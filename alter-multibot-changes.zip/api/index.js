// Foreman core v9: real permission gateway + external-agent adapters + work bus. Agents hold only a Foreman key; every action goes through /api/gateway/act.
const crypto = require('crypto');
const AUTHZ = (()=>{
// Deterministic policy only. Never a payment rail or a grant of authority.
const VERSION='rules-v1';
function evaluate(q,s){
 const deny=(code,reason)=>({version:VERSION,decision:'DENY',code,reason,chargedCents:0});
 if(!Number.isSafeInteger(q.amountCents)||q.amountCents<1||q.currency!=='USD')return deny('invalid_amount','Exact positive USD cents required');
 if(!s.active)return deny('revoked','Bot is not active');
 if(s.paused||s.killed)return deny('paused','Bot or workspace is paused');
 if(s.expired)return deny('expired','Request expired');
 const p=s.policy||{};
 if(p.perActionCents!=null&&q.amountCents>p.perActionCents)return deny('limit_action','Per-request limit exceeded');
 if(p.allowedCategories?.length&&!p.allowedCategories.includes(q.category||'uncategorized'))return deny('merchant_category','Merchant category is outside the owner policy');
 if(p.maxPerHour!=null&&s.recentCount>=p.maxPerHour)return deny('velocity','Hourly admitted-request limit reached');
 if(!Number.isSafeInteger(s.spentToday)||s.spentToday<0||!Number.isSafeInteger(s.dailyLimit)||s.dailyLimit<0)return deny('invalid_policy','Invalid stored limit; owner review required');
 if(s.spentToday+q.amountCents>s.dailyLimit)return deny('limit_daily','Daily sandbox safety cap exceeded');
 if(s.jobRequired||q.taskId){
  if(!s.job||s.job.assignee!==q.botId||s.job.status!=='running')return deny('job_inactive','A running job assigned to this bot is required');
  const g=s.job.sandboxGrant;
  if(!g||g.status!=='active'||g.botId!==q.botId)return deny('job_grant_required','Owner must set a separate sandbox spend budget for this job');
  if(!Number.isSafeInteger(g.budgetCents)||!Number.isSafeInteger(g.spentCents)||g.spentCents+q.amountCents>g.budgetCents)return deny('limit_job','Job sandbox spend budget would be exceeded');
 }
 return {version:VERSION,decision:s.ownerApproved?'ALLOW_SANDBOX':'ASK',code:s.ownerApproved?'owner_approved':'owner_review',reason:s.ownerApproved?'Owner approved exact details; current rules passed':'Owner review required. No spend executes automatically',chargedCents:0};
}
function trust(records){
 const terminal=records.filter(q=>q.authorization&&['simulated','denied','blocked','limit_blocked','expired'].includes(q.status));
 const breaches=terminal.filter(q=>['limit_job','limit_daily','limit_action','merchant_category','velocity','job_inactive','job_grant_required'].includes(q.authorization.code)).length;
 const approved=terminal.filter(q=>q.status==='simulated').length,denied=terminal.filter(q=>q.status==='denied').length;
 return {version:'evidence-v1',scope:'Sandbox decisions only',sampleCount:terminal.length,approvedCount:approved,ownerDeniedCount:denied,policyBlockedCount:breaches,score:terminal.length<5?null:Math.round(100*(terminal.length-breaches)/terminal.length),confidence:terminal.length<5?'insufficient_data':'early_evidence',formula:'100 * (terminal decisions - policy blocks) / terminal decisions; minimum 5',note:'Descriptive compliance signal, not fraud prediction. Owner denials are not policy violations. Never changes permission.'};
}
function demo(){
 const job={assignee:'demo',status:'running',sandboxGrant:{botId:'demo',status:'active',budgetCents:5000,spentCents:0}};
 const base={active:true,spentToday:0,dailyLimit:10000,recentCount:0,jobRequired:true,job,ownerApproved:true,policy:{perActionCents:5000,allowedCategories:['software'],maxPerHour:3}};
 const q={botId:'demo',taskId:'fixture',amountCents:2000,currency:'USD',category:'software'};
 return {mode:'sandbox_fixture',stored:false,chargedCents:0,scenarios:[['Within job budget',q,base],['Over remaining job budget',{...q,amountCents:4000},{...base,job:{...job,sandboxGrant:{...job.sandboxGrant,spentCents:2000}}}],['Outside merchant policy',{...q,category:'travel'},base],['Velocity limit',q,{...base,recentCount:3}],['Needs owner review',q,{...base,ownerApproved:false}],['Revoked bot',q,{...base,active:false}]].map(([name,request,state])=>({name,request,result:evaluate(request,state)})),note:'Made-up bot and requests. The same evaluator gates sandbox card decisions. No issuer, no live charges.'};
}
return {evaluate,trust,demo,VERSION};

})();
const { AsyncLocalStorage } = require('async_hooks');
const als = new AsyncLocalStorage();
// v11: every workspace gets its own key namespace. 'legacy' is the original v9/v10 data (no prefix). 'gl:' keys are global (users, sessions, key index).
const wsId = () => ((als.getStore() || {}).ws) || 'legacy';
const nsKey = k => { const w = wsId(); return (typeof k === 'string' && k.startsWith('fm:') && w !== 'legacy') ? 'w:' + w + ':' + k : k; };

// ---------- storage (Upstash/Vercel KV REST; memory fallback for local dev only) ----------
const URL_ = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const TOK = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
const mem = global.__mem || (global.__mem = { kv: new Map(), lists: new Map() });
async function r(cmd0) {
  const cmd = cmd0.map((x, i) => i === 0 ? x : nsKey(x));
  if (!URL_) return memCmd(cmd);
  const res = await fetch(URL_, { method: 'POST', headers: { Authorization: 'Bearer ' + TOK, 'Content-Type': 'application/json' }, body: JSON.stringify(cmd), ...((als.getStore()||{}).issuerDeadline?{signal:AbortSignal.timeout(Math.max(1,(als.getStore()||{}).issuerDeadline-Date.now()))}:{}) });
  const j = await res.json();
  if (j.error) throw new Error('store: ' + j.error);
  return j.result;
}
function memCmd(c) {
  const [op, k, ...a] = c; const L = () => mem.lists.get(k) || [];
  switch (op.toUpperCase()) {
    case 'EVAL': { const [script,n,key,expected,replacement]=[k,...a]; if(script!==AGENT_CAS || Number(n)!==1)throw Error('unsupported local EVAL'); const old=mem.kv.get(key); if(old==null)return -1;if(old!==expected)return 0;mem.kv.set(key,replacement);return 1; }
    case 'MGET': return c.slice(1).map(x => mem.kv.has(x) ? mem.kv.get(x) : null);
    case 'GET': return mem.kv.has(k) ? mem.kv.get(k) : null;
    case 'SET': if(a.includes('NX')&&mem.kv.has(k))return null;mem.kv.set(k, a[0]); return 'OK';
    case 'INCRBY': { const v = (parseInt(mem.kv.get(k) || '0', 10)) + parseInt(a[0], 10); mem.kv.set(k, String(v)); return v; }
    case 'LPUSH': { const l = L(); l.unshift(a[0]); mem.lists.set(k, l); return l.length; }
    case 'LRANGE': return L().slice(parseInt(a[0], 10), parseInt(a[1], 10) + 1);
    case 'LTRIM': mem.lists.set(k, L().slice(parseInt(a[0], 10), parseInt(a[1], 10) + 1)); return 'OK';
    case 'SADD': { const s = new Set(mem.kv.get(k) || []); s.add(a[0]); mem.kv.set(k, [...s]); return 1; }
    case 'SREM': { const x=(mem.kv.get(k)||[]).filter(v=>v!==a[0]); mem.kv.set(k,x); return 1; }
    case 'SMEMBERS': return mem.kv.get(k) || [];
    case 'EXPIRE': return 1;
    case 'DEL': mem.kv.delete(k); mem.lists.delete(k); return 1;
  }
  throw new Error('memcmd ' + op);
}
const CACHES = new Map(); let SEEDED = false;
const bust = () => { CACHES.delete(wsId()); };
const getJ = async k => { const v = await r(['GET', k]); return v ? JSON.parse(v) : null; };
const setJ = (k, o) => r(['SET', k, JSON.stringify(o)]);
// Policy JSON is authoritative; heartbeats never rewrite it.
const AGENT_CAS = "local old=redis.call('GET',KEYS[1]); if not old then return -1 end; if old~=ARGV[1] then return 0 end; redis.call('SET',KEYS[1],ARGV[2]); return 1";
async function updateAgent(id, patch) {
  const key='fm:agent:'+id;
  for(let attempt=0;attempt<8;attempt++){
    const raw=await r(['GET',key]);if(!raw)return null;
    const a=JSON.parse(raw);patch(a);a.policyRevision=(Number(a.policyRevision)||0)+1;
    const won=await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(a)]);
    if(won===1){bust();return a;}if(won===-1)return null;
  }
  throw new Error('Concurrent policy update; retry');
}
const now = () => new Date().toISOString();
const BRAND_NAME = process.env.BRAND_NAME || 'Alter'; // keep in step with public/brand.js
const rid = p => p + '_' + crypto.randomBytes(5).toString('hex');
const sha = s => crypto.createHash('sha256').update(s).digest('hex');

// ---------- action catalog: the real things an agent can do through Foreman ----------
const ACTIONS = {
  'web.fetch':   { label: 'Fetch a live web page', costCents: 1, risk: 'read' },
  'notes.write': { label: 'Write a note to the shared workspace', costCents: 2, risk: 'write' },
  'notes.delete':{ label: 'Delete a note from the shared workspace', costCents: 5, risk: 'destructive' },
  'work.assign':{label:'Assign a job to another bot',costCents:0,risk:'write'},
  'work.enqueue':{ label: 'Queue an unassigned task', costCents: 0, risk: 'write' },
  'work.handoff':{ label: 'Hand a task to another agent', costCents: 0, risk: 'write' },
};
const DEFAULT_PERMS = { 'web.fetch': 'AUTO', 'notes.write': 'ASK', 'notes.delete': 'NEVER', 'work.handoff': 'AUTO', 'work.enqueue': 'ASK', 'work.assign':'ASK' };

function blockedHost(u) {
  try {
    const x = new URL(u); if (x.protocol !== 'https:') return true;
    const h = x.hostname; if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.|0\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h) || h.endsWith('.internal') || h.includes(':')) return true;
    return false;
  } catch { return true; }
}
async function execute(agent, action, params) {
  if (action === 'web.fetch') {
    if (blockedHost(params.url)) throw new Error('url not allowed');
    const res = await fetch(params.url, { headers: { 'User-Agent': 'foreman-gateway/8', Accept: 'application/json,text/*' }, signal: AbortSignal.timeout(7000) });
    const body = (await res.text()).slice(0, 4000);
    return { summary: `GET ${params.url} -> HTTP ${res.status}, ${body.length} bytes`, data: { status: res.status, body: body.slice(0, 1200) } };
  }
  if (action === 'notes.write') {
    const note = { id: rid('note'), by: agent.id, title: String(params.title || 'untitled').slice(0, 120), text: String(params.text || '').slice(0, 2000), at: now() };
    await r(['LPUSH', 'fm:notes', JSON.stringify(note)]); await r(['LTRIM', 'fm:notes', 0, 99]);
    return { summary: `Wrote note "${note.title}" (${note.id}) to the shared workspace`, data: { note_id: note.id } };
  }
  if (action === 'notes.delete') {
    await r(['DEL', 'fm:notes']);
    return { summary: 'Deleted all notes', data: {} };
  }
  if(action==='work.assign'){
   const to=await getJ('fm:agent:'+params.assignee);if(!to||to.status!=='active'||to.harness||to.hosted||to.id===agent.id)throw Error('Choose an active external bot in this workspace');
   const title=String(params.title||'').trim(),source=String(params.source_id||'').trim();if(!title||title.length>120||!source||source.length>200)throw Error('Title and stable source ID required');
   const id='task_'+sha(agent.id+':'+source).slice(0,24),old=await getJ('fm:task:'+id);if(old){if(old.assignee!==to.id)throw Error('Source ID already belongs to a different assignment');return {summary:'Assignment already registered: '+old.title,data:{task_id:id,status:old.status,assignee:old.assignee,duplicate:true}};}
   const parent=params.parent_id?await getJ('fm:task:'+params.parent_id):null;if(params.parent_id&&(!parent||(parent.assignee!==agent.id&&parent.createdBy!==agent.id)))throw Error('Parent job not yours');
   const advice=await routing(String(params.category||'').toLowerCase());
   const t={id,title,parentId:parent?.id||null,context:parent?String(parent.result||parent.brief||'').slice(0,4000):'',routingReason:advice.suggested?advice.suggested.reason:'No scored category history. Explicit bot choice.',suggestedBotId:advice.suggested?.id||null,brief:String(params.brief||'').slice(0,1500),category:String(params.category||'').toLowerCase(),assignee:to.id,status:'queued',createdBy:agent.id,createdAt:now(),result:null,origin:'chat',sourceId:source};
   if(!await r(['SET','fm:task:'+id,JSON.stringify(t),'NX']))throw Error('Assignment registered concurrently; read the task before retrying');await r(['LPUSH','fm:tasklist',id]);await r(['LTRIM','fm:tasklist',0,59]);
   await event(agent.id,'handoff','Assigned "'+title+'" to '+to.name,{kind:'HANDOFF',taskId:id,toAgentId:to.id});await event(to.id,'assigned',agent.name+' assigned "'+title+'"',{kind:'WAITING',taskId:id,fromAgentId:agent.id});
   return {summary:'Assigned "'+title+'" to '+to.name,data:{task_id:id,status:'queued',assignee:to.id}};
  }
  if (action === 'work.enqueue') {
    if (typeof params.title !== 'string' || !params.title.trim()) throw new Error('title required');
    if (params.brief != null && typeof params.brief !== 'string') throw new Error('brief must be text');
    const slot = Math.floor(Date.now() / 60000), key = `fm:enqueue:${agent.id}:${slot}`;
    const n = await r(['INCRBY', key, 1]); await r(['EXPIRE', key, 120]);
    if (n > 10) throw new Error('Queue limit reached: 10 tasks per minute');
    const t = await newTask({ title: params.title.trim(), brief: params.brief || '', createdBy: agent.id });
    return { summary: `Queued unassigned task "${t.title}" (${t.id})`, data: { task_id: t.id, status: t.status, assignee: null } };
  }
  if (action === 'work.handoff') {
    const t = await getJ('fm:task:' + params.task_id); if (!t || t.assignee !== agent.id) throw new Error('task not found or not yours');
    const to = (await listAgents()).find(x => x.id === params.to || x.name.toLowerCase() === String(params.to || '').toLowerCase());
    if (!to || to.id === agent.id) throw new Error('unknown target agent'); if (to.status !== 'active') throw new Error('target agent is not active');
    const child = await newTask({ title: String(params.title || t.title).slice(0, 120), brief: String(params.brief || '').slice(0, 1500), assignee: to.id, parentId: t.id, context: t.result || '', createdBy: agent.id });
    t.handedTo = to.id; t.childId = child.id; await setJ('fm:task:' + t.id, t);
    await event(agent.id, 'handoff', `Handed "${t.title}" to ${to.name}`, { kind: 'HANDOFF', toAgentId: to.id, taskId: t.id, childTaskId: child.id });
    return { summary: `Handed task "${t.title}" to ${to.name} (new task ${child.id}) with context from ${agent.name}`, data: { child_task_id: child.id, to: to.name } };
  }
  throw new Error('unknown action');
}

// Short-lived single-use browser pairing. Never persists the long credential in client storage.
async function issuePairing(id) {
 const a=await getJ('fm:agent:'+id);if(!a||a.status!=='active'||a.hosted)return {status:409,body:{error:'bot_not_available'}};
 if(await r(['GET','fm:kill']))return {status:403,body:{error:'Workspace is paused'}};
 const code=crypto.randomBytes(5).toString('hex').toUpperCase(),hash=sha(code),expires=Date.now()+300000;
 await setJ('gl:pair:'+hash,{ws:wsId(),agentId:id,epoch:a.oauthEpoch||0,expires});await r(['EXPIRE','gl:pair:'+hash,300]);
 await r(['SET','fm:pairLatest:'+id,hash]);return {status:200,body:{code:code.slice(0,5)+'-'+code.slice(5),expiresAt:new Date(expires).toISOString(),agent:{id:a.id,name:a.name}}};
}
async function redeemPairing(body,ip) {
 const bucket=Math.floor(Date.now()/60000),rate='gl:pairRate:'+sha(ip||'unknown')+':'+bucket;
 const n=await r(['INCRBY',rate,1]);await r(['EXPIRE',rate,120]);if(n>10)return {status:429,body:{error:'Too many attempts. Wait one minute.'}};
 const code=String(body.code||'').replace(/[- ]/g,'').toUpperCase();if(!/^[A-F0-9]{10}$/.test(code))return {status:400,body:{error:'Invalid or expired pairing code'}};
 const hash=sha(code),q=await getJ('gl:pair:'+hash);if(!q||q.expires<=Date.now()||q.agentId!==body.expected_agent_id)return {status:400,body:{error:'Invalid or expired pairing code'}};
 return als.run({ws:q.ws},async()=>{
 const a=await getJ('fm:agent:'+q.agentId);if(!a||a.status!=='active'||a.hosted||(a.oauthEpoch||0)!==q.epoch||await r(['GET','fm:kill'])||await r(['GET','fm:pairLatest:'+a.id])!==hash)return {status:403,body:{error:'Pairing no longer available'}};
 const lock='fm:gatewayKeyLock:'+a.id,token=crypto.randomBytes(12).toString('hex');if(!await r(['SET',lock,token,'NX','PX',30000]))return {status:409,body:{error:'Connection change in progress; retry'}};
 try {
 if(!await r(['SET','gl:pairUsed:'+hash,'1','NX','PX',300000]))return {status:409,body:{error:'Pairing code already used'}};
 const old=await r(['GET','fm:gatewayKeyHash:'+a.id]),key='fmk_'+crypto.randomBytes(20).toString('hex'),kh=sha(key);
 const updated=await updateAgent(a.id,x=>{if(x.status!=='active'||(x.oauthEpoch||0)!==q.epoch)throw Error('Bot authorization changed');x.connectionMode='gateway';x.keyHint=key.slice(0,8)+'...'+key.slice(-4)});
 if(old)await r(['DEL','fm:key:'+old,'gl:key:'+old]);await r(['SET','fm:gatewayKeyHash:'+a.id,kh]);await r(['SET','fm:key:'+kh,a.id]);await r(['SET','gl:key:'+kh,q.ws]);await r(['DEL','gl:pair:'+hash,'fm:gatewaySeen:'+a.id,'fm:seen:'+a.id]);bust();
 return {status:200,body:{key,agent:{id:updated.id,name:updated.name}}};
 }finally{if(await r(['GET',lock])===token)await r(['DEL',lock]);}
 });
}

// ---------- work bus ----------
// Chat adapters register only work that has actually started in their own runtime.
// Idempotency is scoped to authenticated employee and workspace; this never starts hosted inference.
async function chatTask(agent, body) {
  if (agent.status !== 'active' || await r(['GET','fm:kill'])) return {status:403,body:{status:'blocked',reason:'Worker is revoked or workspace paused'}};
  const sourceId = String(body.source_id || '').trim(), title = String(body.title || '').trim();
  if (!sourceId || sourceId.length > 200 || !title || title.length > 120) return {status:400,body:{error:'source_id (max 200) and title (max 120) required'}};
  if(body.assignee&&body.assignee!==agent.id)return gatewayAct(agent,{action:'work.assign',params:body,task_id:body.task_id});
  const category=String(body.category||'').trim().toLowerCase();
  const id = 'task_' + sha(agent.id + ':' + sourceId).slice(0,24);
  const old = await getJ('fm:task:' + id);
  if (old) return {status:200,body:{task:old,duplicate:true}};
  const t = {id,title,brief:String(body.brief || '').slice(0,1500),assignee:agent.id,status:'running',parentId:null,createdBy:agent.id,createdAt:now(),startedAt:now(),result:null,origin:'chat',sourceId,category};
  const won=await r(['SET','fm:task:' + id,JSON.stringify(t),'NX']);if(!won)return {status:200,body:{task:await getJ('fm:task:' + id),duplicate:true}};await r(['LPUSH','fm:tasklist',id]);await r(['LTRIM','fm:tasklist',0,59]);
  await touchAgent(agent);
  await event(agent.id,'task_started','Started: '+title,{kind:'TASK_STARTED',taskId:id,source:'chat'});
  return {status:200,body:{task:t}};
}
async function touchAgent(agent) {
  const live=await getJ('fm:agent:'+agent.id);if(!live||live.status!=='active')return;
  await r(['SET','fm:seen:'+agent.id,now()]);bust();
}
async function taskForAgent(agent,id) {
  const t=await getJ('fm:task:' + id);if(!t)return null;
  // Original worker can read its delegated child result; recipient can read its own assignment.
  if(t.assignee===agent.id || t.createdBy===agent.id)return t;
  return null;
}

async function newTask(o) { const t = { id: rid('task'), title: String(o.title || 'Untitled').slice(0, 120), brief: String(o.brief || '').slice(0, 1500), assignee: o.assignee || null, status: 'queued', parentId: o.parentId || null, context: String(o.context || '').slice(0, 4000), createdBy: o.createdBy || 'owner', createdAt: now(), result: null };
  bust(); await setJ('fm:task:' + t.id, t); await r(['LPUSH', 'fm:tasklist', t.id]); await r(['LTRIM', 'fm:tasklist', 0, 59]);
  if (t.assignee) { const ag = await getJ('fm:agent:' + t.assignee); if (ag && ag.hosted && ag.status === 'active' && !ag.paused) await runHosted(ag, t); }
  return t; }
async function listTasks() { const ids = await r(['LRANGE', 'fm:tasklist', 0, 29]); if (!ids.length) return []; return (await r(['MGET', ...ids.map(i => 'fm:task:' + i)])).filter(Boolean).map(x => JSON.parse(x)); }
async function inbox(agent){return (await listTasks()).filter(t=>t.assignee===agent.id||t.createdBy===agent.id);}
async function capabilityProfiles(){
 const ids=await r(['LRANGE','fm:tasklist',0,59]),ts=ids.length?(await r(['MGET',...ids.map(id=>'fm:task:'+id)])).filter(Boolean).map(x=>JSON.parse(x)):[];
 const rs=(await r(['LRANGE','fm:receipts',0,299])).filter(Boolean).map(x=>JSON.parse(x));
 return (await listAgents()).filter(a=>a.status==='active'&&!a.harness&&!a.hosted).map(a=>{const categories={};
 for(const t of ts.filter(t=>t.assignee===a.id&&['done','failed'].includes(t.status)&&t.category&&!t.synthetic)){
 const k=t.category,c=categories[k]||(categories[k]={completed:0,failed:0,durations:[],trackedCostCents:0,costTrackedJobs:0});t.status==='done'?c.completed++:c.failed++;
 const ms=Date.parse(t.finishedAt)-Date.parse(t.startedAt);if(Number.isFinite(ms)&&ms>=0)c.durations.push(ms);
 const linked=rs.filter(r=>r.taskId===t.id);if(linked.length){c.trackedCostCents+=linked.reduce((v,r)=>v+(Number(r.costCents)||0),0);c.costTrackedJobs++;}
 }
 const profile={};for(const [k,c] of Object.entries(categories)){c.durations.sort((a,b)=>a-b);profile[k]={completed:c.completed,failed:c.failed,samples:c.completed+c.failed,successRate:c.completed/(c.completed+c.failed),medianSeconds:c.durations.length?Math.round(c.durations[Math.floor(c.durations.length/2)]/1000):null,trackedCostCents:c.costTrackedJobs?c.trackedCostCents:null,costTrackedJobs:c.costTrackedJobs};}
 return {id:a.id,name:a.name,provider:a.provider,capabilities:profile};});
}
async function routing(category){const bots=await capabilityProfiles(),rank=bots.map(b=>({b,p:b.capabilities[category]})).filter(x=>x.p).sort((a,b)=>b.p.successRate-a.p.successRate||b.p.samples-a.p.samples||(a.p.medianSeconds??Infinity)-(b.p.medianSeconds??Infinity));const best=rank[0];return {bots,suggested:best?{id:best.b.id,name:best.b.name,category,reason:best.p.completed+' completed / '+best.p.failed+' failed in '+category+'; '+best.p.samples+' reported outcomes'+(best.p.medianSeconds===null?'':'; median '+best.p.medianSeconds+'s')+'. Costs are not used unless tied to a job. This is a suggestion, not a quality guarantee.'}:null,basis:'Retained completed/failed job records only, up to latest 60 jobs. Outcomes are bot-reported, not independently graded. Empty categories and synthetic records excluded. No scored history means no suggestion; no automatic routing.'};}
async function teammates(){return (await capabilityProfiles());}

// Owner-confirmed identity correction. Preserve history; the target must claim.
async function reassignTask(id,body){return withJobLock(id,()=>reassignTaskUnlocked(id,body));}
async function reassignTaskUnlocked(id,body){
 if(body.confirmed!==true)return {status:400,body:{error:'Owner confirmation required'}};
 if(await r(['GET','fm:kill']))return {status:403,body:{error:'Workspace is paused'}};
 const key='fm:task:'+id,raw=await r(['GET',key]),t=raw&&JSON.parse(raw);
 if(!t)return {status:404,body:{error:'Task not found'}};
 if(!['queued','running'].includes(t.status))return {status:409,body:{error:'Only unfinished tasks can be transferred'}};
 if(t.assignee!==body.expectedAssignee||t.status!==body.expectedStatus)return {status:409,body:{error:'Task changed. Review again'}};
 const target=await getJ('fm:agent:'+body.assignee);
 if(!target||target.status!=='active'||target.harness||target.hosted||target.id===t.assignee)return {status:400,body:{error:'Choose a different active external worker in this workspace'}};
 await closeJobGrant(t,'Job transferred; old grant expired');
 const from=t.assignee,at=now(),next={...t,assignee:target.id,status:'queued',startedAt:null,reassignedAt:at,reassignments:[...(t.reassignments||[]),{from,to:target.id,at,previousStatus:t.status,previousStartedAt:t.startedAt||null,by:'owner',reason:String(body.reason||'Owner corrected worker identity').slice(0,300)}]};
 if(await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(next)])!==1)return {status:409,body:{error:'Task changed. Review again'}};
 bust();
 if(from)await event(from,'handoff','Owner moved "'+t.title+'" to '+target.name+'. Stop reporting this job under the old identity.',{kind:'HANDOFF',taskId:id,toAgentId:target.id});
 await event(target.id,'handoff','Owner assigned "'+t.title+'" to you. Read and claim this existing job before reporting or completing it.',{kind:'HANDOFF',taskId:id,fromAgentId:from});
 return {status:200,body:{task:next}};
}

// Owner picks a bot for an unassigned queued job. External bots claim it next; hosted bots run it now.
async function assignTask(id,body){return withJobLock(id,async()=>{
 if(await r(['GET','fm:kill']))return {status:403,body:{error:'Workspace is paused'}};
 const key='fm:task:'+id,raw=await r(['GET',key]),t=raw&&JSON.parse(raw);if(!t)return {status:404,body:{error:'Job not found'}};
 if(t.status!=='queued'||t.assignee)return {status:409,body:{error:'This job already has a bot. Refresh.'}};
 const a=await getJ('fm:agent:'+body.assignee);if(!a||a.status!=='active'||a.harness)return {status:400,body:{error:'Choose an active bot'}};if(a.paused)return {status:409,body:{error:a.name+' is paused'}};
 const next={...t,assignee:a.id,assignedAt:now(),assignedBy:'owner'};
 if(await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(next)])!==1)return {status:409,body:{error:'Job changed. Refresh.'}};
 bust();await event(a.id,'assigned','Owner assigned "'+t.title+'"',{kind:'WAITING',taskId:id});
 if(a.hosted)await runHosted(a,next);
 return {status:200,body:{task:await getJ(key)}};});}
// One job: the task, its events, approvals, gateway receipts, delegated parts, and a plain-language timeline.
async function jobDetail(id){
 const t=await getJ('fm:task:'+id);if(!t)return null;
 const parse=a=>(a||[]).filter(Boolean).map(x=>JSON.parse(x));
 const kids=(await listTasks()).filter(x=>x.parentId===id);
 const ids=new Set([id,...kids.map(k=>k.id)]);
 const events=parse(await r(['LRANGE','fm:events',0,299])).filter(e=>ids.has(e.taskId)||ids.has(e.childTaskId)).reverse();
 const reqIds=await r(['SMEMBERS','fm:taskreqs:'+id]);const requests=reqIds.length?parse(await r(['MGET',...reqIds.map(x=>'fm:req:'+x)])).map(pub):[];
 const receipts=parse(await r(['LRANGE','fm:receipts',0,299])).filter(x=>x.taskId===id).reverse();
 const agents=await listAgents(),name=x=>(agents.find(a=>a.id===x)||{}).name||'A bot';
 return {task:t,children:kids,events,requests,receipts,timeline:timelineOf(t,events,requests,receipts,kids,name)};}
const ACTION_WORDS={'web.fetch':['Read','web page','web pages','web fetch'],'notes.write':['Saved','note','notes','note'],'notes.delete':['Deleted','note set','note sets','delete'],'work.handoff':['Handed off','part','parts','handoff'],'work.assign':['Assigned','job','jobs','assign'],'work.enqueue':['Queued','job','jobs','queue']};
const REQ_WORDS={'web.fetch':'read a web page','notes.write':'save a note','notes.delete':'delete notes','work.handoff':'hand off a part','work.assign':'assign a job','work.enqueue':'queue a job'};
// Steps in plain language. `detail` is owner-only (urls, note titles, tool output); public receipts drop it.
function timelineOf(t,events,requests,receipts,kids,name){
 const out=[],bot=t.assignee?name(t.assignee):'A bot';
 out.push({at:t.createdAt,text:t.createdBy==='owner'?'Owner assigned the job':t.origin==='chat'?bot+' started it from a chat with the owner':name(t.createdBy)+' handed over the job',kind:'step',detail:t.brief?'“'+t.brief.slice(0,120)+'”':null});
 if(t.startedAt&&t.createdBy==='owner')out.push({at:t.startedAt,text:bot+' took the job',kind:'step'});
 for(const e of events){
  if(e.type==='reported'&&e.kind==='TOOL_USED'&&e.agentId===t.assignee)out.push({at:e.at,text:e.text,kind:'step',reported:true});
  if(e.type==='handoff'&&e.toAgentId)out.push({at:e.at,text:'Handed part of it to '+name(e.toAgentId),kind:'step'});}
 /* consecutive gateway actions of the same kind become one step */
 let g=null;
 for(const rc of receipts.filter(x=>x.outcome==='completed'&&!x.requestId)){
  const w=ACTION_WORDS[rc.action]||['Ran','action','actions',rc.action];
  if(g&&g.action===rc.action){g.n++;g.cents+=rc.costCents||0;g.details.push(rc.summary);}
  else{g={action:rc.action,n:1,cents:rc.costCents||0,at:rc.at,details:[rc.summary],w};out.push(g);}}
 for(const x of out.filter(x=>x.action)){x.text=x.w[0]+' '+x.n+' '+(x.n===1?x.w[1]:x.w[2]);x.kind='step';x.meta=x.w[3]+(x.cents?' · '+x.cents+'¢':'');x.detail=x.details.slice(0,3).join(' · ');delete x.w;delete x.details;delete x.n;delete x.cents;delete x.action;}
 for(const q of requests){
  const w=REQ_WORDS[q.action]||q.action,what=q.params&&(q.params.title||q.params.url)?'“'+String(q.params.title||q.params.url).slice(0,60)+'”':null;
  if(['approved','executed','failed'].includes(q.status))out.push({at:q.decidedAt||q.createdAt,text:'Owner approved: '+w,kind:'approval',detail:what});
  else if(q.status==='denied')out.push({at:q.decidedAt||q.createdAt,text:'Owner denied: '+w,kind:'denied',detail:what});
  else if(q.status==='pending')out.push({at:q.createdAt,text:'Waiting for the owner: '+w,kind:'approval',detail:what});
  else if(q.status==='blocked')out.push({at:q.decidedAt||q.createdAt,text:'Blocked: '+w,kind:'denied',detail:q.reason||null});}
 for(const k of kids)if(['done','failed'].includes(k.status))out.push({at:k.finishedAt,text:name(k.assignee)+(k.status==='done'?' finished “'+k.title+'”':' could not finish “'+k.title+'”'),kind:'step'});
 if(t.status==='done')out.push({at:t.finishedAt,text:'Delivered',kind:'step',end:true});
 if(t.status==='failed')out.push({at:t.finishedAt,text:'Stopped without a result',kind:'denied',end:true,detail:t.result?String(t.result).slice(0,160):null});
 return out.filter(x=>x.at).sort((a,b)=>String(a.at).localeCompare(String(b.at))||(a.end?1:0)-(b.end?1:0));}

// ---------- public receipts: owner-reviewed, allowlisted snapshots (the PR #33 boundary, extended) ----------
// A public receipt is never a serialization of the task. The owner writes the public title, summary and reusable template
// (blank to start), reviews the exact snapshot, confirms the public audience, then publishes. The public payload carries no
// bot or owner identity, no task/child titles or IDs, no step notes, no raw result, no params, URLs, file paths or tool details.
const PUBLIC_TTL_DAYS=30;
const publicText=(x,max)=>typeof x==='string'&&x.trim().length>0&&x.trim().length<=max&&!/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/.test(x);
// Conservative rejection that supplements the owner's exact review; it does not "sanitize" and it never claims to.
const PRIVATE_CHECKS=[
 ['secret',/\b(?:fmk_|sk[-_][A-Za-z0-9]|xai-|LLM_|ghp_|gho_|github_pat_|xox[abposr]-|AKIA[0-9A-Z]{12,}|AIza[0-9A-Za-z_-]{20,})|Bearer\s+\S|-----BEGIN|\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}|\b(?:api[_ -]?key|password|passwd|secret|token|credential)s?\s*[:=]|[A-Za-z0-9+/_-]{32,}/i],
 ['internal id',/\b(?:task|agent|req|rcpt|spend|card|grant|user|note|ev|lock|ledger|review)_[a-f0-9]{6,}\b|\bws[a-f0-9]{12}\b/i],
 ['contact',/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|(?:^|[^\w@])@[A-Za-z0-9_]{2,}\b|\b(?:\+?\d[\d ().-]{8,}\d)\b/i],
 ['link',/https?:\/\/|\bwww\.|\blocalhost\b|\b[a-z0-9-]+\.(?:com|net|org|io|ai|dev|app|co|uk|de|gov|edu|xyz|sh|cloud)\b|\b\d{1,3}(?:\.\d{1,3}){3}\b/i],
 ['file path',/(?:^|[\s("'`])(?:~|\.{1,2})?\/[\w.@-]+\/|[A-Za-z]:\\|\\\\[\w.$-]+\\|\b[\w-]+\.(?:md|txt|pdf|docx?|xlsx?|pptx?|csv|tsv|json|ya?ml|js|ts|py|rb|go|sql|env|pem|key|html?|log|zip)\b/i],
 ['tool detail',/\b(?:web\.fetch|notes\.(?:write|delete)|work\.(?:handoff|assign|enqueue)|foreman_\w+|blackbox_\w+|mcp|gateway|tool[_ ]?calls?|function[_ ]?calls?|curl|stack ?trace|json-rpc)\b|\/api\b|\b(?:GET|POST|PUT|PATCH|DELETE)\s+\//i],
];
// Bot names that are ordinary words are not treated as private.
const GENERIC_NAMES=['bot','agent','assistant','ai','helper','worker','robot'];
function publicProblems(fields,names){const out=[];
 for(const [field,v] of Object.entries(fields)){for(const [kind,re] of PRIVATE_CHECKS)if(re.test(v))out.push({field,kind});
  for(const n of names){const s=String(n||'').trim();if(s.length>=3&&!GENERIC_NAMES.includes(s.toLowerCase())&&new RegExp('(^|[^\\w])'+s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'($|[^\\w])','i').test(v))out.push({field,kind:'private name'});}}
 return out.filter((x,i,a)=>a.findIndex(y=>y.field===x.field&&y.kind===x.kind)===i);}
// Steps are fixed-vocabulary codes only; the public page renders them from its own word list.
const PUBLIC_STEPS=['assigned','claimed','actions','approved','denied','blocked','handoff','part_done','delivered','stopped'];
function publicSteps(t,requests,receipts,kids){const s=[],at=x=>x&&Number.isFinite(Date.parse(x))?new Date(x).toISOString():null;
 s.push({at:at(t.createdAt),code:'assigned'});if(t.startedAt)s.push({at:at(t.startedAt),code:'claimed'});
 const acts=receipts.filter(x=>x.outcome==='completed'&&!x.requestId);if(acts.length)s.push({at:at(acts[0].at),code:'actions',n:acts.length});
 for(const q of requests){if(['approved','executed','failed'].includes(q.status))s.push({at:at(q.decidedAt||q.createdAt),code:'approved'});else if(q.status==='denied')s.push({at:at(q.decidedAt||q.createdAt),code:'denied'});else if(q.status==='blocked')s.push({at:at(q.decidedAt||q.createdAt),code:'blocked'});}
 for(const k of kids){s.push({at:at(k.createdAt),code:'handoff'});if(['done','failed'].includes(k.status))s.push({at:at(k.finishedAt),code:'part_done'});}
 if(t.finishedAt)s.push({at:at(t.finishedAt),code:t.status==='done'?'delivered':'stopped'});
 return s.filter(x=>x.at&&PUBLIC_STEPS.includes(x.code)).sort((a,b)=>a.at.localeCompare(b.at)||(['delivered','stopped'].includes(a.code)?1:0)-(['delivered','stopped'].includes(b.code)?1:0));}
async function publicSource(taskId){const j=await jobDetail(taskId);if(!j)return null;const t=j.task;
 return {j,hash:sha(JSON.stringify({id:t.id,status:t.status,result:t.result,title:t.title,startedAt:t.startedAt,finishedAt:t.finishedAt,cost:t.modelCostUsd??null,receipts:j.receipts.map(x=>({id:x.id,hash:x.hash,costCents:x.costCents})),requests:j.requests.map(q=>({id:q.id,status:q.status})),kids:j.children.map(k=>({id:k.id,status:k.status}))}))};}
// Pre-filled budget for the reusable template: what this job recorded (bot-reported model costs + gateway ledger), rounded up to cents.
function suggestedBudgetCents(t,receipts){const ledger=receipts.reduce((v,x)=>v+(Number.isSafeInteger(x.costCents)&&x.costCents>0?x.costCents:0),0),model=t.modelCostUsd!=null?Math.ceil(Math.round(Number(t.modelCostUsd)*1e8)/1e6):0;return ledger+model;}
async function publicReceiptReview(taskId,b){
 const src=await publicSource(taskId);if(!src||!['done','failed'].includes(src.j.task.status))return {status:404,body:{error:'A finished job is required'}};
 const t=src.j.task,fields={title:b.title,summary:b.summary,template:b.template};
 if(!publicText(fields.title,100)||!publicText(fields.summary,700)||!publicText(fields.template,1500))return {status:400,body:{error:'Write a public title (up to 100 characters), a short description (700) and a reusable template (1500). Plain text only.',problems:[]}};
 for(const k of Object.keys(fields))fields[k]=fields[k].trim().replace(/\s+\n/g,'\n');
 const budget=b.budgetCents==null||b.budgetCents===''?null:Number(b.budgetCents);if(budget!=null&&(!Number.isSafeInteger(budget)||budget<0||budget>1000000))return {status:400,body:{error:'Budget must be whole cents between 0 and 1,000,000',problems:[]}};
 const names=[...(await listAgents()).map(a=>a.name),t.title,...src.j.children.map(k=>k.title)];
 const problems=publicProblems(fields,names);
 if(problems.length)return {status:400,body:{error:'Remove private details before sharing: '+problems.map(p=>p.kind+' in '+p.field).join(', ')+'.',problems}};
 const started=Date.parse(t.startedAt),ended=Date.parse(t.finishedAt),ms=ended-started,ledger=src.j.receipts.filter(x=>Number.isSafeInteger(x.costCents)&&x.costCents>=0);
 const snapshot={version:2,title:fields.title,summary:fields.summary,template:fields.template,budgetCents:budget,outcome:t.status==='done'?'completed':'failed',
  elapsedSeconds:Number.isFinite(started)&&Number.isFinite(ended)&&ms>=0?Math.round(ms/1000):null,
  reportedModelCostUsd:t.modelCostUsd!=null&&Number.isFinite(Number(t.modelCostUsd))?Math.round(Number(t.modelCostUsd)*1e6)/1e6:null,externalCost:null,
  ledgerCents:ledger.length?ledger.reduce((v,x)=>v+x.costCents,0):null,trackedActions:src.j.receipts.length,
  approvals:src.j.requests.filter(q=>['approved','executed','failed'].includes(q.status)).length,
  steps:publicSteps(t,src.j.requests,src.j.receipts,src.j.children),
  provenance:'Outcome and model costs are reported by the bot, not verified. Title, description and template were written and reviewed by the owner. Elapsed is wall-clock time, not active work time. The gateway ledger covers retained linked actions only; it is not provider spending or a complete job cost.'};
 const reviewId=crypto.randomBytes(18).toString('hex'),expiresAt=new Date(Date.now()+600000).toISOString();
 await setJ('fm:publicReview:'+reviewId,{snapshot,hash:sha(JSON.stringify(snapshot)),taskId,sourceHash:src.hash,expiresAt});await r(['EXPIRE','fm:publicReview:'+reviewId,600]);
 return {status:200,body:{reviewId,expiresAt,snapshot,hash:sha(JSON.stringify(snapshot)),suggestedBudgetCents:suggestedBudgetCents(t,src.j.receipts),audience:'Anyone with the link, for '+PUBLIC_TTL_DAYS+' days or until you revoke it. People who already saw or copied it keep what they saw.'}};}
// Suggested budget for the review form, before the owner writes anything public.
async function publicReceiptDraft(taskId){const src=await publicSource(taskId);if(!src||!['done','failed'].includes(src.j.task.status))return {status:404,body:{error:'A finished job is required'}};return {status:200,body:{suggestedBudgetCents:suggestedBudgetCents(src.j.task,src.j.receipts),title:'',summary:'',template:''}};}
async function publicReceiptPublish(b){
 if(b.confirmed!==true||b.audience!=='public'||typeof b.reviewId!=='string'||!/^[a-f0-9]{36}$/.test(b.reviewId))return {status:400,body:{error:'Review the exact snapshot and confirm its public audience'}};
 const k='fm:publicReview:'+b.reviewId,review=await getJ(k);if(!review||Date.parse(review.expiresAt)<=Date.now())return {status:409,body:{error:'Review expired; review again'}};
 if(b.hash!==review.hash)return {status:409,body:{error:'This is not the snapshot you reviewed. Review again'}};
 return withJobLock('public:'+b.reviewId,async()=>{const live=await getJ(k);if(!live||live.published)return {status:409,body:{error:'Already published or unavailable'}};
  const src=await publicSource(live.taskId);if(!src||src.hash!==live.sourceHash)return {status:409,body:{error:'The job changed since your review. Review again'}};
  const token=crypto.randomBytes(24).toString('hex'),publishedAt=now(),expiresAt=new Date(Date.now()+PUBLIC_TTL_DAYS*86400000).toISOString();
  await setJ('gl:publicReceipt:'+token,{snapshot:live.snapshot,hash:live.hash,ownerWs:wsId(),taskId:live.taskId,revoked:false,publishedAt,expiresAt});await r(['EXPIRE','gl:publicReceipt:'+token,PUBLIC_TTL_DAYS*86400]);
  await r(['SADD','fm:publicReceipts',token]);await setJ(k,{...live,published:token});
  return {status:201,body:{token,path:'/receipt/'+token,publishedAt,expiresAt,snapshot:live.snapshot,hash:live.hash}};});}
// Public read: only the allowlisted snapshot, its fingerprint and the dates.
async function publicReceiptRead(token){if(!/^[a-f0-9]{48}$/.test(String(token||'')))return null;const p=await getJ('gl:publicReceipt:'+token);
 return !p||p.revoked||Date.parse(p.expiresAt)<=Date.now()||!p.snapshot||p.snapshot.version!==2?null:{token,snapshot:p.snapshot,hash:p.hash,publishedAt:p.publishedAt,expiresAt:p.expiresAt};}
async function publicReceiptRevoke(token){if(!/^[a-f0-9]{48}$/.test(String(token||'')))return {status:404,body:{error:'not found'}};const k='gl:publicReceipt:'+token,p=await getJ(k);if(!p||p.ownerWs!==wsId())return {status:404,body:{error:'not found'}};await setJ(k,{...p,revoked:true,revokedAt:now()});return {status:200,body:{revoked:true}};}
async function publicReceiptList(taskId){const ids=await r(['SMEMBERS','fm:publicReceipts']);return {receipts:(await Promise.all(ids.map(async token=>{const p=await getJ('gl:publicReceipt:'+token);return p&&p.ownerWs===wsId()&&(!taskId||p.taskId===taskId)?{token,path:'/receipt/'+token,title:p.snapshot.title,revoked:!!p.revoked,expired:Date.parse(p.expiresAt)<=Date.now(),publishedAt:p.publishedAt,expiresAt:p.expiresAt}:null}))).filter(Boolean).sort((a,b)=>b.publishedAt.localeCompare(a.publishedAt))};}
const htmlEsc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function receiptPage(x,origin,brand){
 const s=x?x.snapshot:null,title=s?s.title:'Receipt not available',desc=s?s.summary:'This receipt link was revoked, expired or never existed.';
 const og=s?origin+'/og/'+x.token+'.png':origin+'/og/missing.png',url=s?origin+'/receipt/'+x.token:origin;
 const data=s?JSON.stringify(x).replace(/</g,'\\u003c'):'null';
 return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${htmlEsc(title)} · ${htmlEsc(brand)}</title><meta name="description" content="${htmlEsc(desc)}"><meta name="theme-color" content="#F4F4F1"><meta name="robots" content="noindex,nofollow"><meta name="referrer" content="no-referrer">
<meta property="og:type" content="article"><meta property="og:title" content="${htmlEsc(title)}"><meta property="og:description" content="${htmlEsc(desc)}"><meta property="og:url" content="${htmlEsc(url)}"><meta property="og:image" content="${htmlEsc(og)}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:site_name" content="${htmlEsc(brand)}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${htmlEsc(title)}"><meta name="twitter:description" content="${htmlEsc(desc)}"><meta name="twitter:image" content="${htmlEsc(og)}">
<link rel="icon" href="/brand/favicon.svg" type="image/svg+xml"><link rel="icon" href="/brand/favicon-32.png" sizes="32x32" type="image/png"><link rel="icon" href="/brand/favicon-16.png" sizes="16x16" type="image/png"><link rel="apple-touch-icon" href="/brand/alter-icon-light-180.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@400;500&display=swap">
<link rel="stylesheet" href="/styles/tokens.css"><link rel="stylesheet" href="/styles/app.css"><link rel="stylesheet" href="/styles/receipt.css"><script src="/brand.js"></script>
</head><body class="public"><main class="rc" id="rc">${s?'':`<div class="gone"><div class="mark"><i aria-hidden="true"></i><span data-brand="upper">${htmlEsc(String(brand).toLowerCase())}</span></div><h1>This receipt isn't available</h1><p class="lede">The owner revoked the link, it expired, or it never existed. No private job details are shown.</p></div>`}</main>
<script>window.__RECEIPT=${data};</script><script src="/js/receipt-doc.js"></script><script src="/js/receipt-public.js"></script></body></html>`;
}

// Job grants restrict gated actions, not authentication or ordinary replies.
async function withJobLock(id,fn){const k='fm:joblock:'+id,v=rid('lock');if(!await r(['SET',k,v,'NX','PX',120000]))return {status:409,body:{error:'Job is busy. Retry after the current action finishes'}};try{return await fn()}finally{if(await r(['GET',k])===v)await r(['DEL',k]);}}
async function cancelJobRequests(id,reason){for(const qid of await r(['SMEMBERS','fm:reqs'])){const q=await getJ('fm:req:'+qid);if(q&&q.taskId===id&&q.status==='pending'){q.status='blocked';q.reason=reason;q.decidedAt=now();await finishReq(q);await event(q.agentId,'blocked',reason,{kind:'BLOCKED',taskId:id,requestId:qid});}}}
async function setJobScope(id,body){if(body.confirmed!==true||!['job','standing'].includes(body.scope))return {status:400,body:{error:'Review and confirm the permission scope'}};const a=await getJ('fm:agent:'+id);if(!a||a.status!=='active'||a.harness||a.hosted)return {status:404,body:{error:'Active external worker required'}};await updateAgent(id,x=>{x.permissionScope=body.scope});if(body.scope==='job'){for(const qid of await r(['SMEMBERS','fm:reqs'])){const q=await getJ('fm:req:'+qid);if(q&&q.agentId===id&&q.status==='pending'&&!q.taskId){q.status='blocked';q.reason='Standing action permission closed by owner';q.decidedAt=now();await finishReq(q);await event(id,'blocked',q.reason,{requestId:qid});}}}await event(id,'permission','Owner set gated actions to '+body.scope+' scope',{kind:'INTERACTION'});return {status:200,body:{agentId:id,permissionScope:body.scope}};}
async function grantJob(id,body){return withJobLock(id,async()=>{const t=await getJ('fm:task:'+id),a=t&&await getJ('fm:agent:'+t.assignee);if(!t||!a||a.status!=='active'||a.harness||a.hosted)return {status:404,body:{error:'Task and active worker required'}};if(body.confirmed!==true||body.expectedAssignee!==t.assignee||!['running','queued'].includes(t.status))return {status:409,body:{error:'Review this unfinished job and worker again'}};if(await r(['GET','fm:kill']))return {status:403,body:{error:'Workspace paused'}};const modes=body.actions;if(!modes||typeof modes!=='object'||Array.isArray(modes)||!Object.keys(modes).length||Object.entries(modes).some(([k,v])=>!ACTIONS[k]||!['AUTO','ASK'].includes(v)||((a.permissions||{})[k]||DEFAULT_PERMS[k]||'NEVER')==='NEVER'))return {status:400,body:{error:'Choose supported actions and AUTO/ASK modes; NEVER remains blocked'}};if(!Number.isSafeInteger(body.budgetCents)||body.budgetCents<0||body.budgetCents>1000000)return {status:400,body:{error:'Exact ledger budget required (0 to 1000000 cents)'}};const old=t.jobGrant,spent=Number(old?.spentCents||0);if(body.budgetCents<spent)return {status:400,body:{error:'Budget cannot be below already-used ledger cents'}};t.jobGrant={id:rid('grant'),agentId:a.id,actions:{...modes},budgetCents:body.budgetCents,spentCents:spent,status:'active',issuedAt:now(),by:'owner',note:'Gateway ledger only. Not payment authorization.'};await setJ('fm:task:'+id,t);await cancelJobRequests(id,'Job grant changed. Request again under the new grant');bust();await event(a.id,'permission','Owner granted scoped actions for '+t.title,{kind:'INTERACTION',taskId:id});return {status:200,body:{task:t}};});}
async function jobPolicy(agent,action,taskId,grantId){if(!ACTIONS[action])return {code:'unknown_action',reason:'Action is not in the catalog'};if(agent.permissionScope!=='job')return null;if(!taskId)return {code:'job_required',reason:'Register or claim the real job first; gated actions require an owner job grant'};const t=await getJ('fm:task:'+taskId),g=t?.jobGrant;if(!t||t.assignee!==agent.id||t.status!=='running')return {code:'job_inactive',reason:'Job is not running under this worker'};if(!g||g.status!=='active'||g.agentId!==agent.id||grantId&&g.id!==grantId)return {code:'job_grant_required',reason:'Owner must grant actions and a ledger budget for this job'};if(!g.actions[action])return {code:'job_action',reason:'Action is outside the job grant'};if(Number(g.spentCents||0)+ACTIONS[action].costCents>g.budgetCents)return {code:'limit_job',reason:'Job ledger budget would be exceeded'};return null;}
async function closeJobGrant(t,reason){if(t.jobGrant){t.jobGrant={...t.jobGrant,status:'closed',closedAt:now(),closeReason:reason};}await cancelJobRequests(t.id,reason);}

async function claimTask(agent) { if(agent.status!=='active'||agent.paused||await r(['GET','fm:kill']))return null;const active=(await listTasks()).find(t=>t.assignee===agent.id&&t.status==='running');if(active)return active;const ts = (await listTasks()).filter(t => t.status === 'queued' && (t.assignee === agent.id || !t.assignee)).reverse(); const t = ts[0]; if (!t) return null;
  const key='fm:task:'+t.id,raw=await r(['GET',key]),live=raw&&JSON.parse(raw);if(!live||live.status!=='queued'||(live.assignee&&live.assignee!==agent.id))return null;t.status = 'running'; t.assignee = agent.id; t.startedAt = now();if(await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(t)])!==1)return null; await event(agent.id, 'task_started', 'Started: ' + t.title, { kind: 'TASK_STARTED', taskId: t.id }); return t; }
async function completeTask(agent,id,body){return withJobLock(id,()=>completeTaskUnlocked(agent,id,body));}
async function completeTaskUnlocked(agent, id, body) { const raw=await r(['GET','fm:task:'+id]),t=raw&&JSON.parse(raw); if (!t || t.assignee !== agent.id) return { status: 404, body: { error: 'task not found' } };
  if(t.status==='queued'&&(t.reassignedAt||(t.origin==='chat'&&t.createdBy!==agent.id)))return {status:409,body:{error:'Claim the assigned job before completing it'}};
  if (!['running','queued'].includes(t.status)) return {status:409,body:{error:'Task is already terminal',task:t}};
  const failed = body.status === 'failed'; t.status = failed ? 'failed' : 'done'; t.result = String(body.result || '').slice(0, 4000); t.finishedAt = now();
  {const c=reportedCost(body);if(c!=null){t.modelCostUsd=Math.round((Number(t.modelCostUsd||0)+c)*1e6)/1e6;t.modelCostSource=t.modelCostSource==='provider'?'provider+bot':'bot';}} await closeJobGrant(t,'Job finished; action grant expired'); if(await r(['EVAL',AGENT_CAS,1,'fm:task:'+id,raw,JSON.stringify(t)])!==1)return {status:409,body:{error:'Task changed. Read it again'}};
  await touchAgent(agent);
  await event(agent.id, failed ? 'failed' : 'completed', (failed ? 'Failed: ' : 'Finished: ') + t.title, { kind: failed ? 'FAILED' : 'COMPLETED', taskId: t.id });
  if(t.createdBy&&t.createdBy!==agent.id&&t.createdBy!=='owner')await event(t.createdBy,failed?'failed':'completed','Delegate '+(failed?'failed: ':'finished: ')+t.title,{kind:failed?'FAILED':'COMPLETED',taskId:t.id,fromAgentId:agent.id});
  if(t.parentId){const p=await getJ('fm:task:' + t.parentId);if(p&&p.assignee)await event(p.assignee,'result_returned','Delegate '+(failed?'failed: ':'result ready: ')+t.title,{kind:'WAITING',taskId:p.id,childTaskId:t.id,fromAgentId:agent.id});}
  return { status: 200, body: { task: t } }; }
// Read-only, bot-scoped notifications. No task claim, presence update or external delivery.
async function notifications(agent, after) {
  if(agent.status!=='active'||await r(['GET','fm:kill']))return {status:403,body:{status:'blocked',reason:'Worker revoked or workspace paused'}};
  if(after!==undefined&&after!==null&&(typeof after!=='string'||after.length>80))return {status:400,body:{error:'Invalid cursor'}};
  const all=(await r(['LRANGE','fm:events',0,299])).filter(Boolean).map(x=>JSON.parse(x)).filter(e=>e.agentId===agent.id).reverse();
  const index=after?all.findIndex(e=>e.id===after):-1;
  if(after&&index<0)return {status:409,body:{error:'cursor_expired',resetRequired:true,message:'Cursor is outside the retained bot history. Fetch without after to reset; older events may have been lost.'}};
  const kinds=new Set(['NEEDS_APPROVAL','COMPLETED','BLOCKED','FAILED','HANDOFF']);
  const events=all.slice(after?index+1:0).filter(e=>kinds.has(e.kind)).map(e=>({id:e.id,at:e.at,kind:e.kind,text:e.text,taskId:e.taskId||null,requestId:e.requestId||null}));
  const ids=await r(['SMEMBERS','fm:reqs']);
  const pending=ids.length?(await r(['MGET',...ids.map(id=>'fm:req:'+id)])).filter(Boolean).map(x=>JSON.parse(x)).filter(q=>q.agentId===agent.id&&q.status==='pending').map(q=>({id:q.id,action:q.action,label:q.label,createdAt:q.createdAt,status:q.status})):[];
  return {status:200,body:{agentId:agent.id,events,pending,nextCursor:all.length?all[all.length-1].id:null,retention:'Latest 300 workspace events, filtered to this bot. Not a delivery channel.',delivery:'Client automation must poll and notify the owner; this endpoint does not send messages.'}};
}

// Explicit owner conversation telemetry, separate from connection heartbeats.
async function ownerConversation(agent,b,source){return withJobLock('conversation:'+agent.id,async()=>{
 if(agent.status!=='active'||await r(['GET','fm:kill']))return {status:403,body:{status:'blocked',reason:'Worker unavailable or workspace paused'}};
 const valid=x=>typeof x==='string'&&/^[A-Za-z0-9_.:-]{1,100}$/.test(x);
 if(!valid(b.session_id)||!valid(b.event_id)||!Number.isSafeInteger(b.sequence)||b.sequence<1||!['start','update','end'].includes(b.phase))return {status:400,body:{error:'session_id, event_id, positive sequence and start/update/end required. Send no conversation content.'}};
 const key='fm:conversation:'+agent.id,old=await getJ(key),epoch=agent.oauthEpoch||0;
 if(old&&old.epoch===epoch){
  if(old.eventId===b.event_id)return {status:200,body:{status:'ok',duplicate:true,conversation:old}};
  if(old.sessionId===b.session_id&&(b.sequence<=old.sequence||old.phase==='end'))return {status:409,body:{error:'Stale or closed conversation event'}};
  if(old.sessionId!==b.session_id&&b.phase!=='start')return {status:409,body:{error:'Conversation session changed; old event rejected'}};
 }else if(b.phase!=='start')return {status:409,body:{error:'Start the real conversation first'}};
 if(b.phase==='start'&&old?.sessionId!==b.session_id&&old?.epoch===epoch&&old.phase!=='end'&&Date.now()-Date.parse(old.at)<60000)return {status:409,body:{error:'End the current conversation before starting another'}};
 if(b.phase==='start'&&b.sequence!==1)return {status:400,body:{error:'A new conversation starts at sequence 1'}};
 if(b.phase==='start'&&!await r(['SET','fm:conversationSession:'+agent.id+':'+epoch+':'+b.session_id,'used','NX']))return {status:409,body:{error:'Conversation session already used'}};
 const c={sessionId:b.session_id,eventId:b.event_id,sequence:b.sequence,phase:b.phase,at:now(),source,epoch};await setJ(key,c);await touchAgent(agent);
 await event(agent.id,'owner_conversation',b.phase==='end'?'Owner conversation ended':'With you: client-reported owner conversation',{kind:'INTERACTION',source,conversationPhase:b.phase});bust();
 return {status:200,body:{status:'ok',conversation:c}};
 });}
async function reportEvent(agent, body, source) { const kind = normKind(body.kind || body.type || body.status || body.event); if (!kind) return { status: 400, body: { error: 'unrecognized event kind', allowed: KINDS } };
  await touchAgent(agent);
  if (agent.status !== 'active') { await event(agent.id, 'blocked', 'Blocked event report: access revoked', { kind: 'BLOCKED' }); return { status: 403, body: { status: 'blocked', reason: 'Access revoked by owner' } }; }
  if (body.task_id) {const t=await getJ('fm:task:' + body.task_id);if(!t || t.assignee!==agent.id)return {status:404,body:{error:'Task not found or not yours'}};}
  const text = String(body.text || body.message || body.summary || kind).slice(0, 200);
  const cost = reportedCost(body); if (cost != null && body.task_id) await addModelCost(body.task_id, cost);
  await event(agent.id, 'reported', text, { kind, taskId: body.task_id || null, source: source || 'gateway' }); return { status: 200, body: { status: 'ok', kind } }; }
// Model costs are what the bot or provider reports for its own model usage, in USD. Never estimated, never "cost to build".
function reportedCost(b){const v=b&&(b.model_cost_usd??b.modelCostUsd??(b.model_cost_cents!=null?Number(b.model_cost_cents)/100:undefined));const n=Number(v);return v==null||v===''||!Number.isFinite(n)||n<0||n>10000?null:Math.round(n*1e6)/1e6;}
async function addModelCost(taskId,usd){const key='fm:task:'+taskId;for(let i=0;i<8;i++){const raw=await r(['GET',key]);if(!raw)return;const t=JSON.parse(raw);t.modelCostUsd=Math.round((Number(t.modelCostUsd||0)+usd)*1e6)/1e6;t.modelCostSource=t.modelCostSource==='provider'?'provider+bot':'bot';if(await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(t)])===1){bust();return;}}}
// ---------- providers: honest integration tiers ----------
const PROVIDERS = [
  { id: 'instinct', name: 'Instinct', tier: 'verified', how: 'HTTP gateway', note: 'Proven live: a real Instinct agent connected, worked through tasks, and was gated by AUTO, ASK and NEVER, then revoked.' },
  { id: 'custom', name: 'Custom agent', tier: 'verified', how: 'HTTP gateway', note: 'Any agent that can make HTTPS calls. Same adapter Instinct uses.' },
  { id: 'mcp', name: 'API / MCP agent', tier: 'verified', how: 'MCP server (JSON-RPC over HTTPS) or REST', note: 'Foreman exposes /api/mcp. MCP-capable agents get gated tools.' },
  { id: 'grok', name: 'Grok / Grok bots', tier: 'verified', how: 'xAI API worker (HTTP gateway)', note: 'Proven live: a real Grok worker (xAI API, grok-4.3) received a handed-off task through the work bus, did the work, and was gated by ASK on its write.' },
  { id: 'muse', name: 'Meta Muse Spark', tier: 'hosted', how: 'Meta Model API', note: 'Connect with a Meta Model API key. Model-list validation is read-only; tasks use separately billed Meta tokens. No automatic welcome task.' },
];

// ---------- v11: secrets, owner accounts, hosted agents ----------
const ENCK = crypto.createHash('sha256').update('foreman-v11|' + (process.env.ENC_SECRET || TOK || 'dev')).digest();
const enc = t => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', ENCK, iv); const d = Buffer.concat([c.update(String(t), 'utf8'), c.final()]); return [iv, c.getAuthTag(), d].map(b => b.toString('base64')).join('.'); };
const dec = t => { const [iv, tag, d] = String(t).split('.').map(x => Buffer.from(x, 'base64')); const c = crypto.createDecipheriv('aes-256-gcm', ENCK, iv); c.setAuthTag(tag); return Buffer.concat([c.update(d), c.final()]).toString('utf8'); };
const PRESETS = {
  cautious: { 'web.fetch': 'ASK', 'notes.write': 'ASK', 'notes.delete': 'NEVER', 'work.handoff': 'ASK' },
  balanced: { 'web.fetch': 'AUTO', 'notes.write': 'ASK', 'notes.delete': 'NEVER', 'work.handoff': 'AUTO' },
  trusted:  { 'web.fetch': 'AUTO', 'notes.write': 'AUTO', 'notes.delete': 'NEVER', 'work.handoff': 'AUTO' },
};
async function xaiChat(key, model, prompt, maxTokens) {
  const res = await fetch('https://api.x.ai/v1/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key }, signal: AbortSignal.timeout(25000),
    body: JSON.stringify({ model, max_tokens: maxTokens || 600, messages: [{ role: 'system', content: 'You are an AI employee working inside Foreman. Use only the context given. Be concise and factual. If context is missing, say so.' }, { role: 'user', content: prompt }] }) });
  let j = {}; try { j = await res.json(); } catch {}
  if (!res.ok) { const e = new Error(res.status === 401 || res.status === 403 ? 'xAI rejected that key' : (res.status === 402 || res.status === 429) ? 'xAI says this key has no credits or is rate limited' : res.status === 400 ? 'xAI did not recognise that key' : 'xAI error ' + res.status); e.http = res.status; throw e; }
  const text = String((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '').trim();
  return Object.assign(new String(text), { usage: usageOf(j) });
}
// Provider-reported usage only. A cost is recorded only when the provider itself returns one; tokens are never priced here.
function usageOf(j){const u=j&&j.usage;if(!u||typeof u!=='object')return null;const o={promptTokens:Number(u.prompt_tokens)||0,completionTokens:Number(u.completion_tokens)||0};
 const ticks=Number(u.cost_in_usd_ticks);if(Number.isFinite(ticks)&&ticks>=0)o.costUsd=ticks/1e10;else if(Number.isFinite(Number(u.cost))&&Number(u.cost)>=0)o.costUsd=Number(u.cost);return o;}
async function museModels(key) {
  const res = await fetch('https://api.meta.ai/v1/models', { headers: { authorization: 'Bearer ' + key }, signal: AbortSignal.timeout(10000) });
  if (!res.ok) throw new Error(res.status === 401 || res.status === 403 ? 'Meta rejected that key or access is unavailable' : res.status === 429 ? 'Meta is rate limiting this key. Try later.' : 'Meta model lookup failed (HTTP ' + res.status + ')');
  const j = await res.json(); return (Array.isArray(j.data) ? j.data : []).map(m => m.id).filter(id => /^muse-spark-[\w.\-]+$/.test(String(id)));
}
async function museChat(key, model, prompt) {
  const res = await fetch('https://api.meta.ai/v1/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key }, signal: AbortSignal.timeout(25000),
    body: JSON.stringify({ model, max_completion_tokens: 1200, reasoning_effort: 'low', messages: [{ role: 'system', content: 'You are an AI employee working inside Foreman. Use only the context given. Be concise and factual. If context is missing, say so.' }, { role: 'user', content: prompt }] }) });
  if (!res.ok) throw new Error(res.status === 401 || res.status === 403 ? 'Meta rejected this key or model access' : res.status === 402 || res.status === 429 ? 'Meta billing or rate limit prevented this task' : 'Meta task failed (HTTP ' + res.status + ')');
  const j = await res.json(); const text = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
  if (typeof text !== 'string' || !text.trim()) throw new Error('Meta returned no text result'); return Object.assign(new String(text.trim()), { usage: usageOf(j) });
}
// Hosted agents run inline, the moment work is assigned: no polling, no cron, no tab.
async function runHosted(agent, t) {
  const live = await getJ('fm:agent:' + agent.id) || agent;
  t.status = 'running'; t.startedAt = now(); await setJ('fm:task:' + t.id, t);
  await event(agent.id, 'task_started', 'Started: ' + t.title, { kind: 'TASK_STARTED', taskId: t.id });
  const stop = live.status !== 'active' ? 'Access revoked by owner' : live.paused ? 'Paused by owner' : (await r(['GET', 'fm:kill'])) ? 'Owner kill switch is on' : null;
  if (stop) { t.status = 'failed'; t.result = 'Not run: ' + stop; t.finishedAt = now(); await setJ('fm:task:' + t.id, t); await event(agent.id, 'blocked', 'Blocked task: ' + stop, { kind: 'BLOCKED', taskId: t.id }); return; }
  try {
    const key = dec(await r(['GET', 'fm:secret:' + agent.id])); const meta = live.providerId === 'muse'; const model = live.model || (meta ? 'muse-spark-1.3' : 'grok-4.3');
    await event(agent.id, 'tool_used', 'Calling ' + (meta ? 'Muse Spark' : 'Grok') + ' (' + model + ')', { kind: 'TOOL_USED', taskId: t.id });
    const prompt = 'Task: ' + t.title + '\nBrief: ' + t.brief + (t.context ? '\nContext from the previous agent (via Foreman):\n' + t.context : '');
    const res = await (meta ? museChat(key, model, prompt) : xaiChat(key, model, prompt)), out = String(res);
    t.status = 'done'; t.result = out.slice(0, 4000); t.finishedAt = now();
    if (res.usage) { t.modelUsage = { provider: meta ? 'meta' : 'xai', model, promptTokens: res.usage.promptTokens, completionTokens: res.usage.completionTokens }; if (res.usage.costUsd != null) { t.modelCostUsd = res.usage.costUsd; t.modelCostSource = 'provider'; } }
    await setJ('fm:task:' + t.id, t);
    await event(agent.id, 'completed', 'Finished: ' + t.title, { kind: 'COMPLETED', taskId: t.id });
    try { await gatewayAct(live, { action: 'notes.write', params: { title: ('Result: ' + t.title).slice(0, 80), text: out.slice(0, 1500) } }); } catch (e) {}
  } catch (e) {
    await mark('first_task_failed', { reason: /recognise/.test(e.message) ? 'bad_key_format' : /rejected/.test(e.message) ? 'xai_rejected' : /credit|rate/.test(e.message) ? 'xai_credits' : 'run_error' }); t.status = 'failed'; t.result = String(e.message).slice(0, 300); t.finishedAt = now(); await setJ('fm:task:' + t.id, t);
    await event(agent.id, 'failed', 'Failed: ' + t.title + ' (' + t.result + ')', { kind: 'FAILED', taskId: t.id });
  }
}
// owner accounts: email + password (scrypt), session cookie, one workspace per account
const COOKIE = 'fm_sess';
const LEGACY_CLAIM_HASH = '939eed690d2af252b4940442b755cb84ba4c27be515142877a44b1a32424454d';
const cookieOf = req => { const m = String(req.headers.cookie || '').match(new RegExp('(?:^|; )' + COOKIE + '=([^;]+)')); return m ? m[1] : null; };
async function getSession(req) { const t = cookieOf(req); if (!t) return null; const v = await r(['GET', 'gl:sess:' + sha(t)]);if(!v)return null;const sess=JSON.parse(v),u=await getJ('gl:user:'+sha(sess.email));return u&&u.id===sess.uid&&u.ws===sess.ws?sess:null; }
const setCookie = (res, v, maxAge) => res.setHeader('Set-Cookie', `${COOKIE}=${v}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`);
async function startSession(res, user) { const t = crypto.randomBytes(32).toString('hex'); await r(['SET', 'gl:sess:' + sha(t), JSON.stringify({ uid: user.id, email: user.email, ws: user.ws }), 'EX', 2592000]); setCookie(res, t, 2592000); }
// funnel instrumentation: first time each workspace reaches a step, record it once
const STEPS = ['signup', 'connect_started', 'connected', 'first_task_started', 'approval_shown', 'approval_completed', 'first_receipt'];
async function track(step, extra, ws) { try { ws = ws || wsId(); if (!STEPS.includes(step)) return; const first = await r(['SET', 'gl:fn:' + ws + ':' + step, '1', 'NX']); if (!first) return; await r(['LPUSH', 'gl:funnel', JSON.stringify({ ws, step, at: now(), ...(extra || {}) })]); await r(['LTRIM', 'gl:funnel', 0, 4999]); } catch (e) {} }
// extra per-session events: failures and visits. Never stores keys or message text, only short reason codes.
async function mark(kind, extra, ws) { try { ws = ws || wsId(); if (kind === 'visit' && !(await r(['SET', 'gl:vis:' + ws, '1', 'NX', 'EX', 1800]))) return; await r(['LPUSH', 'gl:funnel', JSON.stringify({ ws, k: kind, at: now(), ...(extra || {}) })]); await r(['LTRIM', 'gl:funnel', 0, 4999]); } catch (e) {} }
const SLOW = { connect_started: 120, connected: 120, first_task_started: 45, approval_shown: 90, approval_completed: 180, first_receipt: 45 }; // seconds allowed since the previous step
async function funnel(only) {
  const rows = ((await r(['LRANGE', 'gl:funnel', 0, 4999])) || []).map(x => JSON.parse(x)).filter(x => x.ws !== 'legacy').reverse(); const by = {};
  rows.forEach(x => { const w = (by[x.ws] = by[x.ws] || { steps: {}, ev: [], visits: [] }); if (x.provider) w.provider = x.provider; if (x.step) w.steps[x.step] = x.at; else if (x.k === 'visit') w.visits.push(x.at); else if (x.k) w.ev.push({ kind: x.k, reason: x.reason || null, at: x.at }); });
  const ids = Object.keys(by).sort((a, b) => (by[a].steps.signup || '') < (by[b].steps.signup || '') ? -1 : 1); const sec = (a, b) => Math.round((Date.parse(b) - Date.parse(a)) / 1000);
  const sessions = ids.map((w, i) => { const d = by[w], reached = STEPS.filter(st => d.steps[st]); const steps = {}; let prev = null; const slow = [];
    STEPS.forEach(st => { if (!d.steps[st]) return; const gap = prev ? sec(d.steps[prev], d.steps[st]) : null; steps[st] = { at: d.steps[st], secFromPrevious: gap }; if (gap != null && SLOW[st] && gap > SLOW[st]) slow.push({ step: st, seconds: gap, limit: SLOW[st] }); prev = st; });
    const last = reached[reached.length - 1] || null, next = last ? STEPS[STEPS.indexOf(last) + 1] || null : 'signup'; const rcpt = d.steps.first_receipt;
    const returned = rcpt ? d.visits.filter(v => sec(rcpt, v) > 300).length > 0 : false; const idle = last ? sec(d.steps[last], now()) : null;
    return { id: 'session#' + (ids.length - i), workspace: w, provider: d.provider || null, signupAt: d.steps.signup || null, steps, stoppedAfter: next ? last : null, stuckAt: next, secondsSinceLastStep: next ? idle : null, slowSteps: slow, failures: d.ev.filter(e => /fail/.test(e.kind)), reachedFirstReceipt: !!rcpt, secondsSignupToReceipt: rcpt && d.steps.signup ? sec(d.steps.signup, rcpt) : null, returnedAfterReceipt: returned, visits: d.visits.length }; }).reverse();
  const list = only ? sessions.filter(x => x.workspace === only) : sessions;
  const counts = STEPS.map(st => ({ step: st, sessions: list.filter(x => x.steps[st]).length })); const steps = counts.map((c, i) => ({ ...c, pctOfPrevious: i === 0 ? null : (counts[i - 1].sessions ? Math.round(100 * c.sessions / counts[i - 1].sessions) : null) }));
  const t = list.map(x => x.secondsSignupToReceipt).filter(x => x != null).sort((a, b) => a - b); const fails = {}; list.forEach(x => x.failures.forEach(f => { const k = f.kind + (f.reason ? ':' + f.reason : ''); fails[k] = (fails[k] || 0) + 1 }));
  const safe = list.map(x => { const y = { ...x }; if (only) y.workspace = undefined; else delete y.workspace; return y; });
  return { summary: { sessions: list.length, reachedFirstReceipt: list.filter(x => x.reachedFirstReceipt).length, returnedAfterReceipt: list.filter(x => x.returnedAfterReceipt).length, medianSecondsSignupToReceipt: t.length ? t[Math.floor(t.length / 2)] : null, failures: fails, slowLimitsSeconds: SLOW }, steps, sessions: safe };
}
function funnelHtml(f) { const e = x => String(x == null ? '' : x).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); const S = f.summary;
  return `<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Foreman test sessions</title><body style="font:14px system-ui;margin:24px;color:#0f172a"><h2>Foreman test sessions</h2><p>${S.sessions} sessions - ${S.reachedFirstReceipt} reached first receipt - ${S.returnedAfterReceipt} returned after - median signup to receipt: ${S.medianSecondsSignupToReceipt == null ? 'n/a' : S.medianSecondsSignupToReceipt + 's'}</p><table cellpadding=6 style="border-collapse:collapse"><tr style="background:#f1f5f9"><th align=left>Step<th>Sessions<th>% of previous</tr>${f.steps.map(x => `<tr><td>${e(x.step)}<td align=center>${x.sessions}<td align=center>${x.pctOfPrevious == null ? '' : x.pctOfPrevious + '%'}</tr>`).join('')}</table><p>Failures: ${e(JSON.stringify(S.failures))}</p><h3>Each session</h3><table cellpadding=6 border=1 style="border-collapse:collapse;border-color:#e2e8f0"><tr style="background:#f1f5f9"><th>Session<th>Provider<th>Signed up<th>Stopped / stuck at<th>Idle since last step<th>Slow steps<th>Failures<th>Receipt<th>Returned</tr>${f.sessions.map(x => `<tr><td>${e(x.id)}<td>${e(x.provider || '-')}<td>${e(x.signupAt)}<td>${e(x.stuckAt || 'finished')}<td>${x.stuckAt ? e(x.secondsSinceLastStep) + 's' : '-'}<td>${e(x.slowSteps.map(y => y.step + ' ' + y.seconds + 's').join(', ') || '-')}<td>${e(x.failures.map(y => y.kind + (y.reason ? ':' + y.reason : '')).join(', ') || '-')}<td>${x.reachedFirstReceipt ? 'yes' + (x.secondsSignupToReceipt != null ? ' (' + x.secondsSignupToReceipt + 's)' : '') : 'no'}<td>${x.returnedAfterReceipt ? 'yes' : 'no'}</tr>`).join('')}</table></body>`; }
async function resetOwnerWorkspace(req,res,body){
 const sess=await getSession(req);if(!sess)return res.status(401).json({error:'Sign in required'});
 const origin=(/^localhost/.test(req.headers.host)?'http://':'https://')+req.headers.host;
 if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});
 if(body.confirmed!==true||body.expectedWorkspace!==sess.ws)return res.status(400).json({error:'Confirm the current workspace reset'});
 const key='gl:user:'+sha(sess.email),raw=await r(['GET',key]),u=raw&&JSON.parse(raw);
 if(!u||u.id!==sess.uid||u.ws!==sess.ws)return res.status(409).json({error:'Account changed'});
 if(sess.ws==='legacy'&&await r(['GET','gl:legacy-owner'])!==sess.email)return res.status(403).json({error:'Legacy owner required'});
 return als.run({ws:sess.ws},async()=>{
  const agents=(await listAgents()).filter(a=>!a.harness&&!a.hosted),actual=agents.map(a=>a.id).sort();
  if(JSON.stringify(actual)!==JSON.stringify((body.expectedAgentIds||[]).slice().sort()))return res.status(409).json({error:'Bot roster changed; review again'});
  if(!await r(['SET','fm:ownerResetLock','1','NX','EX',120]))return res.status(409).json({error:'Reset busy'});
  try{
   const oldWs=sess.ws,newWs='ws'+crypto.randomBytes(6).toString('hex');
   for(const a of agents){await updateAgent(a.id,x=>{x.status='revoked';x.revokedAt=now();x.oauthEpoch=(x.oauthEpoch||0)+1;});await r(['DEL','fm:secret:'+a.id]);const kh=await r(['GET','fm:gatewayKeyHash:'+a.id]);if(kh){await r(['DEL','fm:key:'+kh]);await r(['DEL','gl:key:'+kh]);}
    for(const gid of await r(['SMEMBERS','fm:oauth:grants:'+a.id])){const g=await getJ('gl:oauth:grant:'+gid);if(g&&g.ws===oldWs&&g.agentId===a.id)await setJ('gl:oauth:grant:'+gid,{...g,revoked:true,revokedAt:now(),failureReason:'owner_workspace_reset'});}}
   for(const token of await r(['SMEMBERS','fm:publicReceipts'])){const p=await getJ('gl:publicReceipt:'+token);if(p&&p.ownerWs===oldWs)await setJ('gl:publicReceipt:'+token,{...p,revoked:true,revokedAt:now()});}
   for(const t of await listTasks())for(const token of await r(['SMEMBERS','fm:shares:'+t.id])){const p=await getJ('gl:share:'+token);if(p&&p.ws===oldWs)await setJ('gl:share:'+token,{...p,revoked:true,revokedAt:now()});}
   const next={...u,ws:newWs,previousWorkspace:oldWs,resetAt:now()};
   if(await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(next)])!==1)return res.status(409).json({error:'Account changed after revocation; sign in and review reset'});
   bust();await startSession(res,next);return res.json({ok:true,workspace:newWs,archivedWorkspace:oldWs,botsRevoked:actual,empty:true});
  }finally{await r(['DEL','fm:ownerResetLock']);}
 });
}
async function handleAuth(req, res, path, body) {
  if(path==='/auth/reset-workspace'&&req.method==='POST')return resetOwnerWorkspace(req,res,body);
  if (path === '/me') { const s = await getSession(req); if (!s) return res.status(401).json({ error: 'auth' }); if (s.ws !== 'legacy') await mark('visit', null, s.ws); return res.json({ email: s.email, legacy: s.ws === 'legacy', workspace:s.ws }); }
  if (path === '/auth/logout') { const t = cookieOf(req); if (t) await r(['DEL', 'gl:sess:' + sha(t)]); setCookie(res, '', 0); return res.json({ ok: true }); }
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST' });
  const email = String(body.email || '').trim().toLowerCase(), pw = String(body.password || '');
  if (!/^[^@\s]{1,64}@[^@\s]{1,120}\.[^@\s]{2,}$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address' });
  const rl = await r(['INCRBY', 'gl:rl:' + sha(email), 1]); await r(['EXPIRE', 'gl:rl:' + sha(email), 900]); if (rl > 12) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' });
  if (path === '/auth/signup') {
    if (pw.length < 8) return res.status(400).json({ error: 'Use a password of at least 8 characters' });
    if (await r(['GET', 'gl:user:' + sha(email)])) return res.status(409).json({ error: 'An account with that email already exists. Sign in instead.' });
    let ws = 'ws' + crypto.randomBytes(6).toString('hex');
    if (body.claim) { if (sha(String(body.claim).trim()) !== LEGACY_CLAIM_HASH || await r(['GET', 'gl:legacy-owner'])) return res.status(400).json({ error: 'That claim code is not valid or was already used' }); ws = 'legacy'; await r(['SET', 'gl:legacy-owner', email]); }
    const salt = crypto.randomBytes(16).toString('hex'); const user = { id: rid('user'), email, salt, hash: crypto.scryptSync(pw, salt, 32).toString('hex'), ws, createdAt: now() };
    await r(['SET', 'gl:user:' + sha(email), JSON.stringify(user)]); await track('signup', null, ws); await startSession(res, user); return res.json({ ok: true, email, legacy: ws === 'legacy' });
  }
  if (path === '/auth/login') {
    const raw = await r(['GET', 'gl:user:' + sha(email)]); const u = raw && JSON.parse(raw);
    const okp = u && crypto.timingSafeEqual(Buffer.from(crypto.scryptSync(pw, u.salt, 32).toString('hex')), Buffer.from(u.hash));
    if (!okp) return res.status(401).json({ error: 'Email or password is wrong' });
    await startSession(res, u); return res.json({ ok: true, email, legacy: u.ws === 'legacy' });
  }
  return res.status(404).json({ error: 'not found' });
}

// ---------- core ----------
async function listAgents() { const ids = await r(['SMEMBERS', 'fm:agents']); if (!ids.length) return []; const vs = await r(['MGET', ...ids.map(i => 'fm:agent:' + i)]), seen=await r(['MGET',...ids.map(i=>'fm:seen:'+i)]); return vs.map((v,i)=>{if(!v)return null;const a=JSON.parse(v);if(seen[i] && (!a.lastSeen || seen[i]>a.lastSeen))a.lastSeen=seen[i];return a;}).filter(Boolean).sort((x, y) => x.createdAt < y.createdAt ? -1 : 1); }
// Universal Foreman event model. Every provider's activity is normalized into one of these kinds.
const KINDS = ['INTERACTION','TASK_STARTED','TOOL_USED','ACTION_REQUESTED','WAITING','HANDOFF','COMPLETED','FAILED','NEEDS_APPROVAL','BLOCKED'];
const KIND_OF = { attempt:'ACTION_REQUESTED', pending:'NEEDS_APPROVAL', completed:'COMPLETED', failed:'FAILED', blocked:'BLOCKED', revoked:'BLOCKED', denied:'BLOCKED', handoff:'HANDOFF' };
// adapter-level normalizer: maps a provider's own vocabulary onto KINDS
function normKind(x) { const k = String(x || '').toUpperCase().replace(/[\s-]+/g, '_'); if (KINDS.includes(k)) return k;
  const m = [[/START|BEGIN|RUNNING|PICKED|CLAIM/, 'TASK_STARTED'],[/TOOL|CALL|INVOK/, 'TOOL_USED'],[/REQUEST|ATTEMPT|ACTION/, 'ACTION_REQUESTED'],[/WAIT|IDLE|PEND|BLOCKED_ON|QUEUE/, 'WAITING'],[/HAND|DELEGAT|TRANSFER/, 'HANDOFF'],[/DONE|COMPLET|FINISH|SUCCE/, 'COMPLETED'],[/FAIL|ERR/, 'FAILED'],[/APPROV/, 'NEEDS_APPROVAL'],[/BLOCK|DENIED|REFUS/, 'BLOCKED']];
  for (const [re, v] of m) if (re.test(k)) return v; return null; }
async function event(agentId, type, text, extra) { bust(); const e = { id: rid('ev'), at: now(), agentId, type, kind: (extra && extra.kind) || KIND_OF[type] || null, text, ...extra };
  if (agentId && e.kind && !(extra && extra.presenceOnly)) await setJ('fm:st:' + agentId, { kind: e.kind, text, at: e.at, taskId: e.taskId || null, toAgentId: e.toAgentId || null, eventId: e.id }); await r(['LPUSH', 'fm:events', JSON.stringify(e)]); await r(['LTRIM', 'fm:events', 0, 299]); return e; }
async function spentToday(agentId) { return parseInt((await r(['GET', `fm:spend:${agentId}:${now().slice(0, 10)}`])) || '0', 10); }
async function receipt(agent, action, params, outcome, cost, summary, reqId, extra) { bust(); await track('first_receipt');
  const prev = (await r(['GET', 'fm:lasthash'])) || 'genesis';
  const rec = { id: rid('rcpt'), at: now(), agentId: agent.id, agentName: agent.name, action, params: redact(params), outcome, costCents: cost, summary, requestId: reqId || null, ...extra, prevHash: prev };
  rec.hash = sha(prev + JSON.stringify(rec));
  await r(['SET', 'fm:lasthash', rec.hash]); await r(['LPUSH', 'fm:receipts', JSON.stringify(rec)]); await r(['LTRIM', 'fm:receipts', 0, 299]);
  return rec;
}
const redact = p => { const o = {}; for (const k of Object.keys(p || {})) o[k] = String(p[k]).slice(0, 200); return o; };

// Policy check, shared by first attempt and by approval time. Returns null if allowed, else {code, reason}.
async function policy(agent, action, mode) {
  const a = ACTIONS[action]; if (!a) return { code: 'unknown_action', reason: 'Action is not in the catalog' };
  if (agent.status !== 'active') return { code: 'revoked', reason: agent.status === 'revoked' ? 'Access revoked by owner' : 'Agent is not active' };
  if (agent.paused) return { code: 'paused', reason: 'Paused by owner' };
  if (await r(['GET', 'fm:kill'])) return { code: 'killed', reason: 'Owner kill switch is on' };
  if (mode === 'NEVER') return { code: 'never', reason: 'Permission is NEVER for this action' };
  const lim = agent.limits || {};
  if (lim.perActionCents != null && a.costCents > lim.perActionCents) return { code: 'limit_action', reason: `Cost ${a.costCents}c exceeds per-action limit ${lim.perActionCents}c` };
  if (agent.permissionScope!=='job' && lim.dailyCents != null) { const s = await spentToday(agent.id); if (s + a.costCents > lim.dailyCents) return { code: 'limit_daily', reason: `Daily budget ${lim.dailyCents}c would be exceeded (spent ${s}c)` }; }
  return null;
}

async function runAndReceipt(agent, action, params, reqId, approvedBy, taskId) {
  const a = ACTIONS[action];
  try {
    const out = await execute(agent, action, params);
    await r(['INCRBY', `fm:spend:${agent.id}:${now().slice(0, 10)}`, a.costCents]);
    if(agent.permissionScope==='job'&&taskId){const t=await getJ('fm:task:'+taskId);t.jobGrant.spentCents=Number(t.jobGrant.spentCents||0)+a.costCents;await setJ('fm:task:'+taskId,t);}
    const rec = await receipt(agent, action, params, 'completed', a.costCents, out.summary, reqId, { approvedBy: approvedBy || 'policy:AUTO',taskId:taskId||null });
    await event(agent.id, 'completed', out.summary, { receiptId: rec.id });
    return { rec, out };
  } catch (e) {
    const rec = await receipt(agent, action, params, 'failed', 0, 'Execution failed: ' + e.message, reqId, { approvedBy: approvedBy || 'policy:AUTO',taskId:taskId||null });
    await event(agent.id, 'failed', 'Execution failed: ' + e.message, { receiptId: rec.id });
    return { rec, out: null, error: e.message };
  }
}

async function resolveAgent(req) {
  const key = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '').trim(); if (!key) return null;
  const oauth=await getJ('gl:oauth:token:'+sha(key));if(oauth){if(!oauth.grantId){await als.run({ws:oauth.ws},()=>setJ('fm:oauth:legacy:'+oauth.agentId,{seenAt:now(),epoch:oauth.epoch||0}));CACHES.delete(oauth.ws);}if(oauth.expires<Date.now())return null;if(oauth.grantId){const grant=await getJ('gl:oauth:grant:'+oauth.grantId);if(!grant||grant.revoked)return null;await als.run({ws:oauth.ws},()=>r(['SADD','fm:oauth:grants:'+oauth.agentId,oauth.grantId]));}const agent=await als.run({ws:oauth.ws},()=>getJ('fm:agent:'+oauth.agentId));return agent&&agent.status==='active'&&((oauth.epoch||0)===(agent.oauthEpoch||0))?{ws:oauth.ws,agent}:null;}
  const w = await r(['GET', 'gl:key:' + sha(key)]);
  if (w) { const agent = await als.run({ ws: w }, () => authAgent(req)); return agent ? { ws: w, agent, apiKey: true } : null; }
  const agent = await als.run({ ws: 'legacy' }, () => authAgent(req)); return agent ? { ws: 'legacy', agent, apiKey: true } : null;
}
async function authAgent(req) {
  const h = req.headers['authorization'] || ''; const key = h.replace(/^Bearer\s+/i, '').trim(); if (!key) return null;
  const id = await r(['GET', 'fm:key:' + sha(key)]); if (!id) return null;
  const current=await r(['GET','fm:gatewayKeyHash:'+id]);if(current&&current!==sha(key))return null;return getJ('fm:agent:' + id);
}

async function gatewayAct(agent,body){const taskId=body.task_id||body.params?.task_id;return taskId?withJobLock(taskId,()=>gatewayActUnlocked(agent,body)):gatewayActUnlocked(agent,body);}
async function gatewayActUnlocked(agent, body) {
  agent=await getJ('fm:agent:'+agent.id)||{...agent,status:'revoked'};
  const action = body.action, params = body.params || {}, taskId=body.task_id||params.task_id;
  await touchAgent(agent);
  const task=taskId?await getJ('fm:task:'+taskId):null;
  const mode = (agent.permissions||{})[action]==='NEVER'?'NEVER':agent.permissionScope==='job'?(task?.jobGrant?.actions?.[action]||'NEVER'):((agent.permissions||{})[action]||DEFAULT_PERMS[action]||'NEVER');
  await event(agent.id, 'attempt', `Attempted ${action} (${mode})`, { action });
  const blocked = await jobPolicy(agent,action,taskId) || await policy(agent, action, mode);
  if (blocked) {
    const rec = await receipt(agent, action, params, 'blocked', 0, `BLOCKED: ${blocked.reason}`, null, { code: blocked.code });
    await event(agent.id, 'blocked', `Blocked ${action}: ${blocked.reason}`, { receiptId: rec.id, code: blocked.code });
    return { status: 403, body: { status: 'blocked', code: blocked.code, reason: blocked.reason, receipt_id: rec.id } };
  }
  if (mode === 'ASK') {
    const q = { id: rid('req'), agentId: agent.id, agentName: agent.name, action, params: redact(params), rawParams: params, label: ACTIONS[action].label, costCents: ACTIONS[action].costCents, status: 'pending', createdAt: now(), taskId:taskId||null,grantId:agent.permissionScope==='job'?task?.jobGrant?.id:null };
    bust(); await setJ('fm:req:' + q.id, q); await r(['SADD', 'fm:reqs', q.id]); if (q.taskId) await r(['SADD', 'fm:taskreqs:' + q.taskId, q.id]);
    await event(agent.id, 'pending', `Waiting for owner approval: ${action}`, { requestId: q.id,taskId:q.taskId||null });
    return { status: 202, body: { status: 'pending', request_id: q.id, message: 'Action is paused until the owner approves or denies it.' } };
  }
  const { rec, out, error } = await runAndReceipt(agent, action, params, null, null, taskId);
  if (error) return { status: 502, body: { status: 'failed', error, receipt_id: rec.id } };
  return { status: 200, body: { status: 'completed', result: out.data, receipt_id: rec.id } };
}

async function decide(reqId,decision){const q=await getJ('fm:req:'+reqId);return q?.taskId?withJobLock(q.taskId,()=>decideUnlocked(reqId,decision)):decideUnlocked(reqId,decision);}
async function decideUnlocked(reqId, decision) {
  const q = await getJ('fm:req:' + reqId); if (!q) return { status: 404, body: { error: 'not found' } };
  if (q.status !== 'pending') return { status: 409, body: { error: 'already ' + q.status, request: pub(q) } };
  const agent = await getJ('fm:agent:' + q.agentId);
  if (decision === 'deny') {
    q.status = 'denied'; q.decidedAt = now(); await finishReq(q);
    const rec = await receipt(agent, q.action, q.params, 'denied', 0, `Owner denied ${q.action}`, q.id, { approvedBy: 'owner:deny' });
    await event(agent.id, 'denied', `Owner denied ${q.action}`, { requestId: q.id, receiptId: rec.id });
    return { status: 200, body: { request: pub(q) } };
  }
  // approval: re-check policy NOW (agent may have been revoked / budget changed while paused). Mode treated as AUTO for this one action.
  const blocked = await jobPolicy(agent,q.action,q.taskId,q.grantId) || await policy(agent, q.action, (agent.permissions||{})[q.action]==='NEVER'?'NEVER':'AUTO');
  if (blocked) {
    q.status = 'blocked'; q.decidedAt = now(); q.reason = blocked.reason; await finishReq(q);
    const rec = await receipt(agent, q.action, q.params, 'blocked', 0, `BLOCKED at approval: ${blocked.reason}`, q.id, { code: blocked.code });
    await event(agent.id, 'blocked', `Blocked at approval: ${blocked.reason}`, { requestId: q.id, receiptId: rec.id });
    return { status: 200, body: { request: pub(q) } };
  }
  q.status = 'approved'; q.decidedAt = now(); bust(); await setJ('fm:req:' + q.id, q);
  const { rec, out, error } = await runAndReceipt(agent, q.action, q.rawParams, q.id, 'owner:approve',q.taskId);
  q.status = error ? 'failed' : 'executed'; q.receiptId = rec.id; q.result = out ? out.data : { error }; await finishReq(q);
  return { status: 200, body: { request: pub(q), receipt: rec } };
}
const pub = q => { const { rawParams, ...rest } = q; return rest; };

const TASK_CATEGORY_ROOMS={marketing:'marketing',creative:'marketing',research:'finance',finance:'finance',outreach:'sales',sales:'sales',execution:'ops',operations:'ops',ops:'ops',support:'support',lounge:'lounge'};
function taskRoom(agent,tasks){const t=tasks.filter(t=>t.assignee===agent.id&&t.status==='running').sort((a,b)=>String(b.startedAt||b.createdAt).localeCompare(String(a.startedAt||a.createdAt)))[0];return t&&TASK_CATEGORY_ROOMS[t.category]||agent.room||null;}
async function fullState() {
  { const c = CACHES.get(wsId()); if (c && Date.now() - c.t < 1500) return {...c.v,now:now()}; }
  const agents = await listAgents();
  const ids = await r(['SMEMBERS', 'fm:reqs']);
  const parse = a => (a || []).filter(Boolean).map(x => JSON.parse(x));
  const pend = ids.length ? parse(await r(['MGET', ...ids.map(i => 'fm:req:' + i)])).map(pub) : [];
  const hist = parse(await r(['LRANGE', 'fm:reqhist', 0, 14]));
  const day = now().slice(0, 10);
  const sp = agents.length ? await r(['MGET', ...agents.map(a => `fm:spend:${a.id}:${day}`)]) : [];
  const sts = agents.length ? await r(['MGET', ...agents.map(a => 'fm:st:' + a.id)]) : []; const tasks = await listTasks();
  const connections=await Promise.all(agents.map(connectionState));const conversations=await Promise.all(agents.map(a=>getJ('fm:conversation:'+a.id)));
  const agentsPub = agents.map((a, i) => ({ ...a, visibleRoom:taskRoom(a,tasks), ownerConversation:conversations[i]?.epoch===(a.oauthEpoch||0)?conversations[i]:null, connection:connections[i], spentTodayCents: parseInt(sp[i] || '0', 10), state: sts[i] ? JSON.parse(sts[i]) : null })).filter(a => !a.harness);
  const [kill, receipts, events, notes] = await Promise.all([r(['GET', 'fm:kill']), r(['LRANGE', 'fm:receipts', 0, 59]), r(['LRANGE', 'fm:events', 0, 79]), r(['LRANGE', 'fm:notes', 0, 9])]);
  const v = { now: now(), killed: !!kill, actions: ACTIONS, agents: agentsPub, requests: [...pend, ...hist].sort((a, b) => a.createdAt < b.createdAt ? 1 : -1), receipts: parse(receipts), events: parse(events), notes: parse(notes), tasks, kinds: KINDS, providers: PROVIDERS };
  CACHES.set(wsId(), { t: Date.now(), v }); return v;
}
async function finishReq(q) { bust(); await setJ('fm:req:' + q.id, q); await r(['SREM', 'fm:reqs', q.id]); await r(['LPUSH', 'fm:reqhist', JSON.stringify(pub(q))]); await r(['LTRIM', 'fm:reqhist', 0, 29]); }
async function createAgent(name, role, provider, harness, opts) { opts = opts || {};
  const id = rid('agent'); const key = 'fmk_' + crypto.randomBytes(20).toString('hex');
  const agent = { id, name: String(name || 'Agent').slice(0, 40), role: String(role || '').slice(0, 60), provider: (PROVIDERS.find(p => p.id === provider) || { name: 'Custom agent' }).name, providerId: provider || 'custom', harness: !!harness, status: 'active', permissions: { ...(PRESETS[opts.preset] || DEFAULT_PERMS) }, hosted: !!opts.hosted, model: opts.model || null, limits: { perActionCents: 10, dailyCents: 50 }, createdAt: now(), lastSeen: null, keyHint: key.slice(0, 8) + '...' + key.slice(-4) };
  bust(); await setJ('fm:agent:' + id, agent); await r(['SET','fm:gatewayKeyHash:'+id,sha(key)]); await r(['SET', 'fm:key:' + sha(key), id]); await r(['SET', 'gl:key:' + sha(key), wsId()]); await r(['SADD', 'fm:agents', id]);
  await event(id, 'prepared', `${agent.name} connection prepared; waiting for the bot`);
  return { agent, key };
}

// ---------- the live demo agent ("Scout"): a real client of the gateway. Each tick it makes real calls over HTTP with its own key. ----------
const SCOUT_TASKS = [
  { action: 'web.fetch', params: () => ({ url: 'https://api.github.com/repos/roycemy/blackbox-mvp' }), note: 'Check the repo status' },
  { action: 'notes.write', params: s => ({ title: 'Scout report #' + (s.n + 1), text: 'Scout checked github.com/roycemy/blackbox-mvp at ' + now() + '. Foreman gated this write.' }), note: 'File a research note' },
  { action: 'notes.delete', params: () => ({}), note: 'Tidy up old notes' },
];
async function scoutTick(origin) {
  let st = (await getJ('fm:scout:state')) || { n: 0, pending: null, log: [] };
  const key = await r(['GET', 'fm:scout:key']); if (!key) return { error: 'scout not seeded' };
  const call = async (path, method, body) => { const res = await fetch(origin + path, { method, headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }); return { http: res.status, json: await res.json() }; };
  let step;
  if (st.pending) {
    const g = await call('/api/gateway/requests/' + st.pending, 'GET');
    step = { kind: 'poll', request: st.pending, status: g.json.status };
    if (g.json.status !== 'pending') { st.pending = null; st.n++; }
  } else {
    const t = SCOUT_TASKS[st.n % SCOUT_TASKS.length];
    const g = await call('/api/gateway/act', 'POST', { action: t.action, params: t.params(st), note: t.note });
    step = { kind: 'act', action: t.action, http: g.http, status: g.json.status, code: g.json.code };
    if (g.json.status === 'pending') st.pending = g.json.request_id; else st.n++;
  }
  st.log = [{ at: now(), ...step }, ...st.log].slice(0, 20); await setJ('fm:scout:state', st);
  return { step, scout: { n: st.n, pending: st.pending } };
}
async function seed() {
  if (SEEDED) return; if (await r(['GET', 'fm:seeded'])) { SEEDED = true; const sid = await r(['GET', 'fm:scout:id']); const sa = sid && await getJ('fm:agent:' + sid); if (sa && !sa.harness) { await updateAgent(sid,a=>{a.harness=true;}); } return; } SEEDED = true;
  const { agent, key } = await createAgent('Scout', 'Research agent (live)', 'custom', true);
  await updateAgent(agent.id,a=>{a.provider='Foreman live agent';a.live=true;});
  await r(['SET', 'fm:scout:key', key]); await r(['SET', 'fm:scout:id', agent.id]); await r(['SET', 'fm:seeded', '1']);
}

// ---------- MCP adapter (JSON-RPC 2.0 over HTTPS) ----------
const MCP_TOOLS = [
  { name: 'foreman_web_fetch', description: 'Fetch a live https web page through Foreman (policy-gated).', inputSchema: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] }, action: 'web.fetch' },
  { name: 'foreman_notes_write', description: 'Write a note to the shared workspace through Foreman (policy-gated; may pause for owner approval).', inputSchema: { type: 'object', properties: { title: { type: 'string' }, text: { type: 'string' } }, required: ['title', 'text'] }, action: 'notes.write' },
  { name: 'foreman_notes_delete', description: 'Delete workspace notes through Foreman (policy-gated).', inputSchema: { type: 'object', properties: {} }, action: 'notes.delete' },
  { name: 'foreman_enqueue', description: 'Queue an unassigned task in your own workspace. This does not start a hosted worker. Policy-gated, zero cost, maximum 10 per minute.', inputSchema: { type: 'object', properties: { title: { type: 'string' }, brief: { type: 'string' } }, required: ['title'] }, action: 'work.enqueue' },
  { name: 'foreman_handoff', description: 'Hand a task to another Foreman agent.', inputSchema: { type: 'object', properties: { task_id: { type: 'string' }, to: { type: 'string' }, brief: { type: 'string' } }, required: ['task_id', 'to'] }, action: 'work.handoff' },
  { name: 'foreman_report', description: 'Report your activity. kind is one of ' + KINDS.join(', '), inputSchema: { type: 'object', properties: { kind: { type: 'string' }, text: { type: 'string' } }, required: ['kind'] } },
  {name:'foreman_chat_task',description:'Register a task you have actually begun from an owner chat. Does not execute work or infer from text.',inputSchema:{type:'object',properties:{source_id:{type:'string'},title:{type:'string'},brief:{type:'string'},parent_id:{type:'string',description:'Optional parent job you own, for hub sub-jobs.'},assignee:{type:'string',description:'Target bot ID. Another bot creates a policy-gated queued assignment, not running work.'},category:{type:'string',description:'Explicit task category: marketing/creative, research/finance, outreach/sales, execution/operations/ops, support or lounge. Routes visible room during running task without changing home.'}},required:['source_id','title']}},
  {name:'foreman_route_suggestion',description:'Suggest a bot using retained reported job outcomes by category. No assignment or guarantee.',inputSchema:{type:'object',properties:{category:{type:'string'}},required:['category']}},
  {name:'foreman_inbox',description:'Read your assigned jobs and jobs you assigned. Does not claim work.',inputSchema:{type:'object',properties:{}}},
  {name:'foreman_teammates',description:'List active external bots in your workspace for explicit job assignment.',inputSchema:{type:'object',properties:{}}},
  {name:'foreman_read_task',description:'Read your task or the result of a task you delegated.',inputSchema:{type:'object',properties:{task_id:{type:'string'}},required:['task_id']}},
  {name:'alter_broker_request',description:'Request exact owner review for a server-executed route. No credentials released. Only fixture.echo executes; paid xai.chat is disabled. Not native-provider interception.',inputSchema:{type:'object',properties:{sourceId:{type:'string'},taskId:{type:'string'},route:{type:'string',enum:['fixture.echo','xai.chat']},input:{type:'string'},maxCents:{type:'integer'}},required:['sourceId','taskId','route','input','maxCents']}},
  {name:'alter_broker_check',description:'Read your broker request result. Approval executes once; never resubmit it.',inputSchema:{type:'object',properties:{requestId:{type:'string'}},required:['requestId']}},
  {name:'blackbox_card_proposal',description:'Request an owner decision for a synthetic card purchase. No real money moves.',inputSchema:{type:'object',properties:{sourceId:{type:'string'},merchant:{type:'string'},amountCents:{type:'integer'},currency:{type:'string',enum:['USD']},purpose:{type:'string'}},required:['sourceId','merchant','amountCents','currency','purpose']}},
  {name:'foreman_owner_conversation',description:'Report an actual owner conversation start, update or end. Never call on a schedule, notification read, connection or idle heartbeat. No chat content. Start sequence 1; increment per real event; retry the same event_id. With-you expires after 60s without a real update.',inputSchema:{type:'object',properties:{session_id:{type:'string'},event_id:{type:'string'},sequence:{type:'integer',minimum:1},phase:{type:'string',enum:['start','update','end']}},required:['session_id','event_id','sequence','phase']}},
  {name:'foreman_presence',description:'Report actual recent interaction with your owner. Does not claim work is running.',inputSchema:{type:'object',properties:{}}},
  { name: 'foreman_next_task', description: 'Claim the next task from the Foreman work bus.', inputSchema: { type: 'object', properties: {} } },
  { name: 'foreman_complete_task', description: 'Finish a task and store its result. Optionally report what your own model usage for this task cost, in USD.', inputSchema: { type: 'object', properties: { task_id: { type: 'string' }, result: { type: 'string' }, model_cost_usd: { type: 'number', description: 'Your model/API cost for this task in USD, if you know it. Leave it out if unknown; never estimate.' } }, required: ['task_id', 'result'] } },
  {name:'foreman_notifications',description:'Read your own approval/completion/block/failure events. Read-only, no task claim or presence. Persist nextCursor and pass after on later calls; cursor_expired requires an explicit reset. Notification delivery is the client automation responsibility.',inputSchema:{type:'object',properties:{after:{type:'string'}}}},
  { name: 'foreman_check_request', description: 'Check a paused (ASK) request. Once approved Foreman has already run it; the result is included.', inputSchema: { type: 'object', properties: { request_id: { type: 'string' } }, required: ['request_id'] } },
];
for(const t of MCP_TOOLS.filter(t=>t.action)){t.inputSchema.properties.task_id={type:'string',description:'Active job ID. Required when this worker uses job-scoped permissions. Grant check rides this action call.'};}
async function mcpCall(agent, name, args) {
  const t = MCP_TOOLS.find(x => x.name === name); if (!t) return { isError: true, content: [{ type: 'text', text: 'unknown tool' }] };
  let out;
  if (t.action) { const g = await gatewayAct(agent, { action: t.action, params: args || {},task_id:args?.task_id }); out = g.body; }
  else if (name === 'foreman_report') out = (await reportEvent(agent, args || {}, 'mcp')).body;
  else if(name==='foreman_chat_task')out=(await chatTask(agent,args||{})).body;
  else if(name==='foreman_route_suggestion')out=await routing((args||{}).category||'');
  else if(name==='foreman_inbox')out={tasks:await inbox(agent)};
  else if(name==='foreman_teammates')out={bots:await teammates()};
  else if(name==='foreman_read_task'){const task=await taskForAgent(agent,(args||{}).task_id);out=task?{task}:{error:'not found'};}
  else if(name==='alter_broker_request')out=(await brokerRequest(agent,args||{})).body;
  else if(name==='alter_broker_check'){const q=await getJ('fm:broker:q:'+(args||{}).requestId);out=q&&q.agentId===agent.id?{request:brokerPublic(q)}:{error:'not found'};}
  else if(name==='blackbox_card_proposal')out=(await cardPropose(await getJ('fm:agent:'+agent.id),args||{})).body;
  else if(name==='foreman_owner_conversation')out=(await ownerConversation(agent,args||{},'mcp')).body;
  else if(name==='foreman_presence'){if(agent.status!=='active'||await r(['GET','fm:kill']))out={status:'blocked'};else{await touchAgent(agent);await event(agent.id,'interaction','Available: interacting with owner',{kind:'INTERACTION',source:'mcp'});out={status:'ok'};}}
  else if (name === 'foreman_next_task') { if (agent.status !== 'active') out = { status: 'blocked', reason: 'Access revoked by owner' }; else out = { task: await claimTask(agent) }; }
  else if (name === 'foreman_complete_task') out = (await completeTask(agent, (args || {}).task_id, args || {})).body;
  else if(name==='foreman_notifications')out=(await notifications(agent,(args||{}).after)).body;
  else if (name === 'foreman_check_request') { const q = await getJ('fm:req:' + (args || {}).request_id); out = q && q.agentId === agent.id ? pub(q) : { error: 'not found' }; }
  return { isError: ['blocked', 'failed'].includes(out && out.status), content: [{ type: 'text', text: JSON.stringify(out) }] };
}
async function mcpHandle(agent, m) {
  const ok = result => ({ jsonrpc: '2.0', id: m.id, result });
  if (m.method === 'initialize') {await touchAgent(agent);await event(agent.id,'interaction','MCP client connected',{kind:'INTERACTION',source:'mcp'});return ok({ protocolVersion: '2025-03-26', capabilities: { tools: {} }, serverInfo: { name: 'foreman', version: '9.0.0' } });}
  if (m.method === 'tools/list') return ok({ tools: MCP_TOOLS.map(({ action, ...t }) => t) });
  if (m.method === 'tools/call') return ok(await mcpCall(agent, m.params && m.params.name, m.params && m.params.arguments));
  if (m.method === 'ping') return ok({});
  if (m.id === undefined) return null;
  return { jsonrpc: '2.0', id: m.id, error: { code: -32601, message: 'method not found' } };
}
// ---------- spend review scaffold: NO payment execution ----------
// Records owner intent only. No provider adapter or execution token exists here.
async function listSpendRequests(){const ids=(await r(['SMEMBERS','fm:spendRequests']));if(!ids.length)return [];return (await r(['MGET',...ids.map(id=>'fm:spendRequest:'+id)])).filter(Boolean).map(JSON.parse).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,300);}
async function spendSummary(){const requests=await listSpendRequests(),bots={};for(const q of requests){const b=bots[q.agentId]||(bots[q.agentId]={agentId:q.agentId,agentName:q.agentName,requestedCents:0,approvedCents:0,deniedCents:0,chargedCents:0,pendingCount:0});b.requestedCents+=q.amountCents;if(q.status==='approved_not_connected')b.approvedCents+=q.amountCents;if(q.status==='denied')b.deniedCents+=q.amountCents;if(q.status==='pending_review')b.pendingCount++;}return {paymentConnected:false,notificationConnected:false,currency:'USD',requests,bots:Object.values(bots),receipts:requests.filter(q=>q.decisionReceipt).map(q=>q.decisionReceipt),metricsScope:'Latest 300 requests. Approved amounts are intent, not charges.'};}
async function newSpendRequest(agent,body){
 const a=await getJ('fm:agent:'+agent.id);if(!a||a.status!=='active'||await r(['GET','fm:kill']))return {status:403,body:{error:'Worker is off; no spend request accepted'}};
 const text=(v,n)=>typeof v==='string'&&v.trim().length>0&&v.trim().length<=n;
 if(!Number.isSafeInteger(body.amountCents)||body.amountCents<=0||body.amountCents>100000000||body.currency!=='USD'||!text(body.merchant,120)||!text(body.accountLabel,120)||!text(body.purpose,500)||!text(body.undoTerms,500)||!text(body.sourceId,120))return {status:400,body:{error:'USD amountCents (positive integer), merchant, accountLabel, purpose, undoTerms and sourceId are required'}};
 if(body.taskId){const t=await getJ('fm:task:'+body.taskId);if(!t||t.assignee!==a.id)return {status:400,body:{error:'Task must belong to this worker'}};}
 const details={taskId:body.taskId||null,amountCents:body.amountCents,currency:'USD',merchant:body.merchant.trim(),accountLabel:body.accountLabel.trim(),purpose:body.purpose.trim(),undoTerms:body.undoTerms.trim()};
 const id='spend_'+sha(a.id+':'+body.sourceId).slice(0,24),key='fm:spendRequest:'+id,existing=await getJ(key);
 if(existing)return {status:sha(JSON.stringify(existing.details))===sha(JSON.stringify(details))?200:409,body:sha(JSON.stringify(existing.details))===sha(JSON.stringify(details))?{request:existing}:{error:'sourceId already has different spend details'}};
 const q={id,agentId:a.id,agentName:a.name,...details,details,detailsHash:sha(JSON.stringify(details)),status:'pending_review',createdAt:now(),expiresAt:new Date(Date.now()+86400000).toISOString(),paymentConnected:false,notificationStatus:'in_app_only',chargedCents:0};
 const won=await r(['SET',key,JSON.stringify(q),'NX']);if(!won){const old=await getJ(key);return {status:old.detailsHash===q.detailsHash?200:409,body:old.detailsHash===q.detailsHash?{request:old}:{error:'sourceId conflict'}};}
 await r(['SADD','fm:spendRequests',id]);bust();return {status:201,body:{request:q}};
}
async function reviewSpend(id,decision,detailsHash){const key='fm:spendRequest:'+id;
 for(let attempt=0;attempt<8;attempt++){const raw=await r(['GET',key]);if(!raw)return {status:404,body:{error:'not found'}};const q=JSON.parse(raw);
 if(q.detailsHash!==detailsHash)return {status:409,body:{error:'Spend details changed; review this request again'}};
 if(q.status!=='pending_review')return {status:200,body:{request:q}};
 const a=await getJ('fm:agent:'+q.agentId),blocked=!a||a.status!=='active'||await r(['GET','fm:kill']);
 q.status=decision==='deny'?'denied':Date.parse(q.expiresAt)<=Date.now()?'expired':blocked?'blocked':'approved_not_connected';q.decidedAt=now();q.decisionReceipt={id:'review_'+id,at:q.decidedAt,requestId:id,agentId:q.agentId,agentName:q.agentName,merchant:q.merchant,amountCents:q.amountCents,currency:q.currency,outcome:q.status,chargedCents:0,kind:'decision_record',detailsHash:q.detailsHash,note:'Decision record only. No payment connection, no charge and no vendor receipt.'};
 const won=await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(q)]);if(won===1){bust();return {status:200,body:{request:q,receipt:q.decisionReceipt}};}}
 return {status:409,body:{error:'Another decision is being saved; refresh'}};
}

// Synthetic card rails. Separate from gateway policy and existing money decisions.
// Provider contract: execute({id, amountCents, currency, merchant, purpose, botId}).
// Real providers are deliberately not selectable or credentialed in this build.
const CARD_PROVIDER = Object.freeze({id:'sandbox', live:false, async execute(q){
 return {provider:'sandbox',providerReference:'sim_'+q.id,simulatedCents:q.amountCents,chargedCents:0,currency:q.currency};
}});
// The sandbox card's identity (last four digits) is generated once per workspace. It is not an issued card.
async function sandboxCard(){let c=await getJ('fm:cards:card');if(!c){await r(['SET','fm:cards:card',JSON.stringify({last4:String(crypto.randomInt(0,10000)).padStart(4,'0'),label:'Team card',kind:'virtual',issued:false,createdAt:now()}),'NX']);c=await getJ('fm:cards:card');}return c;}
async function cardData(){
 const ids=await r(['SMEMBERS','fm:cards:proposals']);
 const proposals=ids.length?(await r(['MGET',...ids.map(id=>'fm:cards:q:'+id)])).filter(Boolean).map(JSON.parse).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)):[];
 return {mode:'sandbox',liveMoneyEnabled:false,provider:'sandbox',card:await sandboxCard(),day:now().slice(0,10),killed:!!await r(['GET','fm:cards:kill']),proposals,ledger:proposals.filter(q=>q.receipt).map(q=>q.receipt),bots:await Promise.all((await listAgents()).map(async a=>({id:a.id,name:a.name,status:a.status,dailyLimitCents:Number((await r(['GET','fm:cards:cap:'+a.id]))??10000),trust:AUTHZ.trust(proposals.filter(q=>q.botId===a.id)),policy:await getJ('fm:cards:policy:'+a.id)||{},simulatedTodayCents:Number(await r(['GET','fm:cards:spent:'+a.id+':'+now().slice(0,10)])||0)})))};
}
async function cardPropose(a,b){
 if(!a||a.status!=='active'||await r(['GET','fm:kill'])||await r(['GET','fm:cards:kill']))return {status:403,body:{error:'Card proposals paused or worker revoked'}};
 if(!Number.isSafeInteger(b.amountCents)||b.amountCents<1||b.amountCents>100000000||b.currency!=='USD'||!['merchant','purpose','sourceId'].every(k=>typeof b[k]==='string'&&b[k].trim().length>0&&b[k].length<=500))return {status:400,body:{error:'Exact USD cents, merchant, purpose and sourceId required'}};
 if(b.taskId!=null&&(typeof b.taskId!=='string'||!/^task_[a-f0-9]+$/.test(b.taskId)))return {status:400,body:{error:'Valid job id required'}};
 if(b.category!=null&&(!['software','advertising','travel','supplies','uncategorized'].includes(b.category)))return {status:400,body:{error:'Unsupported merchant category'}};
 const details={botId:a.id,merchant:b.merchant.trim(),amountCents:b.amountCents,currency:'USD',purpose:b.purpose.trim(),taskId:b.taskId||null,category:b.category||'uncategorized'},hash=sha(JSON.stringify(details)),id='card_'+sha(a.id+':'+b.sourceId).slice(0,24),key='fm:cards:q:'+id;
 const q={id,...details,detailsHash:hash,botName:a.name,status:'pending',mode:'sandbox',createdAt:now(),expiresAt:new Date(Date.now()+86400000).toISOString(),chargedCents:0};
 q.authorization=await cardAuthorization(q,false);
 const won=await r(['SET',key,JSON.stringify(q),'NX']);const old=won?q:await getJ(key);if(old.detailsHash!==hash)return {status:409,body:{error:'sourceId has different details'}};
 await r(['SADD','fm:cards:proposals',id]);return {status:won?201:200,body:{proposal:old}};
}
async function cardDecision(id,decision,hash){const q=await getJ('fm:cards:q:'+id);return q?.taskId?withJobLock(q.taskId,()=>cardDecisionUnlocked(id,decision,hash)):cardDecisionUnlocked(id,decision,hash);}
async function cardAuthorization(q,ownerApproved){
 const a=await getJ('fm:agent:'+q.botId),day=now().slice(0,10),policy=await getJ('fm:cards:policy:'+q.botId)||{};
 const ids=await r(['SMEMBERS','fm:cards:proposals']),records=ids.length?(await r(['MGET',...ids.map(id=>'fm:cards:q:'+id)])).filter(Boolean).map(JSON.parse):[];
 return AUTHZ.evaluate(q,{active:a?.status==='active',paused:!!a?.paused,killed:!!await r(['GET','fm:kill'])||!!await r(['GET','fm:cards:kill']),expired:Date.parse(q.expiresAt)<=Date.now(),policy,ownerApproved,jobRequired:a?.permissionScope==='job',job:q.taskId?await getJ('fm:task:'+q.taskId):null,spentToday:Number(await r(['GET','fm:cards:spent:'+q.botId+':'+day])||0),dailyLimit:Number((await r(['GET','fm:cards:cap:'+q.botId]))??10000),recentCount:records.filter(x=>x.botId===q.botId&&['simulated','executing_sandbox'].includes(x.status)&&Date.parse(x.decidedAt||x.createdAt)>Date.now()-3600000).length});
}
async function cardDecisionUnlocked(id,decision,hash){
 const key='fm:cards:q:'+id;
 // Serialize all sandbox decisions in the workspace, including cap changes and kill.
 const lock='fm:cards:lock',lockToken=rid('lock');if(!await r(['SET',lock,lockToken,'NX','EX',60]))return {status:409,body:{error:'Another card change is saving. Try again.'}};
 try{
 const q=await getJ(key);if(!q)return {status:404,body:{error:'not found'}};
 if(q.detailsHash!==hash)return {status:409,body:{error:'Review exact details again'}};
 if(q.status!=='pending')return {status:200,body:{proposal:q}};
 const a=await getJ('fm:agent:'+q.botId),day=now().slice(0,10),spentKey='fm:cards:spent:'+q.botId+':'+day,spent=Number(await r(['GET',spentKey])||0),cap=Number((await r(['GET','fm:cards:cap:'+q.botId]))??10000);
 q.authorization=decision==='deny'?{version:AUTHZ.VERSION,decision:'DENY',code:'owner_denied',reason:'Owner denied exact request',chargedCents:0}:await cardAuthorization(q,true);
 q.status=decision==='deny'?'denied':q.authorization.code==='expired'?'expired':q.authorization.decision==='DENY'?(q.authorization.code.startsWith('limit_')?'limit_blocked':'blocked'):'executing_sandbox';
 // Persist admission before provider invocation. A crash stays visibly unresolved, never recharged.
 if(q.status==='executing_sandbox'){await setJ(key,q);const out=await CARD_PROVIDER.execute(q);q.providerResult=out;q.status='simulated';await r(['INCRBY',spentKey,q.amountCents]);if(q.taskId){const t=await getJ('fm:task:'+q.taskId);t.sandboxGrant.spentCents+=q.amountCents;await setJ('fm:task:'+q.taskId,t);}}
 q.decidedAt=now();q.receipt={id:'ledger_'+q.id,requestId:q.id,at:q.decidedAt,botId:q.botId,botName:q.botName,merchant:q.merchant,purpose:q.purpose,amountCents:q.amountCents,currency:q.currency,outcome:q.status,provider:'sandbox',detailsHash:q.detailsHash,authorization:q.authorization,taskId:q.taskId||null,simulatedCents:q.status==='simulated'?q.amountCents:0,chargedCents:0,note:'Synthetic ledger. No card issued, no funds moved, no vendor receipt.'};
 await setJ(key,q);return {status:200,body:{proposal:q,receipt:q.receipt}};
 }finally{if(await r(['GET',lock])===lockToken)await r(['DEL',lock]);}
}
async function cardControl(body){return body.taskId?withJobLock(body.taskId,()=>cardControlUnlocked(body)):cardControlUnlocked(body);}
async function cardControlUnlocked(body){
 if(body.policy){const p=body.policy;if(typeof p!=='object'||Array.isArray(p)||Object.keys(p).some(k=>!['perActionCents','allowedCategories','maxPerHour'].includes(k))||p.perActionCents!=null&&(!Number.isSafeInteger(p.perActionCents)||p.perActionCents<0)||p.maxPerHour!=null&&(!Number.isSafeInteger(p.maxPerHour)||p.maxPerHour<1||p.maxPerHour>1000)||p.allowedCategories!=null&&(!Array.isArray(p.allowedCategories)||p.allowedCategories.some(c=>!['software','advertising','travel','supplies','uncategorized'].includes(c))))return {status:400,body:{error:'Invalid sandbox rules'}};}
 if((body.policy||body.taskId)&&!body.botId)return {status:400,body:{error:'Bot required'}};
 if(body.taskId){const t=await getJ('fm:task:'+body.taskId);if(!t||t.assignee!==body.botId||t.status!=='running'||body.confirmed!==true||!Number.isSafeInteger(body.budgetCents)||body.budgetCents<Number(t.sandboxGrant?.spentCents||0)||body.budgetCents>100000000)return {status:400,body:{error:'Review running job, bot and exact sandbox budget; cannot reduce below used cents'}};}
 if(body.dailyLimitCents!=null&&(!Number.isSafeInteger(body.dailyLimitCents)||body.dailyLimitCents<0||body.dailyLimitCents>100000000))return {status:400,body:{error:'Daily limit must be integer cents'}};
 if(body.botId&&!await getJ('fm:agent:'+body.botId))return {status:404,body:{error:'Unknown bot'}};
 const lock='fm:cards:lock',lockToken=rid('lock');if(!await r(['SET',lock,lockToken,'NX','EX',60]))return {status:409,body:{error:'Another card change is saving. Try again.'}};
 try{if(body.policy)await setJ('fm:cards:policy:'+body.botId,body.policy);if(body.taskId){const t=await getJ('fm:task:'+body.taskId);t.sandboxGrant={botId:body.botId,status:'active',budgetCents:body.budgetCents,spentCents:Number(t.sandboxGrant?.spentCents||0),issuedAt:now(),note:'Sandbox spend only. Not gateway ledger or payment authorization.'};await setJ('fm:task:'+t.id,t);}
 if(typeof body.killed==='boolean'){if(body.killed)await r(['SET','fm:cards:kill','1']);else await r(['DEL','fm:cards:kill']);}
 if(body.botId&&body.dailyLimitCents!=null)await r(['SET','fm:cards:cap:'+body.botId,body.dailyLimitCents]);return {status:200,body:await cardData()};}finally{if(await r(['GET',lock])===lockToken)await r(['DEL',lock]);}
}


// OAuth for outbound MCP connections. Providers never lend us their account password.
const OAUTH_ORIGIN='https://foreman-core.vercel.app';
const validRedirect=u=>{try{const x=new URL(u);return !x.username&&!x.password&&!x.hash&&(x.protocol==='https:'||x.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(x.hostname));}catch{return false;}};
// Refresh grants have no routine expiry. Rotation is atomic; replay revokes the family.
// Raw refresh secrets are never persisted. Owner revoke increments the bot epoch.
async function revokeOAuthGrant(id){
 const key='gl:oauth:grant:'+id;
 for(let n=0;n<8;n++){const raw=await r(['GET',key]),g=raw&&JSON.parse(raw);if(!g||g.revoked)return;
 if(await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify({...g,revoked:true,revokedAt:now(),failureReason:'refresh_replay',failedAt:now()})])===1){CACHES.delete(g.ws);return;}}
 throw new Error('Concurrent connector update; retry');
}
// Owner-visible state derives from grants, never from a stale heartbeat alone.
async function connectionState(a){
 if(a.hosted)return {status:'not_applicable',persistent:false};
 if(a.status!=='active')return {status:'revoked',persistent:false};
 const gateway=await getJ('fm:gatewaySeen:'+a.id);
 const ids=await r(['SMEMBERS','fm:oauth:grants:'+a.id]);
 const grants=(await Promise.all(ids.map(id=>getJ('gl:oauth:grant:'+id)))).filter(g=>g&&g.ws===wsId()&&g.agentId===a.id&&g.epoch===(a.oauthEpoch||0));
 const live=grants.filter(g=>!g.revoked).sort((a,b)=>String(b.renewedAt||b.createdAt).localeCompare(String(a.renewedAt||a.createdAt)));
 if(live.length)return {status:'active',persistent:true,authorizedAt:live[0].createdAt,lastRenewedAt:live[0].renewedAt||null};
 if(a.connectionMode==='gateway')return gateway&&gateway.epoch===(a.oauthEpoch||0)?{status:'active',transport:'gateway',persistent:false,authorizedAt:gateway.seenAt}:{status:'awaiting_bot',transport:'gateway',persistent:false,reason:'gateway_call_pending'};
 const failed=grants.filter(g=>g.failureReason).sort((a,b)=>String(b.failedAt).localeCompare(String(a.failedAt)))[0];
 const seen=a.lastSeen||await r(['GET','fm:seen:'+a.id]),legacy=await getJ('fm:oauth:legacy:'+a.id),knownLegacy=legacy&&legacy.epoch===(a.oauthEpoch||0);
 return {status:failed||knownLegacy||ids.length?'needs_reauth':seen?'verification_pending':'awaiting_bot',persistent:seen&&!failed&&!knownLegacy&&!ids.length?null:false,reason:failed?failed.failureReason:knownLegacy||ids.length?'persistent_grant_missing':seen?'grant_index_not_verified':'authorization_pending',failedAt:failed?failed.failedAt:null,reconnectEndpoint:'/api/agents/'+a.id+'/reconnect',requiresClientParameters:true};
}
async function reconnectAgent(id,body){
 const a=await getJ('fm:agent:'+id);if(!a)return {status:404,body:{error:'not_found'}};
 if(a.status!=='active'||a.hosted)return {status:409,body:{error:'bot_not_available'}};
 if(!body.client_id||!body.redirect_uri||!body.code_challenge)return {status:409,body:{error:'client_reconnect_required',agentId:id,requires:['client_id','redirect_uri','code_challenge','code_challenge_method'],connection:await connectionState(a)}};
 const client=await getJ('gl:oauth:client:'+body.client_id);
 if(!client||!client.redirect_uris.includes(body.redirect_uri)||body.code_challenge_method!=='S256'||!/^[A-Za-z0-9_-]{43}$/.test(body.code_challenge))return {status:400,body:{error:'invalid_client_parameters'}};
 const params=new URLSearchParams({client_id:body.client_id,redirect_uri:body.redirect_uri,response_type:'code',code_challenge_method:'S256',code_challenge:body.code_challenge,scope:'blackbox.bot',resource:OAUTH_ORIGIN+'/api/mcp',agent_id:id});
 if(body.state)params.set('state',String(body.state));
 return {status:200,body:{agentId:id,authorizationUrl:OAUTH_ORIGIN+'/oauth/authorize?'+params.toString(),createsBot:false}};
}
async function oauthRoutes(req,res,path,body){
 const send=(n,b)=>res.status(n).json(b),url=new URL(req.url,OAUTH_ORIGIN),params=Object.fromEntries(url.searchParams);
 if(path==='/.well-known/oauth-protected-resource'||path==='/.well-known/oauth-protected-resource/api/mcp')return send(200,{resource:OAUTH_ORIGIN+'/api/mcp',authorization_servers:[OAUTH_ORIGIN],scopes_supported:['blackbox.bot'],bearer_methods_supported:['header']});
 if(path==='/.well-known/oauth-authorization-server')return send(200,{issuer:OAUTH_ORIGIN,authorization_endpoint:OAUTH_ORIGIN+'/oauth/authorize',token_endpoint:OAUTH_ORIGIN+'/api/oauth/token',registration_endpoint:OAUTH_ORIGIN+'/api/oauth/register',response_types_supported:['code'],grant_types_supported:['authorization_code','refresh_token'],code_challenge_methods_supported:['S256'],token_endpoint_auth_methods_supported:['none'],scopes_supported:['blackbox.bot']});
 if(path==='/oauth/register'&&req.method==='POST'){
 if(!Array.isArray(body.redirect_uris)||body.redirect_uris.length<1||body.redirect_uris.length>5||!body.redirect_uris.every(validRedirect))return send(400,{error:'invalid_redirect_uri'});
 const ip=String(req.headers['x-forwarded-for']||'local').split(',')[0],n=await r(['INCRBY','gl:oauth:rate:'+sha(ip),1]);await r(['EXPIRE','gl:oauth:rate:'+sha(ip),3600]);if(n>30)return send(429,{error:'rate_limited'});
 const c={client_id:rid('client'),client_name:String(body.client_name||'MCP client').slice(0,100),redirect_uris:body.redirect_uris,token_endpoint_auth_method:'none',grant_types:['authorization_code','refresh_token'],response_types:['code']};await setJ('gl:oauth:client:'+c.client_id,c);return send(201,c);
 }
 if(path==='/oauth/context'&&req.method==='GET'){
 const c=await getJ('gl:oauth:client:'+params.client_id);if(!c||!c.redirect_uris.includes(params.redirect_uri)||params.response_type!=='code'||params.code_challenge_method!=='S256'||!/^[A-Za-z0-9_-]{43}$/.test(params.code_challenge||''))return send(400,{error:'Invalid sign-in request. Return to your bot and reconnect.'});
 if(params.scope&&params.scope!=='blackbox.bot')return send(400,{error:'invalid_scope'});
 if(params.resource&&params.resource!==OAUTH_ORIGIN+'/api/mcp')return send(400,{error:'invalid_target'});
 const sess=await getSession(req);if(!sess)return send(401,{error:'auth'});
 const csrf=crypto.randomBytes(24).toString('hex');await setJ('gl:oauth:consent:'+sha(csrf),{ws:sess.ws,params,expires:Date.now()+600000});
 const bots=await als.run({ws:sess.ws},listAgents);if(params.agent_id&&!bots.some(a=>a.id===params.agent_id&&a.status==='active'&&!a.hosted&&!a.harness&&!a.live))return send(400,{error:'bot_not_available'});return send(200,{client:c.client_name,redirectOrigin:new URL(params.redirect_uri).origin,bots:bots.filter(a=>a.status==='active'&&!a.hosted&&!a.harness&&!a.live&&(!params.agent_id||a.id===params.agent_id)).map(a=>({id:a.id,name:a.name,provider:a.provider})),csrf});
 }
 if(path==='/oauth/consent'&&req.method==='POST'){
 if(req.headers.origin!==OAUTH_ORIGIN)return send(403,{error:'origin'});
 const sess=await getSession(req),key='gl:oauth:consent:'+sha(String(body.csrf||'')),raw=await r(['GET',key]),v=raw&&JSON.parse(raw);
 if(!sess||!v||v.ws!==sess.ws||v.expires<Date.now())return send(403,{error:'Sign-in expired. Reconnect from your bot.'});
 const won=await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify({used:true})]);if(won!==1)return send(409,{error:'Already authorized'});
 if(v.params.agent_id&&body.agentId!==v.params.agent_id)return send(400,{error:'Choose the existing bot being reconnected'});
 const a=await als.run({ws:sess.ws},()=>getJ('fm:agent:'+body.agentId));if(!a||a.status!=='active'||a.hosted||a.harness||a.live)return send(400,{error:'Choose an existing external bot'});
 const token='fm_oauth_'+crypto.randomBytes(32).toString('hex'),code=crypto.randomBytes(32).toString('hex');
 await setJ('gl:oauth:code:'+sha(code),{ws:sess.ws,agentId:a.id,clientId:v.params.client_id,redirect:v.params.redirect_uri,challenge:v.params.code_challenge,epoch:a.oauthEpoch||0,expires:Date.now()+120000,token:enc(token)});
 const target=new URL(v.params.redirect_uri);target.searchParams.set('code',code);if(v.params.state)target.searchParams.set('state',v.params.state);return send(200,{redirect:target.toString()});
 }
 if(path==='/oauth/token'&&req.method==='POST'){
 res.setHeader('Cache-Control','no-store');res.setHeader('Pragma','no-cache');
 if(body.resource&&body.resource!==OAUTH_ORIGIN+'/api/mcp')return send(400,{error:'invalid_target'});
 if(body.scope&&body.scope!=='blackbox.bot')return send(400,{error:'invalid_scope'});
 if(body.grant_type==='refresh_token'){
 const hash=sha(String(body.refresh_token||'')),ref=await getJ('gl:oauth:refresh:'+hash);
 if(!ref||ref.clientId!==body.client_id)return send(400,{error:'invalid_grant'});
 const key='gl:oauth:grant:'+ref.grantId,raw=await r(['GET',key]),grant=raw&&JSON.parse(raw);
 if(!grant||grant.revoked)return send(400,{error:'invalid_grant'});
 await als.run({ws:grant.ws},()=>r(['SADD','fm:oauth:grants:'+grant.agentId,ref.grantId]));CACHES.delete(grant.ws);
 const a=await als.run({ws:grant.ws},()=>getJ('fm:agent:'+grant.agentId));
 if(!a||a.status!=='active'||grant.epoch!==(a.oauthEpoch||0))return send(400,{error:'invalid_grant'});
 if(grant.current!==hash){await revokeOAuthGrant(ref.grantId);return send(400,{error:'invalid_grant'});}
 const refresh='fm_refresh_'+crypto.randomBytes(32).toString('hex'),nextHash=sha(refresh),token='fm_oauth_'+crypto.randomBytes(32).toString('hex');
 await setJ('gl:oauth:refresh:'+nextHash,{grantId:ref.grantId,clientId:grant.clientId});
 const won=await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify({...grant,current:nextHash,renewedAt:now()})]);
 if(won!==1){await r(['DEL','gl:oauth:refresh:'+nextHash]);await revokeOAuthGrant(ref.grantId);return send(400,{error:'invalid_grant'});}
 await setJ('gl:oauth:token:'+sha(token),{ws:grant.ws,agentId:grant.agentId,grantId:ref.grantId,epoch:grant.epoch,expires:Date.now()+3600000});
 return send(200,{access_token:token,refresh_token:refresh,token_type:'Bearer',expires_in:3600,scope:'blackbox.bot'});
 }
 if(body.grant_type!=='authorization_code')return send(400,{error:'unsupported_grant_type'});
 if(!/^[A-Za-z0-9._~-]{43,128}$/.test(body.code_verifier||''))return send(400,{error:'invalid_grant'});
 const key='gl:oauth:code:'+sha(String(body.code||'')),raw=await r(['GET',key]),c=raw&&JSON.parse(raw),challenge=crypto.createHash('sha256').update(body.code_verifier).digest('base64url');
 if(!c||c.used||c.expires<Date.now()||c.clientId!==body.client_id||c.redirect!==body.redirect_uri||c.challenge!==challenge)return send(400,{error:'invalid_grant'});
 const a=await als.run({ws:c.ws},()=>getJ('fm:agent:'+c.agentId));if(!a||a.status!=='active'||(c.epoch||0)!==(a.oauthEpoch||0))return send(400,{error:'invalid_grant'});
 const won=await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify({used:true})]);if(won!==1)return send(400,{error:'invalid_grant'});
 const token=dec(c.token),refresh='fm_refresh_'+crypto.randomBytes(32).toString('hex'),hash=sha(refresh),grantId=rid('grant'),epoch=a.oauthEpoch||0;
 await setJ('gl:oauth:grant:'+grantId,{ws:c.ws,agentId:c.agentId,clientId:c.clientId,epoch,current:hash,createdAt:now(),revoked:false});
 await als.run({ws:c.ws},()=>r(['SADD','fm:oauth:grants:'+c.agentId,grantId]));CACHES.delete(c.ws);
 await setJ('gl:oauth:refresh:'+hash,{grantId,clientId:c.clientId});
 await setJ('gl:oauth:token:'+sha(token),{ws:c.ws,agentId:c.agentId,grantId,epoch,expires:Date.now()+3600000});
 return send(200,{access_token:token,refresh_token:refresh,token_type:'Bearer',expires_in:3600,scope:'blackbox.bot'});
 }
 return send(404,{error:'not found'});
}

// Public waitlist: explicit request only, no auto-mail or third-party sharing.
async function joinWaitlist(req,res,body){
 res.setHeader('Cache-Control','no-store');
 if(req.method!=='POST')return res.status(405).json({error:'POST required'});
 if(req.headers.origin!==OAUTH_ORIGIN)return res.status(403).json({error:'origin'});
 if(body.website)return res.json({ok:true});
 const email=String(body.email||'').trim().toLowerCase();
 if(email.length>254||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||body.consent!==true)return res.status(400).json({error:'Enter your email and agree to an access update.'});
 const ip=String(req.headers['x-forwarded-for']||req.socket?.remoteAddress||'unknown').split(',')[0].trim();
 const rate='gl:waitlistRate:'+sha(ip)+':'+Math.floor(Date.now()/3600000),n=await r(['INCRBY',rate,1]);await r(['EXPIRE',rate,3600]);
 if(n>10)return res.status(429).json({error:'Too many attempts. Try again later.'});
 const key='gl:waitlist:'+sha(email),entry={email,requestedAt:now(),consent:'Access availability email only',source:'alter-site'};
 const added=await r(['SET',key,JSON.stringify(entry),'NX']);
 if(added)await r(['SADD','gl:waitlist',sha(email)]);
 return res.json({ok:true});
}

// Runner sessions: scoped HttpOnly cookie; bearer stored encrypted server-side only.
// Rolling 30-day idle lifetime. Only an authenticated session restore renews it.
// Saved authorization never manufactures executor presence or work.
const RUNNER_TTL=2592000;
const runnerCookie=(id,token,age=RUNNER_TTL)=>runnerCookieName(id)+'='+token+'; HttpOnly; Secure; SameSite=Strict; Path=/api/runner/'+id+'; Max-Age='+age;
const runnerCookieName=id=>'ar_'+sha(id).slice(0,16);
async function startRunnerSession(res,ws,agentId,key){
 const a=await als.run({ws},()=>getJ('fm:agent:'+agentId));if(!a||a.status!=='active')throw Error('Bot unavailable');
 const token=crypto.randomBytes(32).toString('hex'),csrf=crypto.randomBytes(24).toString('hex');
 await setJ('gl:runner:'+sha(token),{ws,agentId,epoch:a.oauthEpoch||0,key:enc(key),csrf,expires:Date.now()+RUNNER_TTL*1000});await r(['EXPIRE','gl:runner:'+sha(token),RUNNER_TTL]);
 res.setHeader('Set-Cookie',runnerCookie(agentId,token));
 return {agent:{id:a.id,name:a.name},csrf,persistent:true};
}
async function runnerSession(req,id){
 const match=String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(runnerCookieName(id)+'='));if(!match)return null;
 const token=match.slice(match.indexOf('=')+1);if(!/^[a-f0-9]{64}$/.test(token))return null;
 const sess=await getJ('gl:runner:'+sha(token));if(!sess||sess.agentId!==id||sess.expires<=Date.now())return null;
 const a=await als.run({ws:sess.ws},()=>getJ('fm:agent:'+id));if(!a||a.status!=='active'||(a.oauthEpoch||0)!==sess.epoch)return null;
 const key=dec(sess.key),kh=await als.run({ws:sess.ws},()=>r(['GET','fm:gatewayKeyHash:'+id]));if(kh!==sha(key))return null;
 return {...sess,agent:a,tokenHash:sha(token)};
}
async function runnerRoutes(req,res,path,body){
 res.setHeader('Cache-Control','no-store');
 const m=path.match(/^\/runner\/(agent_[a-f0-9]+)\/(.*)$/);if(!m)return res.status(404).json({error:'Runner not found'});
 const id=m[1],action=m[2],sess=await runnerSession(req,id);if(!sess)return res.status(401).json({error:'Runner session unavailable. Pair this bot again.'});
 if(req.headers.origin&&req.headers.origin!==OAUTH_ORIGIN)return res.status(403).json({error:'origin'});
 if(req.headers['sec-fetch-site']==='cross-site')return res.status(403).json({error:'cross-site'});
 if(req.method!=='GET'&&(req.headers.origin!==OAUTH_ORIGIN||req.headers['x-alter-csrf']!==sess.csrf))return res.status(403).json({error:'csrf'});
 if(action==='session'&&req.method==='GET'){
  // Validation above checks exact bot, epoch, gateway key, expiry and request origin.
  // Preserve the token and CSRF value so simultaneous tabs do not invalidate each other.
  const expires=Date.now()+RUNNER_TTL*1000;
  await setJ('gl:runner:'+sess.tokenHash,{ws:sess.ws,agentId:id,epoch:sess.epoch,key:sess.key,csrf:sess.csrf,expires});
  await r(['EXPIRE','gl:runner:'+sess.tokenHash,RUNNER_TTL]);
  const raw=String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(runnerCookieName(id)+'=')).split('=')[1];
  res.setHeader('Set-Cookie',runnerCookie(id,raw));
  const seen=Date.parse(sess.agent.lastSeen||'');
  return res.json({agent:{id:sess.agent.id,name:sess.agent.name},csrf:sess.csrf,persistent:true,authorization:'saved',idleLifetimeSeconds:RUNNER_TTL,expiresAt:new Date(expires).toISOString(),executor:{state:Number.isFinite(seen)&&Date.now()-seen<60000?'recent_presence':'stale',lastSeen:sess.agent.lastSeen||null,staleAfterSeconds:60},note:'Authorization is saved. Executor presence and actual work require the executor to be running; restore does not send presence.'});
 }
 if(action==='disconnect'&&req.method==='POST'){await r(['DEL','gl:runner:'+sess.tokenHash]);res.setHeader('Set-Cookie',runnerCookieName(id)+'=; HttpOnly; Secure; SameSite=Strict; Path=/api/runner/'+id+'; Max-Age=0');return res.json({ok:true});}
 if(!action.startsWith('gateway/'))return res.status(404).json({error:'Runner action unavailable'});
 if(req.headers['x-alter-csrf']!==sess.csrf)return res.status(403).json({error:'csrf'});
 req.gatewayKeyAuth=true;return als.run({ws:sess.ws},()=>routes(req,res,'/'+action,body,sess.agent));
}

// ---------- http ----------

// ---------- bot link: one onboarding + stay-connected flow for Instinct, Grok and Muse ----------
const BL=(()=>{try{return require('./bot-link.js')}catch{return require('./api/bot-link.js')}})(); // vm-loaded tests resolve from repo root
const blStore={get:k=>r(['GET',k]),set:(k,v)=>r(['SET',k,v]),setNX:async(k,v)=>!!(await r(['SET',k,v,'NX'])),del:k=>r(['DEL',k]),sadd:(k,v)=>r(['SADD',k,v]),smembers:k=>r(['SMEMBERS',k])};
async function rejectPendingBrokerFor(agentId){const ids=await r(['SMEMBERS','fm:broker:requests']);let n=0;for(const id of ids){const k='fm:broker:q:'+id,q=await getJ(k);if(q&&q.agentId===agentId&&q.status==='pending'){q.status='blocked';q.reason='bot_revoked';q.decidedAt=now();await setJ(k,q);n++;}}return n;}
const botLink=new BL.BotLink({store:blStore,
 onBotCreated:b=>als.run({ws:b.ws},async()=>(await createAgent(b.name,'Linked bot',b.type,false,{preset:'balanced'})).agent.id),
 onRevoke:b=>b.agentId?als.run({ws:b.ws},async()=>{await updateAgent(b.agentId,x=>{x.status='revoked';x.revokedAt=now();x.oauthEpoch=(x.oauthEpoch||0)+1;});await rejectPendingBrokerFor(b.agentId);}):null,
 onAlert:a=>als.run({ws:a.ws},()=>event(null,'alert',a.kind==='pairing_second_caller'?'A second caller used a pairing link. Pairing cancelled.':'A bot key was used twice. That bot needs a re-paste.',{kind:'ALERT',code:a.kind}))});
const blCaller=req=>({userAgent:String(req.headers['user-agent']||''),ipRegion:String(req.headers['x-vercel-ip-country']||'unknown'),appId:String(req.headers['x-alter-app-id']||'')});
// Bot side. Not open routes: /pair needs a live single-use pairing ID plus the caller secret; /link/call needs a bot key.
async function botLinkBotRoutes(req,res,path,body){res.setHeader('Cache-Control','no-store');const send=o=>res.status(o.status).json(o.body);
 const pm=path.match(/^\/pair\/(pr_[A-Za-z0-9_-]{20,40})$/);
 if(pm&&req.method==='POST')return send(await botLink.hello(pm[1],{nonce:body.nonce,callerSecret:body.callerSecret,fingerprint:blCaller(req),oldKey:body.oldKey||null}));
 if(pm&&req.method==='GET'){const sec=String(req.headers.authorization||'').replace(/^Pairing\s+/i,'');return send(await botLink.pickup(pm[1],{callerSecret:sec}));}
 if(path==='/link/call'&&req.method==='POST'){const key=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'').trim();return send(await botLink.call(key,{op:body.op,text:body.text}));}
 return res.status(404).json({error:'not found'});}
// Owner side: session cookie (HttpOnly) + per-session CSRF token + Origin check on every write.
async function botLinkOwnerRoutes(req,res,path,body,sess){res.setHeader('Cache-Control','no-store');const send=o=>res.status(o.status).json(o.body);
 const ck='gl:blcsrf:'+sha(cookieOf(req)||'');
 if(path==='/botlink/csrf'&&req.method==='GET'){let t=await r(['GET',ck]);if(!t){t=crypto.randomBytes(24).toString('hex');await r(['SET',ck,t,'EX',2592000]);}return res.json({csrf:t});}
 if(path==='/botlink/types'&&req.method==='GET')return res.json({types:botLink.types()});
 if(path==='/botlink/bots'&&req.method==='GET')return res.json({bots:await botLink.list(sess.ws)});
 {const m=path.match(/^\/botlink\/pairings\/(pr_[A-Za-z0-9_-]{20,40})$/);if(m&&req.method==='GET')return send(await botLink.approvalView(sess.ws,m[1]));}
 if(req.method!=='POST')return res.status(404).json({error:'not found'});
 const t=await r(['GET',ck]);if(!t||req.headers['x-alter-csrf']!==t||(req.headers.origin&&req.headers.origin!==OAUTH_ORIGIN&&!(/^localhost(:\d+)?$/.test(String(req.headers.host))&&req.headers.origin==='http://'+req.headers.host)))return res.status(403).json({error:'csrf'});
 if(path==='/botlink/pairings')return send(await botLink.createPairing({ws:sess.ws,account:sess.email,type:body.type,origin:OAUTH_ORIGIN}));
 {const m=path.match(/^\/botlink\/pairings\/(pr_[A-Za-z0-9_-]{20,40})\/approve$/);if(m)return send(await botLink.approve(sess.ws,m[1],{confirmBotId:body.confirmBotId||null}));}
 {const m=path.match(/^\/botlink\/bots\/(bot_[A-Za-z0-9_-]+)\/(revoke|repaste)$/);if(m)return send(m[2]==='revoke'?await botLink.revoke(sess.ws,m[1]):await botLink.repasteMessage(sess.ws,m[1],OAUTH_ORIGIN));}
 return res.status(404).json({error:'not found'});}
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type'); res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.status(204).end();
  const path = (req.url || '').split('?')[0].replace(/^\/api/, '').replace(/\/$/, '') || '/';
  let body = req.body; if (typeof body === 'string') { try { body = /application\/x-www-form-urlencoded/.test(req.headers['content-type']||'') ? Object.fromEntries(new URLSearchParams(body)) : JSON.parse(body); } catch { body = {}; } } body = body || {};
  try {
    if(path==='/authorization/demo'&&req.method==='GET'){res.setHeader('Cache-Control','no-store');return res.json(AUTHZ.demo());}
    if(path==='/waitlist')return await joinWaitlist(req,res,body);
    if(path.startsWith('/oauth/')||path.startsWith('/.well-known/'))return await oauthRoutes(req,res,path,body);
    if(path.startsWith('/runner/'))return await runnerRoutes(req,res,path,body);
    if(path==='/pairing/redeem'&&req.method==='POST'){res.setHeader('Cache-Control','no-store');if(req.headers.origin!==OAUTH_ORIGIN)return res.status(403).json({error:'origin'});const o=await redeemPairing(body,String(req.headers['x-forwarded-for']||req.socket?.remoteAddress||'unknown').split(',')[0]);if(o.status===200&&body.persistent===true){const ws=await r(['GET','gl:key:'+sha(o.body.key)]);const out=await startRunnerSession(res,ws,o.body.agent.id,o.body.key);return res.status(200).json(out);}return res.status(o.status).json(o.body);}
    if(path.startsWith('/pair/')||path==='/link/call')return await botLinkBotRoutes(req,res,path,body);
    if (path === '/health') return res.json({ ok: true, store: URL_ ? 'upstash' : 'memory', time: now(), v: 14 });
    { const rm = (req.url || '').split('?')[0].match(/^\/receipt\/([^/?#]+)$/) || path.match(/^\/receipt\/([^/?#]+)$/); if (rm && req.method === 'GET') { const x = await publicReceiptRead(rm[1]); const host = (/^localhost/.test(req.headers.host) ? 'http://' : 'https://') + req.headers.host; res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Robots-Tag', 'noindex, nofollow'); res.setHeader('Referrer-Policy', 'no-referrer'); return res.status(x ? 200 : 404).send(receiptPage(x, host, BRAND_NAME)); } }
    { const pm = path.match(/^\/public-receipts\/([a-f0-9]{48})$/); if (pm && req.method === 'GET') { res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Robots-Tag', 'noindex, nofollow'); const x = await publicReceiptRead(pm[1]); return x ? res.json(x) : res.status(404).json({ error: 'Receipt unavailable or expired' }); } }
    if (path === '/me' || path.startsWith('/auth/')) return await handleAuth(req, res, path, body);
    if (path.startsWith('/gateway') || path === '/ingest' || path === '/mcp') {
      const ra = await resolveAgent(req);
      if(!ra&&path==='/mcp')res.setHeader('WWW-Authenticate','Bearer resource_metadata="'+OAUTH_ORIGIN+'/.well-known/oauth-protected-resource/api/mcp"');
      if (!ra) return path === '/mcp' ? res.status(401).json({ jsonrpc: '2.0', id: null, error: { code: -32001, message: 'Unknown or invalid agent key' } }) : res.status(401).json({ status: 'unauthorized', reason: 'Unknown or invalid agent key' });
      req.gatewayKeyAuth=!!ra.apiKey;
      return await als.run({ ws: ra.ws }, () => routes(req, res, path, body, ra.agent));
    }
    const sess = await getSession(req);
    if (!sess) return res.status(401).json({ error: 'auth', message: 'Sign in required' });
    if(path.startsWith('/botlink/'))return await botLinkOwnerRoutes(req,res,path,body,sess);
    if (path === '/funnel') { const f = await als.run({ ws: sess.ws }, () => funnel(sess.ws === 'legacy' ? null : sess.ws)); return /format=html/.test(req.url || '') ? res.setHeader('Content-Type', 'text/html; charset=utf-8').status(200).send(funnelHtml(f)) : res.json(f); }
    return await als.run({ ws: sess.ws }, () => routes(req, res, path, body, null));
  } catch (e) { return res.status(500).json({ error: String(e.message || e) }); }
};
async function routes(req, res, path, body, agentPre) {
  const send = (o) => res.status(o.status).json(o.body);
  const origin = (/^localhost/.test(req.headers.host) ? 'http://' : 'https://') + req.headers.host;
  try {
    if (wsId() === 'legacy') {await seed();
      // Owner-approved cleanup of accidental OAuth authorization on the hidden demo.
      const id=await r(['GET','fm:scout:id']),a=id&&await getJ('fm:agent:'+id);if(a&&a.harness){for(const gid of await r(['SMEMBERS','fm:oauth:grants:'+id])){const k='gl:oauth:grant:'+gid,raw=await r(['GET',k]),g=raw&&JSON.parse(raw);if(g&&g.ws==='legacy'&&g.agentId===id&&g.createdAt==='2026-10-08T21:15:49.442Z'&&!g.revoked){await r(['EVAL',AGENT_CAS,1,k,raw,JSON.stringify({...g,revoked:true,revokedAt:now(),failureReason:'hidden_demo_authorization',failedAt:now()})]);bust();}}}
    }


    if(wsId()==='legacy') {const k='fm:req:req_97e4b111cd',raw=await r(['GET',k]),q=raw&&JSON.parse(raw),a=q&&await getJ('fm:agent:'+q.agentId);if(q&&q.agentId==='agent_a9c54ebb63'&&q.createdAt==='2026-10-06T20:48:23.766Z'&&q.status==='pending'&&a&&a.harness){const next={...q,status:'cancelled',reason:'Stale hidden demo request retired',decidedAt:now()};if(await r(['EVAL',AGENT_CAS,1,k,raw,JSON.stringify(next)])===1)await finishReq(next);}}

    // --- agent-facing gateway ---
    if (path.startsWith('/gateway')) {
      const agent = agentPre;
      if(path==='/gateway/routing'&&req.method==='GET')return res.json(await routing(new URL(req.url,'https://local.invalid').searchParams.get('category')||''));
      if(path==='/gateway/inbox'&&req.method==='GET')return res.json({tasks:await inbox(agent)});
      if(path==='/gateway/teammates'&&req.method==='GET')return res.json({bots:await teammates()});
      if(path==='/gateway/notifications'&&req.method==='GET'){res.setHeader('Cache-Control','no-store');return send(await notifications(agent,new URL(req.url,'https://local.invalid').searchParams.get('after')));}
      if(path==='/gateway/me'&&req.method==='GET'){if(agent.status!=='active'||await r(['GET','fm:kill']))return res.status(403).json({status:'blocked',reason:'Worker revoked or workspace paused'});res.setHeader('Cache-Control','no-store');return res.json({agent:{id:agent.id,name:agent.name,status:agent.status}});}
      if(req.gatewayKeyAuth&&agent.status==='active'&&!await r(['GET','fm:kill'])&&((path==='/gateway/presence'&&req.method==='POST')||(path==='/gateway/tasks/next'&&req.method==='GET'))){const prior=await getJ('fm:gatewaySeen:'+agent.id);await setJ('fm:gatewaySeen:'+agent.id,{seenAt:now(),epoch:agent.oauthEpoch||0});await touchAgent(agent);if(!prior||prior.epoch!==(agent.oauthEpoch||0))await event(agent.id,'interaction','HTTP gateway connected',{kind:'INTERACTION',source:'gateway',presenceOnly:true});}
      if(path==='/gateway/card-proposals'&&req.method==='POST')return send(await cardPropose(await getJ('fm:agent:'+agent.id),body));
      if(path==='/gateway/broker/requests'&&req.method==='POST')return send(await brokerRequest(agent,body));
      {const bm=path.match(/^\/gateway\/broker\/requests\/(broker_[a-f0-9]+)$/);if(bm&&req.method==='GET'){const q=await getJ('fm:broker:q:'+bm[1]);return q&&q.agentId===agent.id?res.json({request:brokerPublic(q)}):res.status(404).json({error:'not found'});}}
      if(path==='/gateway/spend-requests'&&req.method==='POST')return send(await newSpendRequest(agent,body));
      {const sm=path.match(/^\/gateway\/spend-requests\/(spend_[a-f0-9]+)$/);if(sm&&req.method==='GET'){const q=await getJ('fm:spendRequest:'+sm[1]);return q&&q.agentId===agent.id?res.json({request:q}):res.status(404).json({error:'not found'});}}
      if (path === '/gateway/chat-task' && req.method === 'POST') return send(await chatTask(agent,body));
      if(path==='/gateway/owner-conversation'&&req.method==='POST')return send(await ownerConversation(agent,body,'gateway'));
      if (path === '/gateway/presence' && req.method === 'POST') {if(agent.status!=='active'||await r(['GET','fm:kill']))return res.status(403).json({status:'blocked'});await touchAgent(agent);await event(agent.id,'interaction','Runner presence accepted (not conversation or work)',{kind:'INTERACTION',source:'chat',presenceOnly:true});return res.json({status:'ok'});}
      {const tm=path.match(/^\/gateway\/tasks\/(\w+)$/);if(tm&&tm[1]!=='next'&&req.method==='GET'){const t=await taskForAgent(agent,tm[1]);return t?res.json({task:t}):res.status(404).json({error:'not found'});}}
      if (path === '/gateway/act' && req.method === 'POST') return send(await gatewayAct(agent, body));
      if (path === '/gateway/events' && req.method === 'POST') return send(await reportEvent(agent, body));
      if (path === '/gateway/tasks/next') { if (agent.status !== 'active') { await event(agent.id, 'blocked', 'Blocked task claim: access revoked', { kind: 'BLOCKED' }); return res.status(403).json({ status: 'blocked', reason: 'Access revoked by owner' }); } return res.json({ task: await claimTask(agent) }); }
      { const tm = path.match(/^\/gateway\/tasks\/(\w+)\/complete$/); if (tm && req.method === 'POST') return send(await completeTask(agent, tm[1], body)); }
      const m = path.match(/^\/gateway\/requests\/(\w+)$/);
      if (m) { const q = await getJ('fm:req:' + m[1]); if (!q || q.agentId !== agent.id) return res.status(404).json({ error: 'not found' }); return res.json(pub(q)); }
      return res.status(404).json({ error: 'not found' });
    }
    // --- webhook intake: a provider posts its own payload, the adapter normalizes it ---
    if (path === '/ingest' && req.method === 'POST') { return send(await reportEvent(agentPre, body, 'webhook')); }
    if (path === '/mcp') { const agent = agentPre;
      if (req.method !== 'POST') return res.status(405).json({ error: 'POST JSON-RPC' });
      if (Array.isArray(body)) { const outs = (await Promise.all(body.map(m => mcpHandle(agent, m)))).filter(Boolean); return outs.length ? res.json(outs) : res.status(202).end(); }
      const o = await mcpHandle(agent, body); return o ? res.json(o) : res.status(202).end(); }
    // --- owner-facing ---
    if(path==='/cards'&&req.method==='GET')return res.json(await cardData());
    if(path==='/broker'&&req.method==='GET')return res.json(await brokerState());
    {const bm=path.match(/^\/broker\/(broker_[a-f0-9]+)\/(approve|deny)$/);if(bm&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await brokerDecision(bm[1],{...body,decision:bm[2]}));}}
    if(path==='/authorization/demo'&&req.method==='GET')return res.json(AUTHZ.demo());
    if(path==='/issuer/test/mandate'&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await issuerMandate(body));}
    if(path==='/issuer/test/status'&&req.method==='GET')return res.json({mode:'stripe_test_only',configured:!!process.env.STRIPE_ISSUING_TEST_WEBHOOK_SECRET,liveEnabled:false,issuerDeliveryVerified:false,responseBudgetMs:1000,note:'Deployment is not issuer delivery verification. Configure a Stripe sandbox endpoint with decline-on-timeout.'});
    if(path==='/cards/control'&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await cardControl(body));}
    if(path==='/cards/proposals'&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await cardPropose(await getJ('fm:agent:'+body.botId),body));}
    {const cm=path.match(/^\/cards\/(card_[a-f0-9]+)\/(approve|deny)$/);if(cm&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await cardDecision(cm[1],cm[2],body.detailsHash));}}

    {const am=path.match(/^\/tasks\/(\w+)\/assign$/);if(am&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await assignTask(am[1],body));}}
    if(path.startsWith('/public-receipts'))res.setHeader('Cache-Control','no-store');
    if(path==='/public-receipts'&&req.method==='GET')return res.json(await publicReceiptList(new URL(req.url,'https://local.invalid').searchParams.get('taskId')));
    if(path==='/public-receipts/draft'&&req.method==='GET')return send(await publicReceiptDraft(new URL(req.url,'https://local.invalid').searchParams.get('taskId')));
    if(path==='/public-receipts/review'&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await publicReceiptReview(body.taskId,body));}
    if(path==='/public-receipts/publish'&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await publicReceiptPublish(body));}
    {const rv=path.match(/^\/public-receipts\/([a-f0-9]{48})\/revoke$/);if(rv&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await publicReceiptRevoke(rv[1]));}}
    {const jm=path.match(/^\/jobs\/(\w+)$/);if(jm&&req.method==='GET'){const j=await jobDetail(jm[1]);return j?res.json(j):res.status(404).json({error:'not found'});}}
    {const tm=path.match(/^\/tasks\/(\w+)\/reassign$/);if(tm&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await reassignTask(tm[1],body));}}
    {const sm=path.match(/^\/agents\/(\w+)\/permission-scope$/);if(sm&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await setJobScope(sm[1],body));}}
    {const gm=path.match(/^\/tasks\/(\w+)\/grant$/);if(gm&&req.method==='POST'){if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await grantJob(gm[1],body));}}
    if (path === '/tasks' && req.method === 'POST') { if (!String(body.title || '').trim()) return res.status(400).json({ error: 'title required' }); await track('first_task_started'); return res.json({ task: await newTask({ title: body.title, brief: body.brief, assignee: body.assignee }) }); }
    if(path==='/money'&&req.method==='GET')return res.json(await spendSummary());
    {const sm=path.match(/^\/money\/(spend_[a-f0-9]+)\/(approve|deny)$/);if(sm&&req.method==='POST')return send(await reviewSpend(sm[1],sm[2],body.detailsHash));}
    {const cm=path.match(/^\/agents\/(\w+)\/(connection|reconnect)$/);if(cm){if(cm[2]==='connection'&&req.method==='GET'){const a=await getJ('fm:agent:'+cm[1]);return a?res.json({agentId:a.id,connection:await connectionState(a)}):res.status(404).json({error:'not_found'});}if(cm[2]==='reconnect'&&req.method==='POST'){if(req.headers.origin!==OAUTH_ORIGIN)return res.status(403).json({error:'origin'});return send(await reconnectAgent(cm[1],body));}return res.status(405).json({error:'method_not_allowed'});}}
    {const pm=path.match(/^\/agents\/(\w+)\/pairing$/);if(pm&&req.method==='POST'){res.setHeader('Cache-Control','no-store');if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});return send(await issuePairing(pm[1]));}}
    if(path==='/routing'&&req.method==='GET')return res.json(await routing(new URL(req.url,'https://local.invalid').searchParams.get('category')||''));
    if (path === '/state') return res.json(await fullState());
    let m;
    if ((m = path.match(/^\/requests\/(\w+)\/(approve|deny)$/)) && req.method === 'POST') { const d = await decide(m[1], m[2]); if (d.status === 200) await track('approval_completed'); return send(d); }
    {const km=path.match(/^\/agents\/(\w+)\/gateway-key$/);if(km&&req.method==='POST'){
      if(req.headers.origin!==origin)return res.status(403).json({error:'origin'});
      const a=await getJ('fm:agent:'+km[1]);if(!a||a.status!=='active'||a.hosted)return res.status(409).json({error:'bot_not_available'});
      if(await r(['GET','fm:kill']))return res.status(403).json({error:'Workspace is paused'});
      const lock=crypto.randomBytes(12).toString('hex'),lockKey='fm:gatewayKeyLock:'+a.id;if(!await r(['SET',lockKey,lock,'NX','PX',30000]))return res.status(409).json({error:'Key rotation already in progress; retry'});
      try{const oldHash=await r(['GET','fm:gatewayKeyHash:'+a.id]);
      const key='fmk_'+crypto.randomBytes(20).toString('hex'),hash=sha(key);
      const updated=await updateAgent(a.id,x=>{if(x.status!=='active')throw new Error('Bot revoked during setup');x.connectionMode='gateway';x.keyHint=key.slice(0,8)+'...'+key.slice(-4);});
      if(oldHash)await r(['DEL','fm:key:'+oldHash,'gl:key:'+oldHash]);await r(['SET','fm:gatewayKeyHash:'+a.id,hash]);
      await r(['SET','fm:key:'+hash,a.id]);await r(['SET','gl:key:'+hash,wsId()]);await r(['DEL','fm:gatewaySeen:'+a.id,'fm:seen:'+a.id]);bust();
      res.setHeader('Cache-Control','no-store');return res.json({agent:updated,key,connectionStatus:'awaiting_bot'});
      }finally{if(await r(['GET',lockKey])===lock)await r(['DEL',lockKey]);}
    }}
    if (path === '/agents' && req.method === 'POST') { const c = await createAgent(body.name, body.role, body.provider); return res.json(c); }
    if ((m = path.match(/^\/agents\/(\w+)\/(revoke|restore|permissions|limits|room|pause)$/)) && req.method === 'POST') {
      const op=m[2];
      const rooms={ops:'Execution Center',sales:'Outreach Center',marketing:'Creative / Marketing',finance:'Research Center',support:'Outreach Center',lounge:'Lounge'};
      if(op==='room' && !Object.prototype.hasOwnProperty.call(rooms,body.room))return res.status(400).json({error:'Choose a valid room'});
      if(op==='permissions' && (!ACTIONS[body.action] || !['AUTO','ASK','NEVER'].includes(body.mode)))return res.status(400).json({error:'bad input'});
      const a=await updateAgent(m[1],a=>{
        if(op==='room'){a.room=body.room;}
        if(op==='revoke'){a.status='revoked';a.revokedAt=now();a.oauthEpoch=(a.oauthEpoch||0)+1;}
        if(op==='restore'){a.status='active';delete a.revokedAt;}
        if(op==='permissions'){a.permissions={...(a.permissions||{}),[body.action]:body.mode};}
        if(op==='limits'){a.limits={perActionCents:body.perActionCents==null?null:+body.perActionCents,dailyCents:body.dailyCents==null?null:+body.dailyCents};}
        if(op==='pause'){if(body.on){a.paused=true;a.pausedAt=now();}else{delete a.paused;delete a.pausedAt;}}
      });if(!a)return res.status(404).json({error:'not found'});
      if (m[2] === 'revoke') { await event(a.id, 'revoked', `Owner revoked ${a.name}'s access`); 
        // pending requests of this agent are cancelled immediately
        for (const id of await r(['SMEMBERS', 'fm:reqs'])) { const q = await getJ('fm:req:' + id); if (q && q.agentId === a.id && q.status === 'pending') { q.status = 'blocked'; q.reason = 'Access revoked while pending'; q.decidedAt = now(); await finishReq(q); await receipt(a, q.action, q.params, 'blocked', 0, 'BLOCKED: access revoked while request was pending', q.id, { code: 'revoked' }); } } }
      if (m[2] === 'restore') { await event(a.id, 'restored', `Owner restored ${a.name}'s access`); }
      if (m[2] === 'permissions') { await event(a.id, 'permission', `${body.action} set to ${body.mode}`); }
      if (m[2] === 'limits') { await event(a.id, 'limits', `Limits set: per action ${a.limits.perActionCents}c, daily ${a.limits.dailyCents}c`); }
      if(op==='room')await event(a.id,'room_changed','Moved to '+rooms[a.room],{room:a.room});
      if(op==='pause')await event(a.id,body.on?'paused':'resumed',body.on?'Owner paused '+a.name:'Owner resumed '+a.name,{source:'owner'});
      return res.json({ agent: a });
    }
    if ((m = path.match(/^\/agents\/(\w+)\/remove$/)) && req.method === 'POST') { const a = await getJ('fm:agent:' + m[1]); if (!a || a.live) return res.status(400).json({ error: 'cannot remove' }); await updateAgent(a.id,x=>{x.status='revoked';x.revokedAt=now();x.oauthEpoch=(x.oauthEpoch||0)+1;}); bust(); await r(['SREM', 'fm:agents', a.id]); await r(['DEL', 'fm:secret:' + a.id]); return res.json({ removed: true }); }
    if (path === '/kill' && req.method === 'POST') { bust(); if (body.on) await r(['SET', 'fm:kill', '1']); else await r(['DEL', 'fm:kill']); await event(null, 'kill', body.on ? 'KILL SWITCH ON: all agents stopped' : 'Kill switch off'); return res.json({ killed: !!body.on }); }
    // --- v11: one connect flow for every provider. Hosted providers (Grok) need only a pasted key; the rest get one message to paste. ---
    if (path === '/connect' && req.method === 'POST') {
      const prov = String(body.provider || 'custom'); const name = String(body.name || '').trim() || (prov === 'grok' ? 'Grok' : 'AI employee');
      const preset = PRESETS[body.preset] ? body.preset : 'balanced'; const base = OAUTH_ORIGIN;
      if (prov === 'muse' && body.connectionMode !== 'existing') {
        let k = String(body.apiKey || '').trim().replace(/^MODEL_API_KEY=/i, '').replace(/^Bearer\s+/i, '').trim(); if (k.length > 1 && ((k[0] === '"' && k.endsWith('"')) || (k[0] === "'" && k.endsWith("'")))) k = k.slice(1, -1).trim();
        if (!/^LLM(?:_[^\s_|]+_[^\s|]+|\|[^\s|]+\|[^\s|]+)$/.test(k)) return res.status(400).json({ error: 'Paste your Meta Model API key from dev.meta.ai. It starts with LLM_ (LLM_<id>_<secret>).' });
        let models; try { models = await museModels(k); } catch (e) { return res.status(400).json({ error: e.message }); }
        if (!models.length) return res.status(400).json({ error: 'This Meta account has no available Muse Spark text model. Check model access in the Meta dashboard.' });
        const requested = String(body.model || '');
        const model = requested || (models.includes('muse-spark-1.3') ? 'muse-spark-1.3' : models.find(x => !x.includes('contributor')) || models[0]);
        if (!models.includes(model)) return res.status(400).json({ error: 'That Muse Spark model is not available to this key.' });
        if (body.check) return res.json({ ok: true, model, validation: 'read-only model list' });
        const c = await createAgent(name, String(body.role || '').trim() || 'Muse Spark employee', 'muse', false, { preset, hosted: true, model });
        await r(['SET', 'fm:secret:' + c.agent.id, enc(k)]);
        await track('connected', { provider: 'muse' }); return res.json({ agent: c.agent, hosted: true, noFirstTask: true });
      }
      if (prov === 'grok' && body.connectionMode !== 'existing') {
        const k = String(body.apiKey || '').trim(); if (!/^xai-[A-Za-z0-9]{20,}$/.test(k)) { await mark('connect_failed', { reason: 'bad_key_format' }); return res.status(400).json({ error: 'Paste the key from console.x.ai (it starts with xai-)' }); }
        const model = String(body.model || 'grok-4.3').replace(/[^\w.\-]/g, '').slice(0, 40);
        try { await xaiChat(k, model, 'Reply with the word ready.', 5); } catch (e) { await mark('connect_failed', { reason: /recognise/.test(e.message) ? 'bad_key_format' : /rejected/.test(e.message) ? 'xai_rejected' : /credit|rate/.test(e.message) ? 'xai_credits' : 'xai_other' }); return res.status(400).json({ error: e.message + '. Check the key and that your xAI account has credits.' }); }
        if (body.check) return res.json({ ok: true });
        const c = await createAgent(name, String(body.role || '').trim() || 'Grok employee', 'grok', false, { preset, hosted: true, model });
        await r(['SET', 'fm:secret:' + c.agent.id, enc(k)]);
        await track('connected', { provider: 'grok' }); return res.json({ agent: c.agent, hosted: true });
      }
      const c = await createAgent(name, String(body.role || '').trim(), prov, false, { preset });
      const msg = `Connect my existing assistant ${name} to ${BRAND_NAME}. FIRST open ${OAUTH_ORIGIN}/runner?agent=${encodeURIComponent(c.agent.id)} in your own browser. Do not open an OAuth card or reuse a remembered connector flow for this browser-console path. A provider-side Connected label is not proof, and old grants stop working after a workspace reset. Use this exact bot ID: ${c.agent.id}. If browser control is unavailable, stop and explain; do not claim connection. I will enter a one-time pairing code securely in the browser, not in chat. Then click Pair and connect. Only accepted identity and presence confirm connection. Never request or paste a key, password or token in chat, code, logs or URLs. Keep the console open while active; closing it stops presence; reopening this exact link in the saved browser resumes the pair unless revoked, reset or expired. No new provider bot, paid API or credits. Report only real work through Alter policy and never bypass a rejection.`;
      await track('connected', { provider: prov }); return res.json({ agent: c.agent, hosted: false, noFirstTask: true, connectionStatus: 'awaiting_bot', instructions: msg, mcpUrl: base + '/api/mcp', runnerUrl: base + '/runner?agent=' + encodeURIComponent(c.agent.id) });
    }
    if (path === '/track' && req.method === 'POST') { if (['connect_started', 'first_task_started', 'approval_shown'].includes(body.step)) await track(body.step, body.provider ? { provider: String(body.provider).slice(0, 20) } : null); return res.json({ ok: true }); }
    // --- live demo agent ---
    if (wsId() !== 'legacy' && path.startsWith('/demo/')) return res.status(404).json({ error: 'not found' });
    if (path === '/demo/scout/tick' && req.method === 'POST') return res.json(await scoutTick(origin));
    if (path === '/demo/scout/state') return res.json({ ...(await getJ('fm:scout:state') || {}), agentId: await r(['GET', 'fm:scout:id']) });
    return res.status(404).json({ error: 'not found', path });
  } catch (e) { return res.status(500).json({ error: String(e.message || e) }); }
};

// For api/og.js: read a public share without a session.
module.exports.publicReceiptRead = token => als.run({ ws: 'legacy' }, () => publicReceiptRead(token));

// Issuer-test mandate: one owner card, one exact pending spend at a time.
// Metadata from the merchant/webhook never chooses a workspace, bot or job.
async function issuerMandate(body){
 if(body.confirmed!==true||!/^ic_[A-Za-z0-9]+$/.test(body.cardId||'')||!/^acct_[A-Za-z0-9]+$/.test(body.accountId||'')||!Number.isSafeInteger(body.amountCents)||body.amountCents<1||body.amountCents>1000000||!Number.isSafeInteger(body.jobBudgetCents)||body.jobBudgetCents<body.amountCents||body.jobBudgetCents>1000000||typeof body.merchantNetworkId!=='string'||!body.merchantNetworkId.trim()||body.merchantNetworkId.length>100||typeof body.category!=='string'||!body.category||body.category.length>100)return {status:400,body:{error:'Review exact test account/card, bot/job, USD amount, network merchant id and issuer category'}};
 const a=await getJ('fm:agent:'+body.botId),t=await getJ('fm:task:'+body.taskId);
 if(!a||a.status!=='active'||a.paused||!t||t.assignee!==a.id||t.status!=='running')return {status:400,body:{error:'Active bot and assigned running job required'}};
 const binding=body.accountId+':'+body.cardId,bindingKey='gl:issuer-owner-test:'+wsId();await r(['SET',bindingKey,binding,'NX']);if(await r(['GET',bindingKey])!==binding)return {status:409,body:{error:'One test card per owner; registered account/card differs'}};
 const key='gl:issuer-test:'+binding,raw=await r(['GET',key]),old=raw&&JSON.parse(raw);
 if(old&&old.ws!==wsId())return {status:409,body:{error:'Card is registered elsewhere'}};
 if(old?.mandate&&!old.mandate.used&&old.mandate.expires>Date.now())return {status:409,body:{error:'An unexpired mandate already exists for this owner card'}};
 const jobs=old?.jobs||{},spent=Number(jobs[body.taskId]?.reservedCents||0);if(body.jobBudgetCents<spent+body.amountCents)return {status:400,body:{error:'Job issuer-test budget has insufficient unreserved cents'}};jobs[body.taskId]={botId:a.id,budgetCents:body.jobBudgetCents,reservedCents:spent};
 const next={ws:wsId(),jobs,accountId:body.accountId,cardId:body.cardId,decisions:old?.decisions||[],mandate:{id:rid('mandate'),botId:a.id,taskId:t.id,amountCents:body.amountCents,merchantNetworkId:body.merchantNetworkId.trim(),category:body.category,expires:Date.now()+600000,used:false,createdAt:now()}};
 const won=raw?await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(next)]):await r(['SET',key,JSON.stringify(next),'NX']);if(!won)return {status:409,body:{error:'Concurrent mandate change; review again'}};
 return {status:200,body:{mode:'stripe_test_only',mandate:next.mandate,note:'Single-use exact spend approval, expires in 10 minutes. No real card or money. Unknown or ambiguous charges decline.'}};
}
async function issuerProcess(event,deadline){
 const deny=reason=>({approved:false,reason}),auth=event.data?.object,p=auth?.pending_request,card=typeof auth?.card==='string'?auth.card:auth?.card?.id;
 if(event.livemode!==false||auth?.livemode!==false)return deny('live_mode_disabled');
 if(!/^evt_[A-Za-z0-9]+$/.test(event.id||'')||!/^iauth_[A-Za-z0-9]+$/.test(auth?.id||'')||!/^acct_[A-Za-z0-9]+$/.test(event.account||'')||!/^ic_[A-Za-z0-9]+$/.test(card||'')||p?.currency!=='usd'||!Number.isSafeInteger(p?.amount)||p.amount<1)return deny('invalid_or_unsupported_request');
 const key='gl:issuer-test:'+event.account+':'+card;
 for(let attempt=0;attempt<3;attempt++){
  if(Date.now()>=deadline)return deny('internal_deadline');
  const raw=await r(['GET',key]);if(!raw)return deny('unmapped_card');const state=JSON.parse(raw),m=state.mandate;
  // Any replay conservatively declines, including a fresh delivery of an approved authorization.
  if(state.decisions.some(x=>x.eventId===event.id||x.authorizationId===auth.id))return deny('replay_declined');
  if(!m||m.used||m.expires<=Date.now())return deny('no_active_owner_mandate');
  if(p.amount!==m.amountCents||auth.merchant_data?.network_id!==m.merchantNetworkId||auth.merchant_data?.category!==m.category)return deny('mandate_mismatch');
  const decision=await als.run({ws:state.ws,issuerDeadline:deadline},async()=>{
   const a=await getJ('fm:agent:'+m.botId),t=await getJ('fm:task:'+m.taskId),killed=!!await r(['GET','fm:kill'])||!!await r(['GET','fm:cards:kill']);
   // Same engine, issuer-authenticated amount/category, preapproved exact mandate.
   return AUTHZ.evaluate({botId:m.botId,taskId:m.taskId,amountCents:p.amount,currency:'USD',category:auth.merchant_data.category},{active:a?.status==='active',paused:a?.paused,killed,expired:m.expires<=Date.now(),ownerApproved:true,spentToday:0,dailyLimit:state.jobs?.[m.taskId]?.budgetCents||0,recentCount:0,policy:{perActionCents:m.amountCents,allowedCategories:[m.category],maxPerHour:1},jobRequired:true,job:t?{...t,sandboxGrant:{botId:m.botId,status:'active',budgetCents:state.jobs?.[m.taskId]?.budgetCents||0,spentCents:state.jobs?.[m.taskId]?.reservedCents||0}}:null});
  });
  if(Date.now()>=deadline)return deny('internal_deadline');
  const approved=decision.decision==='ALLOW_SANDBOX',jobs={...state.jobs};if(approved)jobs[m.taskId]={...jobs[m.taskId],reservedCents:jobs[m.taskId].reservedCents+p.amount};const next={...state,jobs,mandate:{...m,used:true},decisions:[...state.decisions,{eventId:event.id,authorizationId:auth.id,mandateId:m.id,botId:m.botId,taskId:m.taskId,amountCents:p.amount,approved,reason:decision.code,at:now(),mode:'stripe_test_only',chargedCents:0}]};
  // Atomic consume+decision. Uncertain/time-out storage stays consumed, never auto-retries spend.
  if(await r(['EVAL',AGENT_CAS,1,key,raw,JSON.stringify(next)])===1)return Date.now()<deadline?{approved,reason:decision.code}:deny('internal_deadline');
 }
 return deny('concurrent_admission');
}
module.exports.issuerProcess=(event,deadline)=>!URL_?Promise.resolve({approved:false,reason:'durable_storage_required'}):als.run({issuerDeadline:deadline},()=>issuerProcess(event,deadline));

// Credential-isolated broker. No reusable credential ever leaves the server.
// Paid adapters remain hard-disabled until explicit implementation + owner approval.
const BROKER_COVERAGE={grok:'Runner/HTTP/MCP broker requests only. Native Grok billing and direct keys are outside Alter.',instinct:'Runner/MCP broker requests only. Native tools, wallets and purchases remain outside Alter.',muse:'Existing Muse Poster via runner browser controls. Native Muse credits, vault and purchases remain outside Alter.'};
function brokerPublic(q){const {rawInput,...rest}=q;return rest;}
async function brokerRequest(agent,b){
 const a=await getJ('fm:agent:'+agent.id),t=await getJ('fm:task:'+b.taskId);
 if(!a||a.status!=='active'||a.paused||await r(['GET','fm:kill']))return {status:403,body:{error:'Bot or workspace stopped'}};
 if(!t||t.assignee!==a.id||t.status!=='running')return {status:403,body:{error:'Assigned running job required'}};
 if(!['fixture.echo','xai.chat'].includes(b.route)||typeof b.sourceId!=='string'||!b.sourceId.trim()||b.sourceId.length>120||typeof b.input!=='string'||!b.input.trim()||b.input.length>10000||!Number.isSafeInteger(b.maxCents)||b.maxCents<0||b.maxCents>1000000)return {status:400,body:{error:'Known route, stable sourceId, input and exact maximum cents required'}};
 if(b.route==='fixture.echo'&&b.maxCents!==0)return {status:400,body:{error:'Fixture costs zero'}};
 const details={route:b.route,input:b.input,taskId:t.id,maxCents:b.maxCents},hash=sha(JSON.stringify(details)),id='broker_'+sha(a.id+':'+b.sourceId).slice(0,24),key='fm:broker:q:'+id;
 const q={id,agentId:a.id,agentName:a.name,taskId:t.id,route:b.route,input:b.input,maxCents:b.maxCents,detailsHash:hash,status:'pending',createdAt:now(),expires:Date.now()+600000,note:b.route==='fixture.echo'?'Disposable echo only. No paid provider.':'xAI paid execution disabled. Approval cannot call provider.'};
 const won=await r(['SET',key,JSON.stringify(q),'NX']),old=won?q:await getJ(key);if(old.detailsHash!==hash)return {status:409,body:{error:'sourceId already has different details'}};await r(['SADD','fm:broker:requests',id]);return {status:won?202:200,body:{request:brokerPublic(old)}};
}
async function brokerDecision(id,b){const q=await getJ('fm:broker:q:'+id);return q?withJobLock(q.taskId,()=>brokerDecisionUnlocked(id,b)):{status:404,body:{error:'not found'}};}
async function brokerDecisionUnlocked(id,b){
 if(!['approve','deny'].includes(b.decision))return {status:400,body:{error:'Approve or deny required'}};
 const key='fm:broker:q:'+id,q=await getJ(key);if(!q)return {status:404,body:{error:'not found'}};if(q.detailsHash!==b.detailsHash)return {status:409,body:{error:'Review exact destination, input and maximum again'}};if(q.status!=='pending')return {status:200,body:{request:brokerPublic(q)}};
 const a=await getJ('fm:agent:'+q.agentId),t=await getJ('fm:task:'+q.taskId),killed=await r(['GET','fm:kill']);
 const reason=b.decision==='deny'?'owner_denied':Date.now()>=q.expires?'expired':!a||a.status!=='active'||a.paused||killed?'bot_stopped':!t||t.assignee!==q.agentId||t.status!=='running'?'job_inactive':q.route!=='fixture.echo'?'paid_adapter_disabled':null;
 const policy=AUTHZ.evaluate({botId:q.agentId,taskId:q.taskId,amountCents:1,currency:'USD',category:'fixture'},{active:a?.status==='active',paused:a?.paused,killed:!!killed,ownerApproved:true,spentToday:0,dailyLimit:1,policy:{allowedCategories:['fixture']},recentCount:0,jobRequired:true,job:t?{...t,sandboxGrant:{botId:q.agentId,status:'active',budgetCents:1,spentCents:0}}:null});
 q.status=reason?'blocked':'executing';q.reason=reason||policy.code;q.decidedAt=now();
 // Fail closed on unsupported/paid routes. The only executable adapter is credentialless echo.
 if(reason||policy.decision!=='ALLOW_SANDBOX'){q.status=b.decision==='deny'?'denied':'blocked';await setJ(key,q);return {status:200,body:{request:brokerPublic(q)}};}
 await setJ(key,q);q.result={text:q.input,adapter:'fixture.echo',fixture:true,chargedCents:0};q.status='completed';q.receipt={id:'receipt_'+q.id,taskId:q.taskId,agentId:q.agentId,at:now(),destination:q.route,detailsHash:q.detailsHash,approvedBy:'owner:exact_review',chargedCents:0,note:'Fixture echo executed inside Alter. Not a provider purchase or universal interception proof.'};await setJ(key,q);return {status:200,body:{request:brokerPublic(q)}};
}
async function brokerState(){const ids=await r(['SMEMBERS','fm:broker:requests']);return {mode:'fixture_only',credentialsReleased:false,paidExecutionEnabled:false,coverage:BROKER_COVERAGE,requests:ids.length?(await r(['MGET',...ids.map(id=>'fm:broker:q:'+id)])).filter(Boolean).map(JSON.parse).map(brokerPublic).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,100):[]};}

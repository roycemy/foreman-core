/* Alter island base. Draws the base under floor-clean.png. viewBox 0 0 2232 1270.
   baseSVG('A'|'B'|'C', waiting) -> inner SVG string. */
(function(){
const L=[61,623],B=[1116,1152],R=[2171,623],S=.501;
const edgeY=x=>x<=1116?623+S*(x-61):623+S*(2171-x);
const pl=a=>a.map(p=>p.join(',')).join(' ');
const sh=(a,dy)=>a.map(p=>[p[0],p[1]+dy]);
const dot=(cx,cy,r,face,waiting,idleFill)=>{const sk=face==='L'?'skewY(26.6)':'skewY(-26.6)';
 const tr=`translate(${cx} ${cy}) ${sk}`;
 return waiting?`<g transform="${tr}"><circle class="glow" r="${r*2.6}" fill="#E8452C" opacity=".22"/><circle r="${r}" fill="#E8452C"/></g>`:`<g transform="${tr}"><circle r="${r}" fill="${idleFill}"/></g>`};
window.baseSVG=function(v,w){
 const defs=`<defs><filter id="bl22" x="-20%" y="-40%" width="140%" height="200%"><feGaussianBlur stdDeviation="22"/></filter><filter id="bl7" x="-20%" y="-40%" width="140%" height="200%"><feGaussianBlur stdDeviation="7"/></filter>
 <linearGradient id="gl" x1="0" x2="1"><stop offset="0" stop-color="#F1EFE9"/><stop offset="1" stop-color="#E3E0D8"/></linearGradient>
 <linearGradient id="gr" x1="0" x2="1"><stop offset="0" stop-color="#D9D6CC"/><stop offset="1" stop-color="#CCC8BD"/></linearGradient></defs>`;
 const top=-4;let s=defs;
 const face=(T,fl,fr,y0=0,inset)=>{const A=L,Bv=B,C=R;
  return `<polygon points="${pl([[A[0],A[1]+top+y0],[Bv[0],Bv[1]+top+y0],[Bv[0],Bv[1]+T+y0],[A[0],A[1]+T+y0]])}" fill="${fl}"/><polygon points="${pl([[Bv[0],Bv[1]+top+y0],[C[0],C[1]+top+y0],[C[0],C[1]+T+y0],[Bv[0],Bv[1]+T+y0]])}" fill="${fr}"/>`};
 const hl=(c,o,wd,y0=0)=>`<polyline points="${pl([[L[0],L[1]+y0],[B[0],B[1]+y0],[R[0],R[1]+y0]])}" fill="none" stroke="${c}" stroke-opacity="${o}" stroke-width="${wd}" stroke-linejoin="round" stroke-linecap="round"/>`;
 const bottom=(T,c,o)=>`<polyline points="${pl([[L[0],L[1]+T],[B[0],B[1]+T],[R[0],R[1]+T]])}" fill="none" stroke="${c}" stroke-opacity="${o}" stroke-width="2.5" stroke-linejoin="round"/>`;
 const shadow=(T,a1,a2,off)=>{const o=[L,B,R].map(p=>[p[0],p[1]+T+off]);const poly=pl([[L[0],L[1]+T+off],[B[0],B[1]+T+off],[R[0],R[1]+T+off],[R[0],R[1]+T-40],[L[0],L[1]+T-40]]);
  return `<polygon points="${poly}" fill="#121212" opacity="${a1}" filter="url(#bl22)"/><polygon points="${pl([[L[0]+20,L[1]+T+4],[B[0],B[1]+T+6],[R[0]-20,R[1]+T+4],[R[0]-20,R[1]+T-20],[L[0]+20,L[1]+T-20]])}" fill="#121212" opacity="${a2}" filter="url(#bl7)"/>`};
 const pill=(cx,cy,face,fill,wd=34,ht=12)=>`<g transform="translate(${cx} ${cy}) skewY(${face==='L'?26.6:-26.6})"><rect x="${-wd/2}" y="${-ht/2}" width="${wd}" height="${ht}" rx="${ht/2}" fill="${fill}"/></g>`;
 const glowP=(cx,cy,face)=>`<g transform="translate(${cx} ${cy}) skewY(${face==='L'?26.6:-26.6})"><rect class="glow" x="-34" y="-14" width="68" height="28" rx="14" fill="#E8452C" opacity=".2"/></g>`;
 const groove=(T,f)=>`<polyline points="${pl([[L[0],L[1]+T*f],[B[0],B[1]+T*f],[R[0],R[1]+T*f]])}" fill="none" stroke="#121212" stroke-opacity=".10" stroke-width="2.5" stroke-linejoin="round"/><polyline points="${pl([[L[0],L[1]+T*f+3],[B[0],B[1]+T*f+3],[R[0],R[1]+T*f+3]])}" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="2" stroke-linejoin="round"/>`;
 if(v==='A'){const T=76;
  s+=shadow(T,.10,.16,34)+face(T,'url(#gl)','url(#gr)')+hl('#fff',.95,3)+groove(T,.30)+bottom(T,'#121212',.14)
   +`<line x1="${B[0]}" y1="${B[1]}" x2="${B[0]}" y2="${B[1]+T}" stroke="#fff" stroke-opacity=".6" stroke-width="2"/>`;
  const cx=900,cy=edgeY(cx)+T*.64;
  }
 if(v==='B'){const T=46;
  s+=shadow(T,.09,.18,26)+face(T,'#1D1D1B','#111111')+`<polyline points="${pl([[L[0],L[1]+top+1],[B[0],B[1]+top+1],[R[0],R[1]+top+1]])}" fill="none" stroke="#F8F7F3" stroke-width="5" stroke-linejoin="round"/>`
   +`<line x1="${B[0]}" y1="${B[1]}" x2="${B[0]}" y2="${B[1]+T}" stroke="#F4F3EF" stroke-opacity=".18" stroke-width="2"/>`;
  const cx=930,cy=edgeY(cx)+T*.56;}
 if(v==='C'){const T=40;
  s+=shadow(T,.12,.18,56)+face(T,'url(#gl)','url(#gr)')+hl('#fff',.95,3);
  const band=(y,hh)=>`<polygon points="${pl([[L[0],L[1]+y],[B[0],B[1]+y],[B[0],B[1]+y+hh],[L[0],L[1]+y+hh]])}" fill="#1D1D1B"/><polygon points="${pl([[B[0],B[1]+y],[R[0],R[1]+y],[R[0],R[1]+y+hh],[B[0],B[1]+y+hh]])}" fill="#111"/>`;
  s+=band(T-9,9)+`<line x1="${B[0]}" y1="${B[1]}" x2="${B[0]}" y2="${B[1]+T-9}" stroke="#fff" stroke-opacity=".5" stroke-width="2"/>`;
  const x=B[0],y=B[1]+(T-9)/2;
}
 return s};
})();


/* ===== Round M refinement: B1 / B2 crafted base, edge vignette, inset tray ===== */
(function(){
const L=[61,623],B=[1116,1152],R=[2171,623],REAR=[1116,94];
const pl=a=>a.map(p=>p.join(',')).join(' ');
const prev=window.baseSVG;
window.baseSVG=function(v,w){
 if(v!=='B1'&&v!=='B2')return prev(v,w);
 const c=v==='B1'?10:8,T=v==='B1'?34:26,tot=c+T;
 const off=(dy,dx=0)=>[[L[0]+dx,L[1]+dy],[B[0]+dx,B[1]+dy],[R[0]+dx,R[1]+dy]];
 const sh=(dy,dx,o,f)=>{const a=off(dy,dx);return `<polygon points="${pl([...a,[a[2][0],a[2][1]-70],[a[0][0],a[0][1]-70]])}" fill="#121212" opacity="${o}" filter="url(#${f})"/>`};
 const defs=`<defs><filter id="s5" x="-10%" y="-60%" width="120%" height="220%"><feGaussianBlur stdDeviation="4"/></filter><filter id="s14" x="-10%" y="-60%" width="120%" height="220%"><feGaussianBlur stdDeviation="13"/></filter><filter id="s30" x="-10%" y="-60%" width="120%" height="220%"><feGaussianBlur stdDeviation="28"/></filter><filter id="s3" x="-5%" y="-50%" width="110%" height="200%"><feGaussianBlur stdDeviation="2.5"/></filter>
 <linearGradient id="cl" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FBFAF7"/><stop offset="1" stop-color="#EEECE6"/></linearGradient>
 <linearGradient id="cr" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#E4E1D9"/><stop offset="1" stop-color="#D4D1C7"/></linearGradient>
 <linearGradient id="bl1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3C3C39"/><stop offset="1" stop-color="#232321"/></linearGradient>
 <linearGradient id="br1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1F1F1D"/><stop offset="1" stop-color="#0F0F0E"/></linearGradient></defs>`;
 let s=defs+sh(tot+4,0,.34,'s5')+sh(tot+14,16,.16,'s14')+sh(tot+30,34,.09,'s30');
 const face=(P0,P1,y0,y1,fill)=>`<polygon points="${pl([[P0[0],P0[1]+y0],[P1[0],P1[1]+y0],[P1[0],P1[1]+y1],[P0[0],P0[1]+y1]])}" fill="${fill}" stroke="${fill}" stroke-width="5" stroke-linejoin="round"/>`;
 // band first (rounded), then chamfer on top
 s+=face(L,B,c-2,tot,'url(#bl1)')+face(B,R,c-2,tot,'url(#br1)');
 // chamfer (porcelain, thin top lip)
 s+=`<polygon points="${pl([[L[0],L[1]-3],[B[0],B[1]-3],[B[0],B[1]+c],[L[0],L[1]+c]])}" fill="url(#cl)"/><polygon points="${pl([[B[0],B[1]-3],[R[0],R[1]-3],[R[0],R[1]+c],[B[0],B[1]+c]])}" fill="url(#cr)"/>`;
 // junction lines
 s+=`<polyline points="${pl([[L[0],L[1]+c],[B[0],B[1]+c],[R[0],R[1]+c]])}" fill="none" stroke="#121212" stroke-opacity=".35" stroke-width="1.5" stroke-linejoin="round"/>`;
 // top highlight on chamfer (light from top-left)
 s+=`<polyline points="${pl([[L[0],L[1]+3.5],[B[0],B[1]+3.5]])}" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="1.6" stroke-linecap="round"/>`;
 // bottom edge catch-light and soft rounded front corner
 s+=`<polyline points="${pl([[L[0],L[1]+tot-1],[B[0],B[1]+tot-1]])}" fill="none" stroke="#fff" stroke-opacity=".14" stroke-width="2"/>`;
 s+=`<line x1="${B[0]}" y1="${B[1]+c}" x2="${B[0]}" y2="${B[1]+tot-1}" stroke="#fff" stroke-opacity=".20" stroke-width="3" filter="url(#s3)"/>`;
 if(v==='B2')s+=`<polyline points="${pl([[L[0]+14,L[1]+c+T*.42+7],[B[0],B[1]+c+T*.42],[R[0]-14,R[1]+c+T*.42+7]])}" fill="none" stroke="#fff" stroke-opacity=".10" stroke-width="2"/>`;
 return s};
window.edgeSVG=function(){const id='vg';
 return `<defs><clipPath id="dclip"><polygon points="${pl([L,REAR,R,B])}"/></clipPath><filter id="vgb" x="-10%" y="-30%" width="120%" height="160%"><feGaussianBlur stdDeviation="18"/></filter></defs>
 <g clip-path="url(#dclip)"><polyline points="${pl([L,B,R])}" fill="none" stroke="#121212" stroke-opacity=".10" stroke-width="64" stroke-linejoin="round" filter="url(#vgb)"/></g>`};
})();

/* Island tray (H1 style), inset into the floor: ONE vermilion dot only while a request waits. viewBox 60 40 1320 750 */
(function(){const PP=(x,y,z)=>[720+(x-y)*5.2,96+(x+y)*2.6-(z||0)*5.2];const P=a=>a.map(q=>q.map(v=>v.toFixed(1)).join(',')).join(' ');
const quad=(x,y,w,d,z)=>[PP(x,y,z),PP(x+w,y,z),PP(x+w,y+d,z),PP(x,y+d,z)];
const box=(x,y,w,d,h,c)=>{const T=quad(x,y,w,d,h),L=[PP(x,y+d,0),PP(x+w,y+d,0),PP(x+w,y+d,h),PP(x,y+d,h)],Rt=[PP(x+w,y,0),PP(x+w,y+d,0),PP(x+w,y+d,h),PP(x+w,y,h)];
 return `<polygon points="${P(L)}" fill="${c.l}" stroke="${c.l}" stroke-width="1.2" stroke-linejoin="round"/><polygon points="${P(Rt)}" fill="${c.r}" stroke="${c.r}" stroke-width="1.2" stroke-linejoin="round"/><polygon points="${P(T)}" fill="${c.t}" stroke="${c.o}" stroke-width="1.1" stroke-linejoin="round"/>`};
window.traySVG=function(w){const h=1.5;
 let s=`<defs><filter id="tb" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3"/></filter><filter id="tb2" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="9"/></filter>
 <linearGradient id="padg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#121212" stop-opacity=".10"/><stop offset=".5" stop-color="#121212" stop-opacity=".03"/><stop offset="1" stop-color="#fff" stop-opacity=".5"/></linearGradient></defs>`;
 // inset bay in the floor material: soft inner shadow top-left, light lip bottom-right
 s+=`<polygon points="${P(quad(84,90,28,19,0))}" fill="url(#padg)" filter="url(#tb2)" opacity=".9"/>`;
 s+=`<polygon points="${P(quad(85.5,91.5,25,16,0))}" fill="#121212" fill-opacity=".05" stroke="#121212" stroke-opacity=".10" stroke-width="1" stroke-linejoin="round"/>`;
 // cast shadow to the lower right (light from top-left)
 const sq=quad(87,93,22,13,0).map(p=>[p[0]+11,p[1]+9]);s+=`<polygon points="${P(sq)}" fill="#121212" opacity=".22" filter="url(#tb)"/>`;
 s+=box(87,93,22,13,h,{t:'#F1EFE9',l:'#33332F',r:'#121211',o:'#161615'});
 // top face light edge (top-left)
 const t=quad(87,93,22,13,h);s+=`<polyline points="${P([t[3],t[0],t[1]])}" fill="none" stroke="#fff" stroke-opacity=".9" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>`;
 if(w){const d=PP(98,99.5,h);s+=`<circle class="glow" cx="${d[0]}" cy="${d[1]}" r="13" fill="#E8452C"/><circle cx="${d[0]}" cy="${d[1]}" r="5.5" fill="#E8452C"/>`}return s}})();

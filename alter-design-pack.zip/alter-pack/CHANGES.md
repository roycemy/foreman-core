# Alter design pack: changes

**Brand**
- Name Black Box → Alter. Wordmark: lowercase bold Geist "alter".
- Logo H1, island tray: an iso tray with a vermilion dot that shows only while something waits. The pack includes the mark, idle mark, dark mark, card mark (#ECE9E2), lockups, app icons light/dark (512/180) and a favicon in a firm cut (heavier stroke, bigger dot) so the dot holds at 16px.
- Usage rules: `screens/brand.html` and `shots/16-brand-*`.

**Screens**
- Every vNext screen is rebranded: top bar, card, receipt footer, phone, favicon and titles.
- Round L: the label "Most one purchase can be" is now "Max per purchase". The wordmark is lowercase.
- Landing:
  - New mark and lowercase wordmark.
  - Primary buttons are rounded ink instead of square vermilion.
  - The hero shows the vNext floor with island B; the old red island and robot figures are gone.
  - The italic red headline is now upright.
  - "SYNTHETIC ONLY. No money moves." is now "Sandbox. No real money moves."
- Tokens are consolidated in `tokens.css`.

**Shots** (`shots/`; 1440 = desktop, 390 = phone at 2x)
01 floor, 02 collab, 03 activity glyphs, 04 island B close-up, 05 inbox, 06 anything on me, 07 bot panel, 08 public receipt + OG, 09 receipts, 10 card, 11 phone nav, 12 demo, 13 sandbox rules, 14 card with bot trust, 15 landing, 16 brand.

## Round M: floor first action, welcome, new island
Mockup: `screens/floor.html` (`?s=hover|tour1|tour2|tour3|done|badge|panel`, `?i=A|B|C`). Island options: `screens/islands.html`. Shots: `shots/M-*`.
- **Prompt bar is the hero.** Line "Tell your team what to do", three example chips, a larger bar. Search, Inbox, avatar and zoom are unchanged.
- **Inbox says it in words.** "2 need you" with a vermilion dot only when something waits; otherwise a quiet "5 running". Running jobs collapse into one row in the pop-down.
- **Live line per bot** on hover or tap ("Writing the weekly memo, 3 min in"). Tap opens the panel with one clear action (Approve, Reconnect or See the draft).
- **Welcome tour**, 3 tips (team, where things wait, where to ask), shown once (`localStorage alter.tour`). Skip ends it.
- **Done moment:** the bot walks the finished job to the tray, the tray glows, a soft "Done" chip appears and fades. It is off under reduced motion (the Done chip shows briefly instead).
- **"3 of 3 active" pill** is now "Your team finished 4 jobs today."
- **New island base:** the baked grey slab and blurry shadow are gone (`img/floor-clean.png`, no slab, no shadow). The base is drawn in SVG by `base.js`.
  - A, Porcelain slab: thick two-tone edge, engraved line, recessed dot.
  - **B, Ink band (applied):** near-black band like the H1 tray, porcelain rim line, a vermilion dot that glows only when a request waits.
  - C, Floating tray: thin porcelain plate with an ink lip and a vermilion slot at the front corner.

### Round M update: one red dot
- Island B is chosen and now clean: the near-black band has **no dot or slot**. Options A and C lost their dots too, so all three compare the base alone.
- The floor's center tray is now the H1 tray: porcelain top with an ink outline, near-black band, and **one** vermilion dot that glows only while a request waits. Idle shows the tray with no dot, like the idle mark.
- `img/floor-clean.png` no longer contains the red-outlined tray, its shadow or the red dashed line. The center is plain terrazzo, and the tray is drawn on top (`traySVG()` in `base.js`).
- Vermilion on the floor is now just that one dot (plus the Inbox dot, which is also a "waiting" signal).

### Round M update: one crafted island (B2 applied)
Two refined versions are in `screens/islands.html`: B1 (band 34px) and B2 (band 26px, faint inset line). **B2 is applied** (slimmer, calmer).
- **Band:** thinner, with a porcelain chamfer lip between floor and band, and soft top-left lighting. The left face is lighter than the right, with a vertical gradient on both. The corners are rounded and the front corner has a soft catch-light. No new colors.
- **Shadow:** three layers, tight contact, mid and wide, falling to the lower right. No blob.
- **Floor:** a gentle edge vignette along the front edges, drawn over the art and clipped to the floor.
- **Tray:** inset into the floor in a shallow bay, with a cast shadow to the lower right and the same lighting as the band. Still ONE vermilion dot, glowing only while a request waits.
- All M shots were re-rendered on the new base. The earlier A, B and C option sheet is replaced by `M-islands-B1-B2-1440.png`.

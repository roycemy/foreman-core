# Paste into Claude Code (run at the foreman-core repo root)

You are applying an owner-approved rebrand (Black Box → **Alter**, logo "H1 island tray") and the vNext + round L screen designs. These are visual and copy changes. **Do not change any API contract, route, endpoint, request body or server behavior.** The mockups in `screens/` are static references, not drop-in code: port their look into the real components.

## Inputs
Unzip `alter-design-pack.zip` into `./alter-pack/`. Read `CHANGES.md`, then look at `shots/00-overview.png`.

## 1. Brand (do first)
1. In `public/brand.js` set `name: 'Alter'` and `upper: 'alter'` (the wordmark is lowercase bold Geist, not caps). Rebuild anything derived from it (titles, aria-labels, OAuth consent `{brand}` slots, Cursor deeplink server name).
2. Copy `alter-pack/brand/*` to `public/brand/`. Favicon: `<link rel="icon" href="/brand/favicon.svg">` plus `favicon-32.png` / `favicon-16.png` fallbacks; `apple-touch-icon` = `alter-icon-light-180.png`.
3. Replace every old mark (bordered square with red bar, in CSS `.mark`/`.wm .mark` and the inline favicon) with `alter-mark.svg` (idle: `alter-mark-idle.svg` when nothing waits). On the dark card use `alter-mark-card.svg` (#ECE9E2).
4. Lockup text "alter" must be live text in Geist 700, letter-spacing −0.045em (the SVG lockups need Geist loaded; outline them if used as images).

## 2. Tokens
Merge `alter-pack/tokens.css` into `public/styles/tokens.css`. Keep existing variable names; map them to the new values. Geist only; Geist Mono only for real code. No uppercase labels.

## 3. Screens (port in this order; match shots at 1440 and 390)
1. Top bar: Floor / Receipts / Card + Inbox button with count. Remove Work, Team, Permissions and Card sandbox tabs (routes stay; just unlinked). Phone nav: Inbox / Receipts / Card. (`05`, `11`)
2. "Anything on me?" pop-down from Inbox, incl. empty state. (`06`)
3. Floor: island B (flat porcelain tray; vermilion dot only while a request waits). **Remove the old red island baked into the floor art** (use the no-island floor asset; draw island B as its own layer). Collab dotted line + small card, activity glyph badges. (`01–04`)
4. Bot panel + permissions. (`07`)
5. Receipts list and public receipt + OG image; Alter mark in the receipt footer. Wording "model costs". (`08`, `09`)
6. Card page with bot trust rows ("N decisions · M blocked", "Not enough data yet" under 5) and footnote. Never show a score. (`10`, `14`)
7. Sandbox rules: 520px dialog on desktop, full page on phone. Label is **"Max per purchase"**. Blank field = no extra limit. (`13`)
8. Authorization demo page: six scenarios, sentence-case Allow / Deny / Ask, plain reasons, grey rule names, "Real charge: $0.00 on every scenario." (`12`)
9. Landing: H1 mark, rounded ink primary buttons, hero art = the vNext floor, "Sandbox. No real money moves." (`15`)

Keep the line **"Sandbox. No real money moves."** wherever money appears in test mode. Do not change the meaning of any rule or the owner-approval requirement.

## 4. Verify
- `rg -i "black ?box" public/` returns nothing user-facing.
- Favicon dot visible at 16px; mark visible on the dark card.
- Re-run the existing `verify.js` suite; all hooks in `HOOKS.md` still exist.
- Screenshot each screen at 1440 and 390 and compare with `alter-pack/shots/`.

## 5. Round M: floor first action, welcome and new island (apply after sections 1 to 4; see `shots/M-*`)
Reference code: `screens/floor.html`, `screens/base.js`. Do not change any API.
1. **Island.** Replace the floor art with `screens/img/floor-clean.png` (floor with no slab, no shadow, no red island). Draw the base as an SVG layer *under* the art with the same box (`viewBox 0 0 2232 1270`); copy `baseSVG('B', waiting)` from `base.js`. Variants A and C stay available. Remove the old slab shadow CSS. The dot glows (`.glow`) only while a request waits; idle uses the dark dot.
2. **Prompt hero.** Above the bottom prompt bar: `<h2>Tell your team what to do</h2>` and 3 chips that fill the input when tapped (examples should come from the user's own recent jobs when available). Bar 58px high, radius 18. Leave search, Inbox, avatar, corner button and zoom as they are. On narrow screens the crew sentence moves to the top-left; chips scroll sideways.
3. **Inbox badge.** Count text "N need you" plus a vermilion dot only when N > 0 (from the existing approvals count). When N = 0 show "M running" in muted text without a dot. In the pop-down, collapse running jobs into one "M running" row.
4. **Bot live line.** On hover or tap of a bot show a tip: current job in plain words plus elapsed time ("Writing the weekly memo, 3 min in"; build it from the job title and start time). Tap opens the existing bot panel with exactly one primary button: Approve if a request waits, Reconnect if access lapsed, otherwise "See the draft".
5. **Welcome tour.** 3 steps (team, where things wait, where to ask) with a spotlight and a card. Show once per owner: prefer a server flag, otherwise `localStorage['alter.tour']`. Skip sets it too.
6. **Done moment.** When a job finishes: the bot sprite walks to the tray (about 3.4s, linear), the tray glows, a "Done · <job title>" chip fades in and out. With `prefers-reduced-motion` skip the walk and show only the chip for 3s. The mock uses Grok Bot's sprite because the other sprites are baked into the art; in the real build use the sprite layer.
7. **Crew pill.** Replace "N of N active" with "Your team finished {n} jobs today." (n from today's receipts; hide the line at 0).
8. Verify at 1440, 1024x715 and 390 against `shots/M-*`. Keep text sentence case, Geist only.

### 5a. Round M update: exactly one red dot
- Use island **B** with **no dot, slot or vermilion on the band**. Delete any glow or dot code on the base. In `base.js` the options differ only in edge style.
- Replace the old red-outlined tray art with the H1 tray from `traySVG(waiting)` in `base.js`: porcelain top (#F4F3EF) with 1.6 ink stroke, ink band (#1D1D1B / #111), and one vermilion dot (r 5.5, glow r 13, `.glow` animation). Draw the dot only while a request waits; idle shows the tray alone.
- Use the updated `img/floor-clean.png`. It already has the old red tray, its shadow and the dashed red line painted out. If the real floor art is regenerated, do not bake a tray into it.
- Check: at 1440 the only vermilion on the floor is the tray dot (and the Inbox dot).

### 5b. Round M update: crafted island (supersedes 5 and 5a for the base and tray)
- Base: `baseSVG('B2', waiting)` in `screens/base.js` (B1 is the thicker alternative). Draw it under the floor art. Then draw `edgeSVG()` over the art for the front-edge vignette (clipped to the floor diamond).
- Layers, bottom to top: three shadows (tight contact, mid, wide, falling lower right), band faces (left lighter than right, vertical gradients, rounded joins), porcelain chamfer lip, junction line, top-left highlight, catch-light on the front corner.
- Tray: `traySVG(waiting)` draws a shallow inset bay, a cast shadow to the lower right, then the tray (porcelain top, ink band). One vermilion dot, shown and glowing only while a request waits.
- Light is from the top left everywhere: the left faces are lighter, shadows fall right and down. Do not add colors. Do not put any vermilion on the band.
- Keep the baked floor art free of slab, shadow and tray (`img/floor-clean.png`). Compare against `shots/M-*` at 1440, 1024x715 and 390.
